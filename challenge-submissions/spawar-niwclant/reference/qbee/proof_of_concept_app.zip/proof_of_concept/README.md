# Dependencies
This scripts depend on multiple python libraries to be run.
Install the dependencies via:
```
pip install requirements.txt
```

Tested with python 3.6