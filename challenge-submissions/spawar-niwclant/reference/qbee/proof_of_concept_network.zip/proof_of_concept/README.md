# Python Dependencies
This scripts depend on multiple python library being installed as well as __wireshark command line utils__.

Install the python dependencies with:
```
pip install -r requirements.txt
```

