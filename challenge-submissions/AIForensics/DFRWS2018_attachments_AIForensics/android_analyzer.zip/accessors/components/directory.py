import re
import os



class directory:
    def __init__(self, volumes, directory_path):
        self.m_volumes = volumes

        file_pattern = directory_path[directory_path.rindex('/')+1:]
        file_pattern = (file_pattern if file_pattern[0] != '*' else '.*' + file_pattern[1:])
        self.m_file_pattern = re.compile(file_pattern)

        self.m_directory_path = directory_path[:directory_path.rindex('/')]
        self.m_mount_point = self.m_directory_path[1:self.m_directory_path[1:].index('/') + 1]
        self.m_directory_path_without_mount_point = self.m_directory_path[self.m_directory_path[1:].index('/')+1:]

        self.m_directory_handle = None

        self.m_entries = []

    def open(self):
        if self.m_directory_handle is None:
            self.m_directory_handle = self.m_volumes.get_volume_by_type(self.m_mount_point).get_handle().open_dir(path=self.m_directory_path_without_mount_point)
        return self.m_directory_handle

    def get_entries(self):
        if len(self.m_entries) == 0:
            directory_handle = self.open()
            for entry in directory_handle:

                if hasattr(entry, "info") and hasattr(entry.info, "name") and hasattr(entry.info.name, "name") and entry.info.name.name not in ['.', '..']:
                    if self.m_file_pattern.match(entry.info.name.name) is not None:
                        self.m_entries.append('/'.join([self.m_directory_path, entry.info.name.name]))

        return self.m_entries

    def extract(self, out_path):
        from accessors.accessor import accessor

        entries = self.get_entries()
        for entry in entries:
            accessor.instance().get_file(entry).extract(out_path)

    def get_mount_point(self):
        return self.m_mount_point

    def get_diectory_path_without_mount_point(self):
        return self.m_directory_path_without_mount_point