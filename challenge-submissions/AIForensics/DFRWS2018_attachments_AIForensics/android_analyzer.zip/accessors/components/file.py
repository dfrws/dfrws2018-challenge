import datetime
import os
import re

class file:
    def __init__(self, volumes, file_path):
        self.m_volumes = volumes

        self.m_file_path = file_path
        self.BUFF_SIZE = 1024*1024
        self.m_mount_point = self.m_file_path[1:self.m_file_path[1:].index('/')+1]
        self.m_file_path_without_mount_point = self.m_file_path[self.m_file_path[1:].index('/')+1:]
        self.m_file_name = os.path.basename(self.m_file_path)

        self.m_file_handle = None

    def open(self):
        if self.m_file_handle is None:
            self.m_file_handle = self.m_volumes.get_volume_by_type(self.m_mount_point).get_handle().open(self.m_file_path_without_mount_point)
        return self.m_file_handle

    def read(self, offset=0, length=-1):
        file_handle = self.open()
        if file_handle.info.meta.size == 0:
            raise Exception('[name(%s)/size(%s)/ctime(%s)/mtime(%s)/crtime(%s)/atime(%s)]'%(file_handle.info.name.name, file_handle.info.meta.size, str(self.get_localtime(file_handle.info.meta.ctime)), str(self.get_localtime(file_handle.info.meta.mtime)), str(self.get_localtime(file_handle.info.meta.crtime)), str(self.get_localtime(file_handle.info.meta.atime))))

        if length == -1:
            length = file_handle.info.meta.size
        return file_handle.read_random(offset, length)

    def extract(self, out_path):
        try:
            with open(os.path.join(out_path, self.m_file_name), 'wb') as out:
                out.write(self.read())
        except Exception as e:
            print e

    def get_file_handle(self):
        return self.m_file_handle

    def get_mount_point(self):
        return self.m_mount_point

    def get_file_path_without_mount_point(self):
        return self.m_file_path_without_mount_point

    def get_localtime(self, unixtime):
        utc_time = datetime.datetime.fromtimestamp(unixtime)
        local_time = utc_time - datetime.timedelta(hours=7)

        return local_time

    def get_time(self, file_handle):
        created_time = self.get_localtime(file_handle.info.meta.crtime)
        access_time = self.get_localtime(file_handle.info.meta.atime)
        last_change_time = self.get_localtime(file_handle.info.meta.ctime)
        last_modification_time = self.get_localtime(file_handle.info.meta.mtime)

        return [str(last_modification_time), str(last_change_time), str(access_time), str(created_time)]