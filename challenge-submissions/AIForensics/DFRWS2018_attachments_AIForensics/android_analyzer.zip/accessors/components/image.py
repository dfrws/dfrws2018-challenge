import pytsk3

from accessors.components.volume import volumes


class image:
    def __init__(self, image_path):
        self.m_image_path = image_path
        self.m_image_handle = pytsk3.Img_Info(self.m_image_path)
        self.m_volumes = volumes(self.m_image_handle)

    def get_volumes(self):
        return self.m_volumes
