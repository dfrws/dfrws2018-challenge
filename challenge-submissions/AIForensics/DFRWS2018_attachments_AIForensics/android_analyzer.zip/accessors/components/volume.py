import pytsk3


class volumes:
    def __init__(self, image_handle):
        self.m_image_handle = image_handle
        self.m_volumes_handle = pytsk3.Volume_Info(image_handle)

        self.m_volumes = {}
        for volume_descriptor in self.m_volumes_handle:
            try:
                self.m_volumes[volume_descriptor.desc.lower()] = volume(self, volume_descriptor)
            except:
                self.m_volumes[volume_descriptor.desc.lower()] = None

    def get_image_handle(self):
        return self.m_image_handle

    def get_sector_size(self):
        return self.m_volumes_handle.info.block_size

    def get_volume_by_type(self, type):
        type = 'userdata' if type == 'data' else type

        if (type in self.m_volumes.keys()) and (self.m_volumes[type] is not None):
            return self.m_volumes[type]

    def get_volume_by_number(self, number):
        return self.m_volumes.values()[number]

    def get_handle(self):
        return self.m_volumes_handle


class volume:
    def __init__(self, volumes, volume_descriptor):
        self.m_volume_descriptor = volume_descriptor
        self.m_volume_handle = pytsk3.FS_Info(volumes.get_image_handle(), offset=self.get_volume_start_sector() * volumes.get_sector_size())

    def get_type(self):
        return self.m_volume_descriptor.desc

    def get_volume_number(self):
        return self.m_volume_descriptor.addr

    def get_volume_start_sector(self):
        return self.m_volume_descriptor.start

    def get_length(self):
        return self.m_volume_descriptor.len

    def get_handle(self):
        return self.m_volume_handle