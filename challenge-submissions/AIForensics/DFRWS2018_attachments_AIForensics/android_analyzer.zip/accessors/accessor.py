from accessors.components.directory import directory
from accessors.components.file import file
from accessors.components.image import image
from libs.singletone import singletone
from datetime import datetime


class accessor(singletone):
    def __init__(self):
        self.m_image_path = None
        self.m_image = None

        self.m_extracted_artifacts = {}
        self.m_access_history = []

    def set_image_path(self, image_path):
        self.m_image_path = image_path

    def get_image(self):
        if self.m_image is None:
            self.m_image = image(self.m_image_path)
        return self.m_image

    def get_volumes(self):
        return self.m_image.get_volumes()

    def get_file(self, file_path):
        self.m_extracted_artifacts[file_path] = None
        self.m_access_history.append((datetime.now(), file_path))
        if self.m_image is not None:
            return file(self.get_volumes(), file_path)

    def get_dir(self, dir_path):
        if self.m_image is not None:
            return directory(self.get_volumes(), dir_path)

    def get_access_history(self):
        return self.m_access_history

    def get_extracted_artifacts(self):
        return self.m_extracted_artifacts