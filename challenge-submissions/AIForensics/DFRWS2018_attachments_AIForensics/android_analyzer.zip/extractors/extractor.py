from constant.artifacts import artifacts
from modules.module_policy import module_group, module


class artifact_extractor:
    def __init__(self, base_path, module_tags):
        self.m_base_path = base_path
        self.m_module_tags = module_tags

        self.m_base_module_group_name = 'extracted'
        self.m_selective_artifacts = []

        self.m_root_module_group = module_group(self.m_base_path, self.m_base_module_group_name)

        self.initialize_modules()

    def retrieve_modules(self, root_module_group, root_tag_artifacts):
        root_artifact_keys = root_tag_artifacts.keys()
        for root_artifact_key in root_artifact_keys:

            if type(root_tag_artifacts[root_artifact_key]) == list:
                root_module_group.add(module(root_artifact_key, root_tag_artifacts[root_artifact_key]))

            elif type(root_tag_artifacts[root_artifact_key]) == dict:
                module_group_to_add = module_group(root_module_group.get_context_path(), root_artifact_key)
                root_module_group.add(module_group_to_add)
                self.retrieve_modules(module_group_to_add, root_tag_artifacts[root_artifact_key])

        pass

    def initialize_modules(self):
        for module_tag in self.m_module_tags:
            last_tag_artifacts = artifacts.all
            last_added_module_group = self.m_root_module_group

            tag_keys = module_tag.split('/')
            for tag_key in tag_keys[:-1]:
                added_module_group = module_group(self.m_base_path, tag_key)
                last_added_module_group.add(added_module_group)
                last_added_module_group = added_module_group

            for tag_key in tag_keys[:-1]:
                last_tag_artifacts = last_tag_artifacts[tag_key]

            if tag_keys[-1] == '*':
                self.retrieve_modules(last_added_module_group, last_tag_artifacts)
                pass
            else:
                last_tag_artifacts = last_tag_artifacts[tag_keys[-1]]
                last_added_module_group.add(module(tag_keys[-1], last_tag_artifacts))

    def extract(self):
        

        self.m_root_module_group.do()
