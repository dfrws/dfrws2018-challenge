import abc
import os

from accessors.accessor import accessor


class module_policy:
    @abc.abstractmethod
    def do(self):
        pass


class module_group(module_policy):
    def __init__(self, base_path, group_name):
        self.m_base_path = base_path
        self.m_group_name = group_name
        self.m_moudles = []

        self.m_context_path = os.path.join(self.m_base_path, self.m_group_name)

    def add(self, module):
        module.set_context_path(self.get_context_path())
        self.m_moudles.append(module)

    def get_group_name(self):
        return self.m_group_name

    def set_context_path(self, base_path):
        self.m_context_path = os.path.join(base_path, self.m_group_name)

    def get_context_path(self):
        return self.m_context_path

    def do(self):
        if not os.path.isdir(self.m_context_path):
            os.makedirs(self.m_context_path)

        for module in self.m_moudles:
            module.do()


class module(module_policy):
    def __init__(self, module_name, artifacts):
        self.m_module_name = module_name
        self.m_artifacts = artifacts

        self.m_context_path = None

    def set_context_path(self, base_path):
        self.m_context_path = os.path.join(base_path, self.m_module_name)

    def get_context_path(self):
        return self.m_context_path

    def do(self):
        if not os.path.isdir(self.m_context_path):
            os.makedirs(self.m_context_path)

        for artifact in self.m_artifacts:
            if artifact['type'] == 'file':
                accessor.instance().get_file(artifact['path']).extract(self.m_context_path)
            elif artifact['type'] == 'dir':
                accessor.instance().get_dir(artifact['path']).extract(self.m_context_path)
            print artifact
