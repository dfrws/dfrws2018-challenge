import os
import argparse
from app import app
from constant.choices import choices


def arguments():
    parser = argparse.ArgumentParser('Analysis android constant from physical image by @aiforensics')
    parser.add_argument('-i', '--image_path', dest='image_path', nargs='?', metavar='image path', required=True, help='physical image path to analyze')
    parser.add_argument('-m', '--module_tags', dest='module_tags', nargs='+', metavar='', choices=choices.options, default='system/*', help='extraction/anaysis modules (ex. system/*)')

    arguments = parser.parse_args()

    if not os.path.exists(arguments.image_path):
        raise Exception({
            'tag': 'options',
            'message': 'Image file(%s) does not exist' % arguments.image_path
        })

    return arguments


if __name__ == '__main__':
    app = app(arguments())
    app.start()
