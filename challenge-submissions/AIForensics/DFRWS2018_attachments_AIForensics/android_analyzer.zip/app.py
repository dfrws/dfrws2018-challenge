import os

from accessors.accessor import accessor
from extractors import extractor

class app:
    def __init__(self, arguments):
        self.m_base_path = os.path.dirname(os.path.abspath(__file__))
        self.m_image_path = arguments.image_path
        self.m_module_tags = arguments.module_tags

    def start(self):
        print '[+] Current process : checking image'
        accessor.instance().set_image_path(self.m_image_path)
        accessor.instance().get_image()

        print '[+] Current process : extracting constant'
        artifact_extractor = extractor.artifact_extractor(self.m_base_path, self.m_module_tags)
        artifact_extractor.extract()

