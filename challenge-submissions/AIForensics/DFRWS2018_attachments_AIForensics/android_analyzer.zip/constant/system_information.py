
class system_information:
    artifacts = {
        'category': 'system_information',
        'paths': [
            {'path': '/data/misc/wifi/wpa_supplicant.conf', 'type': 'file'},
            {'path': '/data/misc/bluedroid/bt_config.conf', 'type': 'file'},
            {'path': '/data/system/users/0/accounts.db', 'type': 'file'},
            {'path': '/data/system/packages.list', 'type': 'file'},
            {'path': '/system/build.prop', 'type': 'file'},
            {'path': '/efs/wifi/.mac.info', 'type': 'file'},
            {'path': '/efs/bluetooth/bt_addr', 'type': 'file'},
            {'path': '/data/property/persist.sys.timezone', 'type': 'file'},
            {'path': '/data/property/persist.sys.locale', 'type': 'file'},
            {'path': '/data/system/SimCard.dat', 'type': 'file'}
        ],
        'sub_categories': {
            'device': [
                {'name': 'wpa_supplicant.conf', 'path': '/data/misc/wifi/wpa_supplicant.conf', 'type': 'text'}
            ],
            'network': [
                {'name': 'wpa_supplicant.conf', 'path': '/data/misc/wifi/wpa_supplicant.conf', 'type': 'text'},
                {'name': 'bt_config.conf', 'path': '/data/misc/bluedroid/bt_config.conf', 'type': 'text'},
                {'name': '.mac.info', 'path': '/efs/wifi/.mac.info', 'type': 'text'},
                {'name': 'bt_addr', 'path': '/efs/bluetooth/bt_addr', 'type': 'text'}
            ],
            'simcard': [
                {'name': 'SimCard.dat', 'path': '/data/system/SimCard.dat', 'type': 'text'}
            ],
            'settings': {
                'timezone': [
                    {'name': 'persist.sys.timezone', 'path': '/data/property/persist.sys.timezone', 'type': 'text'}
                ],
                'locale': [
                    {'name': 'persist.sys.locale', 'path': '/data/property/persist.sys.locale', 'type': 'text'}
                ]
            },
            'accounts': [
                {'name': 'accounts.db', 'path': '/data/system/users/0/accounts.db', 'type': 'sqlite'}
            ],
            'packages': [
                {'name': 'packages.list', 'path': '/data/system/packages.list', 'type': 'text'},
                {'name': 'packages.xml', 'path': '/data/system/packages.xml', 'type': 'xml'}
            ],
            'software': [
                {'name': 'build.prop', 'path': '/system/build.prop', 'type': 'text'}
            ]
        }
    }