
class artifacts:
    all = {
        'system': {
            'basic': [
                {'path': '/data/misc/wifi/wpa_supplicant.conf', 'type': 'file', 'format': 'text'}
            ],
            'network': [
                {'path': '/data/misc/wifi/wpa_supplicant.conf', 'type': 'file', 'format': 'text'},
                {'path': '/data/misc/bluedroid/bt_config.conf', 'type': 'file', 'format': 'text'},
                {'path': '/efs/wifi/.mac.info', 'type': 'file', 'format': 'text'},
                {'path': '/efs/bluetooth/bt_addr', 'type': 'file', 'format': 'text'}
            ],
            'simcard':[
                {'path': '/data/system/SimCard.dat', 'type': 'file', 'format': 'text'}
            ],
            'settings': {
                'timezone': [
                    {'path': '/data/property/persist.sys.timezone', 'type': 'file', 'format': 'text'}
                ],
                'locale': [
                    {'path': '/data/property/persist.sys.locale', 'type': 'file', 'format': 'text'}
                ]
            },
            'accounts': [
                {'path': '/data/system/users/0/accounts.db', 'type': 'file', 'format': 'sqlite'}
            ],
            'packages': [
                {'path': '/data/system/packages.list', 'type': 'file', 'format': 'text'},
                {'path': '/data/system/packages.xml', 'type': 'file', 'format': 'xml'}
            ],
            'software': [
                {'path': '/system/build.prop', 'type': 'file', 'format': 'text'}
            ]
        },
        'usage': {
            'network': [
                {'path': '/data/misc/wifi/networkHistory.txt', 'type': 'file', 'format': 'text'},
            ],
            'usagestats': [
                {'path': '/data/system/usagestats/0/daily/*', 'type': 'dir', 'format': 'xml'},
                {'path': '/data/system/usagestats/0/monthly/*', 'type': 'dir', 'format': 'xml'},
                {'path': '/data/system/usagestats/0/weekly/*', 'type': 'dir', 'format': 'xml'},
            ],
            'procstats': [
                {'path': '/data/system/procstats/*', 'type': 'dir', 'format': 'bin'},
            ],
            'batterystats': [
                {'path': '/data/system/batterystats-daily.xml', 'type': 'file', 'format': 'xml'},
                {'path': '/data/data/com.google.android.gms/files/BatterystatsDumpsysTask.gz', 'type': 'file', 'format': 'archive'},
            ],
            'notifications': [
                {'path': '/data/system/notification_log.db', 'type': 'file', 'format': 'sqlite'},
            ],
            'recent_activity': [
                {'path': '/data/system/recent_images/*', 'type': 'dir', 'format': 'image'},
                {'path': '/data/system/recent_tasks/*', 'type': 'dir', 'format': 'xml'},
            ],
            'poweron': [
                {'path': '/data/log/rtc.log', 'type': 'file', 'format': 'text'},
            ],
            'poweroff': [
                {'path': '/data/log/power_off_reset_reason.txt', 'type': 'file', 'format': 'text'},
                {'path': '/data/log/power_off_reset_reason_backup.txt', 'type': 'file', 'format': 'text'}
            ]
        },
        'app': {
            'communication': {
                'contactprovider': [
                    {'path': '/data/data/com.android.providers.contacts/databases/contacts2.db', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.providers.contacts/databases/contacts2.db-wal', 'type': 'file', 'format': 'sqlite'}
                ],
                'sms': [
                    {'path': '/data/data/com.android.providers.telephony/databases/mmssms.db', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.providers.telephony/databases/telephony.db', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.providers.telephony/databases/telephony.db-journal', 'type': 'file', 'format': 'sqlite'}
                ],
                'facebook': [
                    {'path': '/data/media/0/com.facebook.katana/fb_temp/*', 'type': 'dir', 'format': 'image'},
                    {'path': '/data/media/0/Pictures/Facebook/*', 'type': 'dir', 'format': 'image'}
                ],
                'telegram': [
                    {'path': '/data/media/0/Android/data/org.telegram.messenger/cache/*', 'type': 'dir', 'format': 'image'},
                    {'path': '/data/media/0/Pictures/Telegram/*', 'type': 'dir', 'format': 'image'},
                    {'path': '/data/media/0/Telegram/Telegram Audio/*', 'type': 'dir', 'format': 'audio'},
                    {'path': '/data/media/0/Telegram/Telegram Documents/*', 'type': 'dir', 'format': 'video'},
                    {'path': '/data/media/0/Telegram/Telegram Images/*', 'type': 'dir', 'format': 'image'}
                ],
                'whatsapp': [
                    {'path': '/data/data/com.whatsapp/databases/wa.db', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/media/0/WhatsApp/Databases/msgstore.db.crypt12', 'type': 'file', 'format': 'sqlite(encrypted)'},
                    {'path': '/data/media/0/WhatsApp/Media/WhatsApp Images/*', 'type': 'dir', 'format': 'image'},
                    {'path': '/data/media/0/WhatsApp/Media/WhatsApp Images/Sent/*', 'type': 'dir', 'format': 'image'}
                ]
            },
            'media': {
                'mediaprovider': [
                    {'path': '/data/data/com.android.providers.media/databases/external.db', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.providers.media/databases/internal.db', 'type': 'file', 'format': 'sqlite'}
                ],
                'samsungcmhprovider': [
                    {'path': '/data/data/com.samsung.cmh/databases/cmh.db', 'type': 'file', 'format': 'sqlite'}
                ]
            },
            'userinteraction': {
                'userdictionary': [
                    {'path': '/data/data/com.android.providers.userdictionary/databases/user_dict.db', 'type': 'file', 'format': 'sqlite'}
                ]
            },
            'iot': {
                'echo': {
                    'databases': [
                        {'path': '/data/data/com.amazon.dee.app/databases/RKStorage', 'type': 'file', 'format': 'sqlite'},
                        {'path': '/data/data/com.amazon.dee.app/databases/RKStorage-journal', 'type': 'file', 'format': 'sqlite'},
                        {'path': '/data/data/com.amazon.dee.app/databases/map_data_storage_v2.db', 'type': 'file', 'format': 'sqlite'},
                        {'path': '/data/data/com.amazon.dee.app/databases/DataStore.db', 'type': 'file', 'format': 'sqlite'}
                    ],
                    'webcache': [
                        {'path': '/data/data/com.amazon.dee.app/cache/org.chromium.android_webview/*', 'type': 'dir', 'format': 'webcache'}
                    ]
                },
                'ismartalarm': {
                    'databases': [
                        {'path': '/data/data/iSA.common/databases/iSmartAlarm.DB', 'type': 'file', 'format': 'sqlite'},
                        {'path': '/data/data/iSA.common/databases/iSmartAlarm.DB-journal', 'type': 'file', 'format': 'sqlite'}
                    ],
                    'sharedprefs': [
                        {'path': '/data/data/iSA.common/shared_prefs/iSmartAlermData.xml', 'type': 'file', 'format': 'text'}
                    ],
                    'data': [
                        {'path': '/data/media/0/iSmartAlarm/Log/*', 'type': 'dir', 'format': 'text'},
                        {'path': '/data/media/0/iSmartAlarm/Image/Logo/*', 'type': 'dir', 'format': 'image'}
                    ]
                },
                'nest': {
                    'databases': [
                        {'path': '/data/data/com.nest.android/databases/cache', 'type': 'file', 'format': 'sqlite'},
                        {'path': '/data/data/com.nest.android/databases/cache-journal', 'type': 'file', 'format': 'sqlite'}
                    ],
                    'cache': [
                        {'path': '/data/data/com.nest.android/cache/cache/*', 'type': 'dir', 'format': 'text'}
                    ],
                    'sharedprefs': [
                        {'path': '/data/data/com.nest.android/shared_prefs/com.nest.android.preferences.xml', 'type': 'file', 'format': 'text'},
                        {'path': '/data/data/com.nest.android/shared_prefs/DevicePreferences.xml', 'type': 'file', 'format': 'text'}
                    ],
                    'data': [
                        {'path': '/data/media/0/Pictures/Nest/*', 'type': 'dir', 'format': 'video'}
                    ]
                },
                'arlo': {
                    'sharedprefs': [
                        {'path': '/data/data/com.netgear.android/shared_prefs/Phoenix.xml', 'type': 'file', 'format': 'text'}
                    ],
                    'cache': [
                        {'path': '/data/data/com.netgear.android/cache/cams/*', 'type': 'dir', 'format': 'image'},
                        {'path': '/data/data/com.netgear.android/cache/http/*', 'type': 'dir', 'format': 'image'},
                        {'path': '/data/data/com.netgear.android/cache/org.chromium.android_webview/*', 'type': 'dir', 'format': 'image'},
                        {'path': '/data/data/com.netgear.android/cache/thumbs/*', 'type': 'dir', 'format': 'image'}
                    ]
                },
                'qbeecam': {
                    'sharedprefs': [
                        {'path': '/data/data/com.vestiacom.qbeecamera/shared_prefs/com.vestiacom.qbeecamera_preferences.xml', 'type': 'file', 'format': 'text'}
                    ]
                },
                'wink': {
                    'databases': [
                        {'path': '/data/data/com.quirky.android.wink.wink/databases/persistenceDB', 'type': 'file', 'format': 'sqlite'},
                        {'path': '/data/data/com.quirky.android.wink.wink/databases/persistenceDB-journal', 'type': 'file', 'format': 'sqlite'}
                    ],
                    'sharedprefs': [
                        {'path': '/data/data/com.quirky.android.wink.wink/shared_prefs/com.quirky.android.wink.wink_preferences.xml', 'type': 'file', 'format': 'text'},
                        {'path': '/data/data/com.quirky.android.wink.wink/shared_prefs/user.xml', 'type': 'file', 'format': 'text'},
                        {'path': '/data/data/com.quirky.android.wink.wink/shared_prefs/wink_local_pref_[0-9]*.xml', 'type': 'dir', 'format': 'text'},
                        {'path': '/data/data/com.quirky.android.wink.wink/shared_prefs/WinkPreferencesFile.xml', 'type': 'file', 'format': 'text'}
                    ],
                    'cache': [
                        {'path': '/data/data/com.quirky.android.wink.wink/cache/image_manager_disk_cache/*', 'type': 'dir', 'format': 'image'}
                    ]
                }
            },
            'mail': {
                'gmail': [
                    {'path': '/data/data/com.google.android.gm/databases/mailstore\\..*\\.db', 'type': 'dir', 'format': 'sqlite'},
                    {'path': '/data/data/com.google.android.gm/databases/mailstore\\..*\\.db-wal', 'type': 'dir', 'format': 'sqlite'},
                    {'path': '/data/data/com.google.android.gm/cache/jpinkman2018@gmail.com/*','type': 'dir', 'format': 'image'},
                    {'path': '/data/data/com.google.android.gm/shared_prefs/MailAppProvider.xml', 'type': 'file', 'format': 'xml'},
                    {'path': '/data/data/com.google.android.gm/shared_prefs/Gmail.xml', 'type': 'file', 'format': 'xml'},
                    {'path': '/data/data/com.google.android.gm/shared_prefs/UnifiedEmail.xml', 'type': 'file', 'format': 'xml'}
                ]
            },
            'store': {
                'playstore' : [
                    {'path': '/data/data/com.android.vending/databases/library.db', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.vending/databases/package_verification.db', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.vending/databases/suggestions.db', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.vending/databases/localappstate.db', 'type': 'file', 'format': 'sqlite'}
                ]
            },
            'browser': {
                'chrome': [
                    {'path': '/data/data/com.android.chrome/app_chrome/Default/Sync Data/SyncData.sqlite3', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.chrome/app_chrome/Default/Bookmarks', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.chrome/app_chrome/Default/Cookies', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.chrome/app_chrome/Default/Google Profile Picture.png', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.chrome/app_chrome/Default/History', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.chrome/app_chrome/Default/Login Data', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.chrome/app_chrome/Default/Preferences', 'type': 'file', 'format': 'text'},
                    {'path': '/data/data/com.android.chrome/app_chrome/Default/Top Sites', 'type': 'file', 'format': 'sqlite'},
                    {'path': '/data/data/com.android.chrome/app_chrome/Default/Web Data', 'type': 'file', 'format': 'sqlite'}
                ]
            },
            'clouddrive': {
                'onedrive': [
                    {'path': '/data/media/0/Android/data/com.microsoft.skydrive/cache/logs/*', 'type': 'dir', 'format': 'archive'}
                ]
            },
            'finder': {
                'samsungfinder': [
                    {'path': '/data/data/com.samsung.android.app.galaxyfinder/databases/Application.db', 'type': 'file', 'format': 'sqlite'}
                ]
            },
            'misc': {
                'peelsmart': [
                    {'path': '/data/data/tv.peel.app/databases/peel', 'type': 'file', 'format': 'sqlite'}
                ]
            },
            'map': {
                'swissmapmobile': [
                    {'path': '/data/media/0/Android/data/com.garzotto.smma/files/smma.db.png', 'type': 'file', 'format': 'sqlite'}
                ]
            }

        },
        'media': {
            'camera': [
                {'path': '/data/media/0/DCIM/Camera/*', 'type': 'dir', 'format': 'binary'}
            ],
            'screenshot': [
                {'path': '/data/media/0/DCIM/Screenshots/*', 'type': 'dir', 'format': 'binary'}
            ],
            'download': [
                {'path': '/data/media/0/Download/*', 'type': 'dir', 'format': 'binary'}
            ],
            'voice_recorder': [
                {'path': '/data/media/0/Voice Recorder/*', 'type': 'dir', 'format': 'binary'}
            ],
            'picture': [
                {'path': '/data/media/0/Pictures/*', 'type': 'dir', 'format': 'binary'}
            ]
        }
    }