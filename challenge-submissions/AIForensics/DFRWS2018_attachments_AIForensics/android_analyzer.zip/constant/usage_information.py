
class usage_information:
    artifacts = {
        'category': 'system and app usage information',
        'paths': [
            {'path': '/data/misc/wifi/networkHistory.txt', 'type': 'file'},
            {'path': '/data/system/usagestats/0/daily/*', 'type': 'dir'},
            {'path': '/data/system/usagestats/0/monthly/*', 'type': 'dir'},
            {'path': '/data/system/usagestats/0/weekly/*', 'type': 'dir'},
            {'path': '/data/system/procstats/*', 'type': 'dir'},
            {'path': '/data/system/batterystats-daily.xml', 'type': 'file'},
            {'path': '/data/data/com.google.android.gms/files/BatterystatsDumpsysTask.gz', 'type': 'file'},
            {'path': '/data/system/notification_log.db', 'type': 'file'},
            {'path': '/data/system/recent_images/*', 'type': 'dir'},
            {'path': '/data/system/recent_tasks/*', 'type': 'dir'},
            {'path': '/data/log/rtc.log', 'type': 'file'},
            {'path': '/data/log/power_off_reset_reason.txt', 'type': 'file'},
            {'path': '/data/log/power_off_reset_reason_backup.txt', 'type': 'file'}
        ]
    }