#!/bin/sh

# Stop the bluetooth radio....
logger -p info -s "Stopping bluetooth"
/usr/sbin/hciconfig hci0 reset
/usr/sbin/hciconfig hci0 down
