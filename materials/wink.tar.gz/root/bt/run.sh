#!/bin/sh

# Start the bluetooth radio
if ! /usr/sbin/hciconfig hci0 up; then
    logger -p error "Failed to start Bluetooth radio hci0"
fi
# Set "Secure Simple Pairing" ON to allow clients to bond to us
hciconfig hci0 sspmode 1
