#!/bin/bash
#
# Start the soft-ap
#

source /usr/sbin/terminate_verify

case "$1" in
  start)
	logger -p info -s "Starting Soft-AP"
	rm /tmp/isalive

    /root/wifi/stop.sh
	if ! lsmod | grep -q dhd; then
		logger -p notice "Kernel module dhd was not running, starting it now"
		insmod /root/wifi/dhd.ko firmware_path="/root/wifi/fw_prod.bin" nvram_path="/root/wifi/nvram.conf" iface_name=wlan0 dhd_sdiod_drive_strength=8
	fi
	set_rgb 127 20 73 0 0 0 flash 250000
	wl mpc 0         # Turn off bcm4334's power control   ## UNDOCUMENTED ##
	wl down          # reset and mark adapter down (disabled)
	wl ap 1          # Set AP on
	wl channel 8
	wl wsec 0        # Set Wireless Security off
	wl wpa_auth 0    # Disable WPA
	wl maxassoc 2    # Max clients associated with device  ## UNDOCUMENTED ##
	wl up            # reinitialize and mark adapter up (operational)

	# wireless is in ap mode, set up to retry wifi connection if we have any wifi credentials
	if [ -f /database/wpa_supplicant.conf ]; then
	  crontab -c /etc/cron.d -l > /tmp/tmpcronfile
	  sed -i '/retry_wifi/d' /tmp/tmpcronfile # prevent stacking up duplicate retry_wifi jobs
	  echo "*/30 * * * * /root/wifi/retry_wifi.sh" >> /tmp/tmpcronfile
	  crontab -c /etc/cron.d /tmp/tmpcronfile
	  rm /tmp/tmpcronfile
	fi

	hwaddr="$(ifconfig wlan0 | head -1 | egrep -o '([0-9A-F]{2}:){5}[0-9A-F]{2}' | sed 's/://g')"
	randchars4="$(head -c3 </dev/urandom | uuencode -m - | \
		sed -n '2{y,aeiouAEIOU+/,0123456789YZ,;p}' | tr a-z A-Z)"
	ssid="WINKHUB-${hwaddr:6:12}-$randchars4"

	wl ssid "$ssid"
	ifconfig wlan0 192.168.0.1
	if ! pidof udhcpd >/dev/null ; then
		udhcpd -S /etc/udhcpd.conf
	fi

	# Start bluetooth
	/root/bt/run.sh

	touch /tmp/ap_mode
	;;
  stop)
	logger -p info -s "Stopping Soft-AP"

	wl mpc 0
	wl down
	wl ap 0
	wl up
	if [ ! -z "$(pidof udhcpd)" ]; then
		terminate_verify udhcpd
	fi

	rm -rf /tmp/ap_mode
	;;
  restart|reload)
	"$0" stop
	"$0" start
	;;
  *)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $?

