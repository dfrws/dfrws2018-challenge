#!/bin/bash
IFACE=$1
EVENT=$2

case $EVENT in

  CONNECTED) logger -p notice -s "Received event: $EVENT"
    set_rgb 127 83 0 0 0 0 flash 500000
    echo "ATTEMPTING_TO_GET_IP" > /tmp/connection_status
    udhcpc -i $IFACE --retries 15 --timeout 3 --syslog --tryagain 10 -R
  ;;

  DISCONNECTED) logger -p notice -s "Received event: $EVENT"
    source /usr/sbin/terminate_verify
    # Kill udhcpc gently so it releases our IP (the -R option must be specified at startup)
    terminate_verify udhcpc
    set_rgb 127 127 0 0 0 0 flash 250000
    echo "DISCONNECTED" > /tmp/connection_status
  ;;

  *) logger -p error -s "Strange event: $EVENT"
  ;;

esac

exit $?

