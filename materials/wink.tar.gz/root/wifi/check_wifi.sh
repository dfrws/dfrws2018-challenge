#!/bin/bash
FILE=/tmp/isalive

sleep 90
if [ -f $FILE ];
then
   logger -p debug "Network is up. Not launching ap_mode again."

   # remove cron job from crontab
   crontab -c /etc/cron.d -l > /tmp/tmpcronfile
   sed -i '/retry_wifi/d' /tmp/tmpcronfile
   crontab -c /etc/cron.d /tmp/tmpcronfile
   rm /tmp/tmpcronfile
else
   logger -p info -s "File $FILE does not exist. Launching ap_mode."
   /root/wifi/run_ap.sh start
fi
