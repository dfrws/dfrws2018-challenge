#!/bin/sh

EXITCODE=0

if pidof wpa_supplicant >/dev/null; then
    if ! /usr/sbin/wpa_cli -p/var/run/wpa_supplicant terminate; then
            logger -p error "Failed to terminate wpa_supplicant"
            EXITCODE=$((EXITCODE+1))
    fi
fi
if pidof wpa_cli >/dev/null; then
    if ! /usr/sbin/wpa_cli -p/var/run/wpa_supplicant quit; then
            logger -p error "Failed to quit wpa_supplicant"
            EXITCODE=$((EXITCODE+1))
    fi
fi

exit $EXITCODE
