#!/bin/sh

if [ -f /database/wpa_supplicant.conf ]; then
    logger -p debug "Starting wifi network"
    set_rgb 127 127 0 0 0 0 flash 250000
    echo "ATTEMPTING_TO_CONNECT" > /tmp/connection_status
    lsmod | grep dhd
    if [ $? -eq 1 ]; then
        logger -p notice "Kernel module dhd was not running, starting it now"
        insmod /root/wifi/dhd.ko firmware_path="/root/wifi/fw_prod.bin" nvram_path="/root/wifi/nvram.conf" iface_name=wlan0 dhd_sdiod_drive_strength=8
    fi
    
    /root/wifi/wl mpc 0
    /root/wifi/wl band b    # so we don't try to join a 5GHz network
    if ! /root/wifi/wl up; then
        logger -p crit "Failed to bring up wireless interface"
    fi
    
    if ! /usr/sbin/wpa_supplicant -iwlan0 -Dwext -c/database/wpa_supplicant.conf -B; then
        logger -p crit "Failed to initialize wpa_supplicant"
        echo "FAIL_INIT_WPA_SUPP" > /tmp/connection_status
        exit 1
    elif ! /usr/sbin/wpa_cli -iwlan0 -p/var/run/wpa_supplicant -a/root/wifi/wpa_action.sh -B; then
        logger -p error "Failed to initialize wpa_cli"
        echo "FAIL_INIT_WPA_CLI" > /tmp/connection_status
        exit 1
    fi

    exit 0
else
    logger -p warn "Tried to start wireless without /database/wpa_supplicant.conf"
    exit 1
fi