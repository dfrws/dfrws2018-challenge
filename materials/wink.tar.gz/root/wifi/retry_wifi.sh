#!/bin/ash -x

logger "attempting wifi reconnect..."

/root/wifi/run_ap.sh stop > /dev/null 2>/dev/null

/etc/init.d/S41wireless start > /dev/null 2>/dev/null

/root/wifi/join-timeout.sh > /dev/null 2>/dev/null

