#!/bin/bash
FILE=/database/token

# we rely on the hub process to remove the token file IF an oauth file already exists. However
# the hub process only performs this check during start up. Therefore we must restart the
# hub process to ensure the token file is exchanged or removed before the end of our timeout.
monit restart hub
sleep 120
if [ -f $FILE ];
then
   logger -p notice -s "Token $FILE still exists, hub.c hasn't connected to Wink. Starting AP"
   /root/wifi/run_ap.sh start
else
   logger -p info "File $FILE does not exist, hub.c must have deleted if after connecting to Wink. Stopping BT."
   /root/bt/stop.sh
fi
