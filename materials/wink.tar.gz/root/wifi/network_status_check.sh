#!/bin/bash
ALIVEFILE=/tmp/isalive
STATUSFILE=/tmp/network_status

WINKAPP_SERVER=winkapp.com
GOOGLE_DNS_SERVER=8.8.8.8

CONNECTION_GOOD=0
AVAILABLE_BUT_NOT_CONNECTED=1
WIFI_DOWN=2
WINK_SERVER_DOWN=3
INTERNET_DOWN=4

if [ -f $ALIVEFILE ] ; then
    if ping -q -w 1 -c 1 `ip r | grep default | cut -d ' ' -f 3` \
	> /dev/null ; then
	if ping -q -w 1 -c 1 $WINKAPP_SERVER > /dev/null ; then
	    logger -p info -s "Connnected to Wink server"
	    echo "$CONNECTION_GOOD" > $STATUSFILE
	    exit $CONNECTION_GOOD
	else
	    if ping -q -w 1 -c 1 $GOOGLE_DNS_SERVER > /dev/null ; then
		logger -p warn -s "Cannot connect to Wink server"
		echo "$WINK_SERVER_DOWN" > $STATUSFILE
		exit $WINK_SERVER_DOWN
	    else
		logger -p warn -s "Cannot connect to the internet"
		echo "$INTERNET_DOWN" > $STATUSFILE
		exit $INTERNET_DOWN
	    fi
	fi
    else
	logger -p warn -s "Network unavailable"
	echo "$WIFI_DOWN" > $STATUSFILE
	exit $WIFI_DOWN
    fi

else
    for network in $( cat /database/wpa_supplicant.conf | grep ssid | \ 
	grep -v scan_ssid | cut -d "\"" -f 2 )
    do
	if iwlist wlan0 scan | grep $network > /dev/null ; then
	    logger -p info -s "Network $network available but not connected"
	    echo $AVAILABLE_BUT_NOT_CONNECTED
	    exit $AVAILABLE_BUT_NOT_CONNECTED
	fi
    done

    logger -p warn -s "No networks available"
    echo "$WIFI_DOWN" > $STATUSFILE
    exit $WIFI_DOWN
fi

