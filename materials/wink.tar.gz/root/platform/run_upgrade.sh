#!/bin/bash
FILE=/tmp/isalive

while [ ! -e $FILE ];
do
	echo "waiting for $FILE"
	sleep 1
done

/root/platform/upgrade.sh

