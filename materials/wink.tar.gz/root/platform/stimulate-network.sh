#!/bin/bash

while true
do
    echo "Kicking network interface..."
    iwconfig > /dev/null 2>&1
    sleep 15
done
