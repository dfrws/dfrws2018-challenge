#!/bin/sh -e
#set -x

COPROC_UPDATER=/usr/sbin/lutron-coproc-firmware-update-app
COPROC_TTY_DEVICE=/dev/ttySP2

DATABASE_DIR=/database
DEFAULT_DATABASE_DIR=/database_default
DATABASE_FILE_NAME=lutron-db.sqlite
CONVERSION_SCRIPT_DIR=${DEFAULT_DATABASE_DIR}/lutrondb-patches/conversion-scripts
CONVERSION_SCRIPT_NAME=existing-db-converter.sh
FLAG_FILE_LOCATION=${DATABASE_DIR}/lutron.d

DATABASE_FILE=${DATABASE_DIR}/${DATABASE_FILE_NAME}
DEFAULT_DATABASE_FILE=${DEFAULT_DATABASE_DIR}/${DATABASE_FILE_NAME}
TEMP_DATABASE_FILE=/${DATBASE_DIR}/tmp-${DATABASE_FILE_NAME}
CONVERSION_SCRIPT=${CONVERSION_SCRIPT_DIR}/${CONVERSION_SCRIPT_NAME}
DATABASE_CONVERTED_HASH_FILE=${FLAG_FILE_LOCATION}/database-converted

EXPECTED_COPROC_VERSION_FILE=/etc/lutron.d/coproc-os-version
PROGRAMMED_COPROC_VERSION_FILE=${FLAG_FILE_LOCATION}/coproc-os-version-programmed


ERROR_MESSAGE=""

# catch and log any errors and clean up any state
onExit()
{
   # clean  up the temporary files created during the database conversion
   rm -rf ${TEMP_DATABASE_FILE}

   if [ "${ERROR_MESSAGE}" != "" ]; then
      logger -p error -s "${ERROR_MESSAGE}" " - Exiting Lutron component update script."
      exit 1
   fi
}

trap onExit EXIT

####################################
# Set up the location for flag files
####################################
if [ ! -d ${FLAG_FILE_LOCATION} ]; then
   mkdir -p ${FLAG_FILE_LOCATION}
fi

########################
# Update the coprocessor
########################

# Check the expected coproc version against the reported version.
# If they're different, update the coproc.
EXPECTED_COPROC_VERSION=$(cat ${EXPECTED_COPROC_VERSION_FILE} 2> /dev/null || true)
PROGRAMMED_COPROC_VERSION=$(cat ${PROGRAMMED_COPROC_VERSION_FILE} 2> /dev/null || true)
ERROR_MESSAGE="Failed to query the Lutron coprocessor os version"
if [ "${EXPECTED_COPROC_VERSION}" != "${PROGRAMMED_COPROC_VERSION}" ]; then
   logger -p info -s "Lutron coprocessor firmware update required..."
   #start flash led red
   set_rgb 100 0 0 0 0 0 flash 250000
   # Make one attempt to update the coprocessor; if it fails, we'll bail out on the update.
   ERROR_MESSAGE="Failed updating the Lutron coprocessor"
   rm -f ${PROGRAMMED_COPROC_VERSION_FILE}
   sync
   ${COPROC_UPDATER} ${COPROC_TTY_DEVICE}
   cp ${EXPECTED_COPROC_VERSION_FILE} ${PROGRAMMED_COPROC_VERSION_FILE}
   sync
   logger -p info -s "Successfully updated Lutron coprocessor firmware."
fi

######################
# Convert the Database
######################

# Check to see if we should convert the database. If the database conversion flag
# is set to the hash of the default database, then we know we've applied all
# conversions for this database.
ERROR_MESSAGE="Could not verify Lutron default database hash."
EXPECTED_DATABASE_HASH=$(cat ${DATABASE_CONVERTED_HASH_FILE} 2> /dev/null || true)
ACTUAL_DATABASE_HASH=$(md5sum ${DEFAULT_DATABASE_FILE})
if [ -z "${EXPECTED_DATABASE_HASH}" -o -z "${ACTUAL_DATABASE_HASH}" -o "${EXPECTED_DATABASE_HASH}" != "${ACTUAL_DATABASE_HASH}" ]; then
   logger -p info -s  "Lutron database conversion required..."
   # First, copy the active database to a temporary location.
   ERROR_MESSAGE="Lutron: could not create temporary database file."
   cp ${DATABASE_FILE} ${TEMP_DATABASE_FILE}

   # now run the conversion on the temporary file.
   ERROR_MESSAGE="Error in Lutron database conversion."
   ${CONVERSION_SCRIPT} -d ${DEFAULT_DATABASE_FILE} -a ${TEMP_DATABASE_FILE} -c ${CONVERSION_SCRIPT_DIR} -q

   # Overwrite the old copy with the converted copy.
   ERROR_MESSAGE="Failed to overwrite the old Lutron database."
   mv ${TEMP_DATABASE_FILE} ${DATABASE_FILE}

   # The conversion completed successfully (otherwise we would have exited due to -e)
   # so save a hash of the default database so we can check it the next time around.
   md5sum ${DEFAULT_DATABASE_FILE} > ${DATABASE_CONVERTED_HASH_FILE}
   sync
   logger -p info -s  "Successfully converted Lutron database."
fi

ERROR_MESSAGE=""