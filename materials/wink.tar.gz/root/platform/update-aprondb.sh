#!/bin/sh

report () {
    printf >&2 "$@"
}

die () {
    report "$@"
    exit 1
}

usage_and_die () {
    cat >&2 <<__END
Usage: $0 db_file upgrade_dir/ target_version

Upgrade Apron database to the target schema version number.

The schema version number is a positive integer that increases by 1 for each
database schema change.
__END
    exit 1
}

is_numeric () {
    case "$1" in
        *[^0-9]*)
            return 1
            ;;
    esac
    return 0
}

sql () {
    # The -bail flag ensures we abort on error.  This is critical.
    sqlite3 -bail "$db_file" "$@"
}

get_aprondb_version () {
    local version

    # Are we looking at an Apron database?
    sql 'select 1 from masterDevice limit 0;' >/dev/null 2>&1 || return 1

    # Older database schemas do not have a version table.
    # They will be marked as version 0.
    version="$(sql 2>/dev/null 'select version from versionHistory order by rowid desc limit 1;')" && [ -n "$version" ] || version=0
    printf "%s" "$version"
}

do_upgrades () {
    local from to upfile result trans sqlout
    for i in "$@" ; do
        from="${i%%_*}"
        to="${i##*_}"
        report "Upgrade %d => %d ...\n" "$from" "$to"
        upfile="$upgrade_dir/upgrade_${i}.sql"

        result=
        for trans in YES "" ; do
            if
                sqlout="$(sql 2>&1 <<__END
${trans:+BEGIN TRANSACTION;}
.read "$upfile"
INSERT INTO versionHistory (version) VALUES ('$to');
SELECT "%%UPGRADE-SCRIPT-FINISHED%%";
${trans:+COMMIT;}
__END
                )"
            then
                if [ -n "$trans" ] ; then
                    report "... WARN: No transaction controls in %s" "$upfile"
                fi
                result=OK
                break
            elif
                printf "%s\n" "$sqlout" | \
                    grep -q '^Error.*transaction within a transaction'
            then
                [ -n "$trans" ] && \
                    report "... Good; transaction controls detected.\n"
            elif
                printf "%s\n" "$sqlout" | \
                    grep -q '^%%UPGRADE-SCRIPT-FINISHED%%'
            then
                if [ -n "$trans" ] ; then
                    # If the script finished but the final COMMIT failed, it
                    # either mean operational failure, or the script file
                    # contains a COMMIT without a BEGIN TRANSACTION.  If the
                    # transaction actually failed, we'll detect that later.
                    report "... WARN: Error on final COMMIT.  Missing BEGIN TRANSACTION?\n"
                fi
                result=OK
                break
            fi
        done

        # Show the sql result output, for debugging purposes
        printf "%s\n" "$sqlout" | \
            grep -v '^%%UPGRADE-SCRIPT-FINISHED%%' | \
            sed 's/^/    /' >&2

        # Check the version number to make sure the patch applied
        if
            [ -n "$result" ] && \
            result="$(get_aprondb_version)" && \
            [ "$result" = "$to" ]
        then
            report "[-OK-] Patch %s => %s\n" "$from" "$to"
        else
            if [ "$result" = "$from" ] ; then
                report "... Patch seems okay but didn't apply.  Missing COMMIT?\n"
            else
                report "*** PATCH DID SOMETHING FUNKY!  CORRUPTED DATABASE? ***\n"
            fi
            report "[FAIL] Patch %s => %s\n" "$from" "$to"
            return 1
        fi
    done
    return 0
}

#-----MAIN SCRIPT-----

db_file="$1"
upgrade_dir="$2"
target_version="$3"

if [ -z "$db_file" -o -z "$upgrade_dir" -o -z "$target_version" ] ; then
    usage_and_die
fi

[ -f "$db_file" ] || die "Database file '%s' not found\n" "$db_file"

version="$(get_aprondb_version)" || \
    die "File '%s' does not look like an Apron database file\n" "$db_file"

is_numeric "$version" || \
    die "Database reports bizarre version %s; cannot upgrade\n" "$version"

report "Starting database version is %d\n" "$version"

if [ "$target_version" = "latest" ] ; then
    upgrade_path=
    curr="$version"
    while
        i="$(expr "$curr" + 1)" &&
            [ -f "$upgrade_dir/upgrade_${curr}_${i}.sql" ]
    do
        upgrade_path="${upgrade_path} ${curr}_${i}"
        curr="$i"
    done
    target_version="$curr"
else
    is_numeric "$target_version" || \
        die "Cannot upgrade to bizarre target version %s\n" "$target_version"

    [ "$version" -le "$target_version" ] || \
        die "Database is version %d; cannot downgrade\n" "$version"

    ### Verify upgrade path before starting
    upgrade_path=
    prev="$version"
    for i in $(seq "$version" "$target_version") ; do
        [ "$i" = "$version" ] && continue

        if [ ! -f "$upgrade_dir/upgrade_${prev}_${i}.sql" ] ; then
            die "No upgrade path from %d to %d\n" "$prev" "$i"
        fi
        upgrade_path="${upgrade_path} ${prev}_${i}"

        prev="$i"
    done
fi

if [ -z "$upgrade_path" ] ; then
    report "Nothing to do\n"
    exit 0
fi

db_old="${db_file}.old"
rm -f "$db_old"
sql ".backup main '${db_old}'"

if ! res="$(do_upgrades $upgrade_path)"
then
    report "Error upgrading from %s to %s\n" \
        "${res%%_*}" "${res##*_}"
fi
