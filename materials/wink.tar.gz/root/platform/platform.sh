#!/bin/bash
#set -x

# define our logging function
log_output()
{
    echo "$1"
    echo "$1" >> /database/upgrade_log
    logger -t plat-upgd-script "$1"
}

#check for corrupt image
kernel_cmd_line=`cat /proc/cmdline | grep badapp`
if [ "" != "$kernel_cmd_line" ]; then
    rm -rf /database/cf_fver2 /database/cf_fver3
fi
kernel_cmd_line=`cat /proc/cmdline | grep badupdater`
if [ "" != "$kernel_cmd_line" ]; then
    rm -rf /database/cf_fver0 /database/cf_fver1
fi

#bring in the configuration
source /root/platform/platform.config

#end() - exit the script. assume everything is handled and set appropriatly.
# end 0 means do nothing with LED, end 1 means set LED error
end()
{
    log_output "END"

    # upload the logfile
    /usr/bin/log-upload-test -k -f /database/upgrade_log

    if [ $1 = 1 ]; then
       #bad, led solid red
       log_output "Upgrade failed..."
	   set_rgb 200 0 0
    fi	

	# sleep briefly to show state and then reboot
	sync
	sync
	sleep 3
    reboot
    exit 0
}

#cross platform function to read vars from flash
flash_get()
{
    eval "$1=`cat /database/$2`"
    if [ 0 != $? ]; then
	$1=""
    fi
    #Test using local file 
    #tmp=$2
    #eval "$1=`cat /tmp/flash.bin | grep ''$tmp'' | awk -F '=' {'print $2'} | tr -d '\r'`" 
}

#cross platform function to write vars to flash
flash_set()
{
    log_output "$2" > /database/$1
    sync
    sync
    #Test using local file
    #tmp=$1
    #tmp2=$2
    #cat /tmp/flash.bin | grep -v $1 >> /tmp/flash.new
    #log_output "$1=$2" >> /tmp/flash.new
    #mv /tmp/flash.new /tmp/flash.bin
}

set_boot_application()
{
    #set the boot var in CFE
    flash_set DO_UPDATE $app_boot
}

set_boot_updater()
{
    #set the boot var in CFE
    flash_set DO_UPDATE $upgrade_boot
}

wait_on_network()
{
    #launch wireless if not up
    tmp=`ifconfig $eth_dev | grep "inet addr"`
    if [ "" == "$tmp" ]; then
    cd /root/wifi
    ./run.sh
    cd -
    fi

    #loop with one second delay until eth device gets an address
    for (( timer=0 ; timer<$eth_timeout; timer++ ))
    do
        sleep 1
        tmp=`ifconfig $eth_dev | grep "inet addr"`
        if [ "" != "$tmp" ]; then
            return 0
        fi
    done
    return 1
}

#update fuction for package type 0, NAND flash with curl
update0()
{
    # get the file size and verify
    success_url="${read_sw_pkg_url}/${read_fsrc[$idx]}"
    file_len=`curl ${curl_args} -I ${read_sw_pkg_url}/${read_fsrc[$idx]} | grep "Content-Length" | awk {'print $2'}`
    if [ "" = "${file_len}" ]; then
	    log_output "Could not open $read_sw_pkg_url"
        end 1
    fi

    #Flash the package
    flash_erase ${read_fdest[$idx]} 0 0

    #make sure it worked
    if [ 0 != $? ]; then
        log_output "Could not erase flash"
        end 1
    fi
    
    #wait for everything to settle
    sleep 1

    #write to flash
    rm -rf /tmp/test.md5
    curl ${curl_args} ${success_url} | md5pipe /tmp/test.md5 | nandwrite -p -m -s ${read_foff[$idx]} ${read_fdest[$idx]} -
    if [ 0 != $? ]; then
	   log_output "Could not write flash"
	   end 1
    fi

    #sync and wait again for things to settle
    sync
    sync
    sync
    sleep 1

    md5_check=`cat /tmp/test.md5`
    if [ "$md5_check" != "${read_md5sum[$idx]}" ]; then
	flash_set cf_fver$idx 00.00.00-git{unknown}
	log_output "MD5 did not match"
	end 1
    fi

    #the update succeeeded update the version info
    flash_set cf_fver$idx ${read_fver[$idx]}    

}

#update fuction for package type 1, UBIFS package
update1()
{
    # get the file size and verify
    success_url="${read_sw_pkg_url}/${read_fsrc[$idx]}"
    file_len=`curl ${curl_args} -I ${read_sw_pkg_url}/${read_fsrc[$idx]} | grep "Content-Length" | awk {'print $2'}`
    if [ "" = "${file_len}" ]; then
	    log_output "Could not open $read_sw_pkg_url"
        end 1
    fi

    #write to flash
    for i in 1; do
        COUNTER=0
        while [  $COUNTER -lt $max_flash_tries ]; do
            curl --stderr /tmp/upgrade_stderr_curl ${curl_args} ${success_url} | md5pipe /tmp/test.md5 | ubiformat ${read_fdest[$idx]}  -y -f - -S ${file_len}
            if [ 0 == $? ]; then
                # success, break out of the outer for loop
                break 2
            fi
            iwconfig >> /tmp/upgrade_stderr_curl
            log_output "$(cat /tmp/upgrade_stderr_curl)"
            let COUNTER=COUNTER+1
            log_output "Unable to format flash, attempt $COUNTER"
            /root/wifi/stop.sh
            sleep 2
            wait_on_network
            # flash LED red again before the retry
            set_rgb 100 0 0 0 0 0 flash 250000
        done
        # Failed all attempts to upgrade, try one last time with stimulate-network script
        /root/platform/stimulate-network.sh > /dev/null 2>&1 &
        curl --stderr /tmp/upgrade_stderr_curl ${curl_args} ${success_url} | md5pipe /tmp/test.md5 | ubiformat ${read_fdest[$idx]}  -y -f - -S ${file_len}
        if [ 0 == $? ]; then
            break
        fi
        iwconfig >> /tmp/upgrade_stderr_curl
        log_output "$(cat /tmp/upgrade_stderr_curl)"
        log_output "Unable to format flash, fatality"
        end 1
    done

    #sync and wait again for things to settle
    sync
    sync
    sync
    sleep 1

    md5_check=`cat /tmp/test.md5`
    if [ "$md5_check" != "${read_md5sum[$idx]}" ]; then
	flash_set cf_fver$idx 00.00.00-git{unknown}
	log_output "MD5 did not match"
	end 1
    fi

    #the update succeeeded update the version info
    flash_set cf_fver$idx ${read_fver[$idx]}    

}

set_date()
{
    for (( timer=0 ; timer<$ntpd_retry; timer++ ))
    do
        datecheck=`date | grep '1970'`
        if [ "" != "$datecheck" ]; then
            ntpdate $ntpserver1 $ntpserver2
            if [ 0 = $? ]; then
	        return 0
            fi
	else
            return 0
        fi
    done
    return 1
}

get_update_config()
{
    #manifest file substitution, for DEV, early RETURN
	if [ -e /database/cf_manifest_subst ]; then
	    cp /database/cf_manifest_subst /tmp/temp/upgrade.txt
	    log_output "manifest file substitution..."
	    return 0
	fi

    # get the file size and verify
    file_len=`curl ${curl_args} -I $sw_pkg_url | grep "Content-Length" | awk {'print $2'}`
    if [ "" = "${file_len}" ]; then
	log_output "Could not open $sw_pkg_url"
	return 1
	else
	     curl $curl_args $sw_pkg_url > /tmp/temp/upgrade.txt
	  	 md5_download=$(md5sum /tmp/temp/upgrade.txt)
	  	 md5_download=${md5_download%% *}
	  	 #check cf_url md5 against what we downloaded
	  	 if [ "$md5_download" == "$md5_manifest" ]; then
  			log_output "md5 match..."
  		 else 
		 	log_output "md5 non-match..."
		 	#log_output "download: $md5_download"
	  	 	#log_output "manifest: $md5_manifest"
	  	 	rm -rf /tmp/temp/upgrade.txt
	  	 	return 1
		 fi
	fi	
	
#echo "*********************************"
#cat /tmp/temp/upgrade.txt
#echo "*********************************"

    return 0
}

cleanup_update_config()
{
    rm -rf /tmp/temp
}

