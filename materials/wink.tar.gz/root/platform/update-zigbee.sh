#!/bin/sh

latest_version="5.1.2.1"
version_file="/database/zigbee-version.txt"
ncp_image_dir="/root/platform/zigbee-ncp-image"

source /usr/sbin/terminate_verify

################################

# Run ZigBeeHACoord for maximum 1 second.
# This is for testing '-n' values; if we give the wrong value for '-n' it will
# hang forever, so use job control to time out.
hacoord_test () {
    (
        set -m
        exec 2>/dev/null
        ZigBeeHACoord "$@" -p ttySP4 </dev/null &
        sleep 2
        kill -9 %%
    )
}

n_mode=
current_version=

# Different firmware versions may use different flow control methods.
# Test both schemes ("-n 0" and "-n 1") and use whichever one works.
# Global variables set:
# - n_mode              The correct value for the -n parameter
# - current_version     The version reported by the NCP chip
detect_ncp () {
    local ver i
    for i in 0 1 ; do
        ver="$(hacoord_test -n "$i" | grep '^ezsp ver')" && break
    done
    [ -z "$ver" ] && return 1

    n_mode="$i"

    # Version string example:
    # ezsp ver 0x04 stack type 0x02 stack ver. [5.1.0 GA build 49]
    current_version="$(printf "%s" "$ver" |
        sed -n '1{ s/.*\[\([^ ]\+\)[^]]*\].*/\1/ ; p}')"

    # Set return value.  We succeed if we got the version number.
    [ -n "$current_version" ]
}

# Compare two version strings.  Write numeric result on stdout.
# -1    $1 < $2
# 0     $1 = $2
# 1     $1 > $2
compare_versions () {
    printf "%s %s\n" "$1" "$2" | awk '{
        x = 0;
        split($1, a, ".");
        split($2, b, ".");
        for (i = 1; i <= 4; i++)
            if (a[i] < b[i]) { x =-1; break; }
            else if (a[i] > b[i]) { x = 1; break; }
        print x;
        }'
}


do_flash=0

# Check for existence of version file
if [ -f "$version_file" ]; then
   read current_version <"$version_file"
   if [ "$(compare_versions "$latest_version" "$current_version")" -gt 0 ]; then
      do_flash=1
   fi
else
   do_flash=1
fi

if [ "$do_flash" -eq "1" ]; then
    setrgb -s 5 -R -p 10 ff0000:50 000000:50
    terminate_verify ZigBeeHACoord

    printf "%s\n" "Checking actual Zigbee NCP version: "
    detect_ncp  # updates $current_version
    printf " --> %s\n" "$current_version"

    if [ "$current_version" != "$latest_version" ]; then
        echo "Flashing version $latest_version firmware to Zigbee NCP"
        echo "plugin ota-client bootload 0" |
            ZigBeeHACoord -n "$n_mode" -p ttySP4 \
                -I "${ncp_image_dir:+"$ncp_image_dir/"}$latest_version"
        detect_ncp  # updates $current_version
    else
        do_flash=0
    fi

    # current_version may have changed
    if [ "$current_version" = "$latest_version" ]; then
        if [ "$do_flash" = 1 ] ; then
            echo "Flash successful!"
        else
            echo "Zigbee NCP is already up to date; updating version file"
        fi
        printf " --> %s\n" "$current_version"
        echo "$latest_version" > "$version_file"
    else
        echo "Flash failed!"
        rm "$version_file"
    fi
    setrgb -s 5
else
    echo "Zigbee NCP is up to date"
fi
