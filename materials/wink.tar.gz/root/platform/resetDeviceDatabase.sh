#!/bin/bash

# This is the script to revert the HUB DB to a factory default state.  It will
# delete the existing database and reboot.  All will be restored during the reboot.
# It utilizes the priority LED channel (14) which is not impacted by the hub process
# or other scripts calling set_rgb

setrgb -R -s14 -p9001 ff0000:125 0000ff:125

aprontest --zwave_controller_reset
sleep 5

monit -g wink-services stop
sleep 7

rm /database/apron.db
rm /var/lib/database/apron.db
rm /database/lutron-db.sqlite

sync
sync
sleep 2

reboot