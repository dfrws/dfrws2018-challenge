#!/bin/bash
#set -x

#give user chance to cancel
echo "Press enter to cancel update..."
read -t2 stdin
if [ "$?" = "0" ]; then
    exit 0
fi

if [[ ! -e /database/cf_url || ! -e /database/cf_cert ]]; then
    #exit update, and resume without reboot
    logger -p err -s "URL or certificate information missing, update canceled."
    exit 0
fi

monit -g wink-services stop

#start flash led yellow
set_rgb 100 100 0 0 0 0 flash 250000

#wait up to 30 sec for apron to go down
APRON_TIMER=0
while [  $APRON_TIMER -lt 30 ]; do
    if pidof aprond >/dev/null; then
        let APRON_TIMER=APRON_TIMER+1
        sleep 1;
    else
        break;
    fi
done

#bring in the platform
source /root/platform/platform.sh

# temporary hack: move apron.db out of rootfs and to /database/apron.db
move_rootfs_db_to_database()
{
    if [ -e /var/lib/database/apron.db ]; then
        rm /database/apron.db
        if sqlite3 /var/lib/database/apron.db ".backup /database/apron.db"; then
            log_output "backed up /var/lib/database/apron.db to /database"
            sync; sleep 1; sync
            return 0
        else
            log_output "failed to move /var/lib/database/apron.db to /database"
            return 1
        fi
    else
        log_output "no db in /var/lib/database/apron.db"
        return 0
    fi
}

do_update()
{
    #idx is our index to update. Check if we can update this index. 0 = YES
    if [ "" = "${canupdate[$idx]}" ]; then
        #find what function to use for the update based on type

        #generate function name ex. update0
		update_func="update${read_ftype[$idx]}"

		#make sure it exists
		declare -f $update_func > /dev/null 2>&1
		if [ 0 = $? ]; then
            #start flash led red
	    	set_rgb 100 0 0 0 0 0 flash 250000

            #call it
            $update_func

	    	#signify update was done
	    	didupdate=1
		else
	    	log_output "no updater function"
		fi
    else
	   log_output "update skipped"
    fi

}

#check all package versions and update accordingly
check_versions()
{
    didupdate=0

    #check the bootloaders first
    for (( idx=0 ; idx<num_bootloaders ; idx++ ))
    do
	if [ "${read_fver[$idx]}" != "${fver[$idx]}" ]; then
	    do_update
	fi
    done
	
    #if we did a bootloader update in bootloader, reboot into the new bootloader
    if [ "$SCRIPT_VERSION" != "APP" ]; then
		if [ 1 = $didupdate ]; then
		    #blink green before reboot
		    set_rgb 0 200 0 0 0 0 flash 500000
		    end 0
		fi
    fi
    
    #if the bootloader is up to date, check the app kernel and rootfs
    for (( idx=num_bootloaders ; idx<read_fparts ; idx++ )); do
        if [ "${read_fver[$idx]}" != "${fver[$idx]}" ]; then
            if [ "$SCRIPT_VERSION" != "APP" ]; then
                do_update
            else
                if move_rootfs_db_to_database; then
                    #blink green before reboot
                    set_rgb 0 200 0 0 0 0 flash 500000
                    set_boot_updater
                    end 0
                else
                    #failed to move db
                    set_boot_application
                    end 1
                fi
            fi
        fi
    done
}

#get versions from flash

forced_update=0
for (( idx=0 ; idx<fparts ; idx++ ))
do
    flash_get fver[$idx] cf_fver$idx

    if [ "${fver[$idx]}" = "" ]; then
          log_output "No valid version for part $idx, set to 00.00.00-git{unknown}"
          fver[$idx]="00.00.00-git{unknown}"
          forced_update=1
    fi

done

#Get access to the upgrade file and clear it
cd /tmp
if [ ! -d temp ]; then
    mkdir /tmp/temp
fi
rm -rf /tmp/temp/upgrade.txt

#make sure the network is up
wait_on_network
if [ 0 != $? ]; then
    log_output "network not coming up. booting into app."
    set_boot_application
    end 1
fi

#make sure time is set (for SSL)
set_date
if [ 0 != $? ]; then
    log_output "unable to set date."
    set_boot_application
    end 1
fi

#get manifest file
get_update_config
if [ 0 != $? ]; then
    set_boot_application
    end 1
fi

#Read the new values from the file
read_board_id=`cat /tmp/temp/upgrade.txt | grep 'board_id' | awk -F '=' {'print $2'} | tr -d '\r'`

read_group_id=`cat /tmp/temp/upgrade.txt | grep 'group_id' | awk -F '=' {'print $2'} | tr -d '\r'`
if [ "$read_group_id" = "" ]; then
    log_output "groupID not found. reboot into app."
    set_boot_application
    cleanup_update_config
    end 1
else
    let "read_group_id = $read_group_id"   #convert to integer
fi

read_sw_pkg_url=`cat /tmp/temp/upgrade.txt | grep 'sw_pkg_url' | awk -F '=' {'print $2'} | tr -d '\r'`

read_fparts=`cat /tmp/temp/upgrade.txt | grep 'fparts' | awk -F '=' {'print $2'} | tr -d '\r'`

if [ "$read_fparts" = "" -o "$read_fparts" = "0" ]; then
    log_output "fparts is zero or not found. reboot into app."
    set_boot_application
    cleanup_update_config
    end 1
else
    let "read_fparts = $read_fparts"   #convert to integer	
fi

for (( idx=0 ; idx<read_fparts ; idx++ ))
do
    read_fdest[$idx]=`cat /tmp/temp/upgrade.txt | grep ''fdest$idx'' | awk -F '=' {'print $2'} | tr -d '\r'`

    read_fver[$idx]=`cat /tmp/temp/upgrade.txt | grep ''fver$idx'' | awk -F '=' {'print $2'} | tr -d '\r'`

    if [[ "${read_fver[$idx]}" = "" ]]; then
	log_output "No valid version for part $idx. Reboot into app."
	set_boot_application
	cleanup_update_config
	end 1
    fi

    read_foff[$idx]=`cat /tmp/temp/upgrade.txt | grep ''foff$idx'' | awk -F '=' {'print $2'} | tr -d '\r'`

    read_ftype[$idx]=`cat /tmp/temp/upgrade.txt | grep ''ftype$idx'' | awk -F '=' {'print $2'} | tr -d '\r'`

    read_fsrc[$idx]=`cat /tmp/temp/upgrade.txt | grep ''fsrc$idx'' | awk -F '=' {'print $2'} | tr -d '\r'`

    read_md5sum[$idx]=`cat /tmp/temp/upgrade.txt | grep ''md5sum$idx'' | awk -F '=' {'print $2'} | tr -d '\r'`
done

cleanup_update_config

#check the upgrade parameters

if [ $group_id -le $read_group_id -o "1" = "$forced_update" ]; then
	log_output "Group Ids Pass..."
	check_versions
else
	log_output "Group Ids do not match..."
fi
	
#set boot back to the application
if [ "$SCRIPT_VERSION" != "APP" ]; then
    set_boot_application
    #blink green before reboot
    set_rgb 0 200 0 0 0 0 flash 500000
else
    #solid green for successful update
    set_rgb 0 200 0
fi
end 0
