-- Upgrade apron.db from version 12 to 13.
BEGIN TRANSACTION;

-- Add support for attributes 17 and 18 on battery powered linear siren
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(335, 8197, 1283, 0, 17, 'Siren_Strobe_Mode');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(335, 8197, 1283, 1, 18, 'Auto_Stop_Time');

-- Add new config params for z-wave lever locks
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25419, 20556, 3, 19, 'Beeper_On_Off');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25419, 20556, 4, 20, 'Vacation_Mode');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25419, 20556, 15, 23, 'Auto_Lock_On_Off');

COMMIT;
