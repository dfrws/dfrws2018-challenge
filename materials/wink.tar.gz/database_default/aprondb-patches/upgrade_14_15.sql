-- Upgrade apron.db from version 14 to 15.
BEGIN TRANSACTION;

-- Add device specific configuration parameters to supported devices
DELETE FROM  "zwaveDeviceConfigurationParameters" WHERE "manufacturerNum"=335 AND "productType"=8201 AND "productNum"=0903;
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(335, 8201, 2307, 0, 17, 'Siren_Strobe_Mode');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(335, 8201, 2307, 1, 18, 'Auto_Stop_Time');

COMMIT;

