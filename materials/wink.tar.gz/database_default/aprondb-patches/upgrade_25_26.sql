-- Upgrade apron.db from version 25 to 26.
BEGIN TRANSACTION;

-- Integrated Bluetooth Device Table
CREATE TABLE integratedBluetoothDevice(
    deviceDescriptor        VARCHAR(256),
    deviceClass             INTEGER,
    manufacturerName        VARCHAR(256),
    interviewMethod	    VARCHAR(128)
);
    
-- Bluetooth Device Table
CREATE TABLE bluetoothDevice(
    masterId            INTEGER,
    bluetoothAddress    VARCHAR(40),
    deviceDescriptor    VARCHAR(256),
    deviceClass         INTEGER,
    manufacturerName    VARCHAR(256),
    manufacturerId	INTEGER,
    userDeviceName      VARCHAR(256),
    firmwareVersion	VARCHAR(128),
    paired              BOOLEAN,
    FOREIGN KEY ( masterId ) REFERENCES masterDevice( nodeId ),
    FOREIGN KEY ( deviceDescriptor, deviceClass ) REFERENCES integratedBluetoothDevice( deviceDesciptor, deviceClass )
);

-- Bluetooth Supported Attributes Table
CREATE TABLE bluetoothAttribute(
    attributeId             INTEGER,
    description             VARCHAR(256),
    dataType                VARCHAR(32),
    read_write              VARCHAR(3)
);

-- Bluetooth Device Attribute State Table
CREATE TABLE bluetoothDeviceState(
    deviceAddress       VARCHAR(40),
    attributeId         INTEGER,
    value_get           VARCHAR(256),
    value_set           VARCHAR(256),
    updateNeeded        BOOLEAN,
    lastUpdate          INTEGER,
    writeMethod		VARCHAR(128),
    readMethod		VARCHAR(128),
    FOREIGN KEY ( deviceAddress ) REFERENCES bluetoothDevice( bluetoothAddress ),
    FOREIGN KEY ( attributeId ) REFERENCES bluetoothAttribute( attributeId )
);

-- Bluetooth Device Attribute Table
CREATE TABLE bluetoothDeviceAttribute(
    deviceDescriptor        VARCHAR(256),
    attributeId             INTEGER,
    writeMethod		    VARCHAR(128),
    readMethod		    VARCHAR(128),
    FOREIGN KEY ( deviceDescriptor ) REFERENCES integratedBluetoothDevice( deviceDescriptor )
);

-- TE Link Mesh Device Table
CREATE TABLE telinkMeshDevice(
    masterId		    INTEGER,
    bluetoothAddress	    VARCHAR(40),
    telinkMeshUUID	    INTEGER,
    telinkMeshAddress	    INTEGER,
    lastConnection	    INTEGER NOT NULL DEFAULT 0
);

-- Unique constraint on bluetoothDevice and bluetoothDeviceAttribute
CREATE UNIQUE INDEX bluetoothDeviceAddress ON bluetoothDevice( bluetoothAddress );
CREATE UNIQUE INDEX bluetoothNodeAttribute ON bluetoothDeviceState( deviceAddress, attributeId );
CREATE UNIQUE INDEX telinkBluetoothMeshDevice ON telinkMeshDevice( bluetoothAddress );

-- New Bluetooth attributes
INSERT INTO bluetoothAttribute VALUES(1,'On_Off','STRING','R/W');
INSERT INTO bluetoothAttribute VALUES(2,'Level','UINT8','R/W');

-- New Bluetooth Device Attributes
INSERT INTO bluetoothDeviceAttribute VALUES('telink_mesh1',1,'c-life-write','c-life-read');
INSERT INTO bluetoothDeviceAttribute VALUES('telink_mesh1',2,'c-life-write','c-life-read');

-- Integrated Bluetooth Device Table
INSERT INTO integratedBluetoothDevice VALUES('telink_mesh1',0,'GE','c-life');

COMMIT;
