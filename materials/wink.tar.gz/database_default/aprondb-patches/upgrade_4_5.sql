-- Upgrade apron.db from version 4 to 5.
BEGIN TRANSACTION;

-- Add cluster and attributes for Simple Meter Cluster 
INSERT OR REPLACE INTO "zigbeeCluster" VALUES(1794, 'Simple Metering');

-- Cluster 0x0702, Attributes 0x0000, 0x0200, 0x0300, 0x0301, 0x0302, 0x0303, 0x0306
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1794,117633024,'ZB_CurrentSummationDelivered','ATTRIBUTE','UINT64','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1794,117633536,'ZB_Status','ATTRIBUTE','UINT8','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1794,117633792,'ZB_UnitOfMeasure','ATTRIBUTE','UINT8','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1794,117633793,'ZB_Multiplier','ATTRIBUTE','UINT32','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1794,117633794,'ZB_Divisor','ATTRIBUTE','UINT32','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1794,117633795,'ZB_SummationFormatting','ATTRIBUTE','UINT8','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1794,117633798,'ZB_MeteringDeviceType','ATTRIBUTE','UINT8','R');

INSERT OR REPLACE INTO "zigbeeDeviceType" VALUES(81,'Smart Plug');

-- Additional thermostat attributes
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681438,'ZB_ThermostatRunningMode', 'ATTRIBUTE','UINT8','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681481,'ZB_OverrideTemperature','COMMAND','FLOAT','R/W');		 
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681482,'ZB_OverrideTemperatureTimeout','ATTRIBUTE','UINT16','R/W');

-- Add Accelerometer Cluster 
INSERT OR REPLACE INTO "zigbeeCluster" VALUES(64512,'Accelerometer');

-- Add Accelerometer Attributes,  cluster ID: 0xFC00 
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(64512, 4227919872, 'ZB_AccelerometerEnable', 'ATTRIBUTE', 'BOOL', 'R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(64512, 4227919873, 'ZB_SetpointIncrementValue', 'ATTRIBUTE', 'UINT8', 'R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(64512, 4227919874, 'ZB_XAxisThreshold', 'ATTRIBUTE', 'UINT8', 'R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(64512, 4227919875, 'ZB_YAxisThreshold', 'ATTRIBUTE', 'UINT8', 'R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(64512, 4227919876, 'ZB_AcclerometerFactoryReset', 'ATTRIBUTE', 'BOOL', 'R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(64512, 4227919877, 'ZB_NetworkReportAddress', 'ATTRIBUTE', 'UINT16', 'R/W');

-- Enable level control for blinds
INSERT OR REPLACE INTO "zwaveProfiles" VALUES(38,4,3);

-- Add support for battery command class
INSERT OR REPLACE INTO "zwaveCmdClass" VALUES(128,'COMMAND_CLASS_BATTERY');
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(128,15,'ATTRIBUTE','BatteryLevel','UINT8','R',1);

-- Group support
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(4,4,'NameSupport','ATTRIBUTE','UINT8','R');

CREATE TABLE zigbeeGroup(
       groupId INTEGER PRIMARY KEY,   
       groupName VARCHAR(16)          
);

CREATE TABLE zigbeeGroupMembers(
       groupId     INTEGER,
       nodeId      INTEGER,
       PRIMARY KEY ( groupId, nodeId ),     
       FOREIGN KEY (groupId) REFERENCES zigbeeGroup (groupId)
       );

CREATE TABLE zigbeeGroupState(
       groupId     INTEGER,     
       clusterId   INTEGER,      
       attributeId INTEGER,      
       value_get   VARCHAR(256), 
       value_set   VARCHAR(256), 
       FOREIGN KEY (groupId) REFERENCES zigbeeGroup(groupId),
       FOREIGN KEY (attributeId) REFERENCES zigbeeAttribute(attributeId),
       FOREIGN KEY (clusterId) REFERENCES zigbeeCluster(clusterId)
);

COMMIT;
