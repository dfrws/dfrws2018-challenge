
-- Upgrade apron.db from version 1 to 2.
BEGIN TRANSACTION;

-- Activate Binary Sensor 
INSERT OR REPLACE INTO "zwaveCCSupport" VALUES(48,32,0,5,'SENSOR_BINARY');	
INSERT OR REPLACE INTO "zwaveCCSupport" VALUES(48,32,1,5,'ROUTING_SENSOR_BINARY');

-- This multilevel sensor device type was missing before
INSERT OR REPLACE INTO "zwaveCCSupport" VALUES(49,33,0,6,'SENSOR_MULTILEVEL');

COMMIT;
