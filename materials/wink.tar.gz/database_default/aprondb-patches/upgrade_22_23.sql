-- Upgrade apron.db from version 22 to 23.
BEGIN TRANSACTION;

-- Add support for power configuration attributes
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1,127009,'BatteryPercentRemaining','ATTRIBUTE','UINT8','R');
-- Add support for Identify attribute
INSERT OR REPLACE INTO "zigbeeCluster" VALUES(3, 'Identify Cluster');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(3,258048,'IdentifyTime','ATTRIBUTE','UINT16','R/W');
-- Add support for Waxman liquid detection
INSERT OR REPLACE INTO "zigbeeCluster" VALUES(64514, 'Waxman Liquid Detection Cluster');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(64514,4228050944,'SensitivityLevel','ATTRIBUTE','UINT8','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(64514,4228051029,'LiquidDetected','ATTRIBUTE','UINT8','R');
-- Add support for Temperature Cluster
INSERT OR REPLACE INTO "zigbeeCluster" VALUES(1026, 'Temperature Measurement Cluster');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1026,67301376,'TemperatureMeasuredValue','ATTRIBUTE','INT16','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1026,67301377,'TemperatureMinMeasuredValue','ATTRIBUTE','INT16','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1026,67301378,'TemperatureMaxMeasuredValue','ATTRIBUTE','INT16','R');

COMMIT;
