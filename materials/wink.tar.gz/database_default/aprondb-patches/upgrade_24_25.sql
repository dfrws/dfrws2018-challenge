-- Upgrade apron.db from version 24 to 25.
BEGIN TRANSACTION;

-- Add support for all multilevel sensor reading types (55 new attributes, from attr 43 to 97)

-- First, delete the entries from zwaveProfiles for multilevel sensor, which create attributes 8 + 9
-- INSERT INTO "zwaveProfiles" VALUES(49,8,8);     /* COMMAND_CLASS_SENSOR_MULTILEVEL - SENSOR_MULTILEVEL_GET */
-- INSERT INTO "zwaveProfiles" VALUES(49,8,9);     /* COMMAND_CLASS_SENSOR_MULTILEVEL - Report unit type */
DELETE FROM "zwaveProfiles" WHERE cmdClass = '49';

-- Next, create attributes for the 55 possible sensor types in this command class. All of these
-- attributes are named `MultiSensor_xx`, where `xx` is the `Sensor Type` as defined in the
-- ZW_classcmd.h header, so that we can match a sensor type to the correct attribute.

-- Command Class: 0x31 (49) COMMAND_CLASS_SENSOR_MULTILEVEL
-- Command Key: 0x04 SENSOR_MULTILEVEL_GET
-- INSERT INTO "zwaveAttribute" VALUES(cmdClass, attributeId, attr_cmd, description, dataType, read_write, commandKey)

--#define SENSOR_MULTILEVEL_GET_TEMPERATURE_VERSION_1_V7                                   0x01
INSERT INTO "zwaveAttribute" VALUES(49, 43,'ATTRIBUTE','MultiSensor_01_Temperature','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_GENERAL_PURPOSE_VALUE_VERSION_1_V7                         0x02
INSERT INTO "zwaveAttribute" VALUES(49, 44,'ATTRIBUTE','MultiSensor_02_General_Purpose_Value','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_LUMINANCE_VERSION_1_V7                                     0x03
INSERT INTO "zwaveAttribute" VALUES(49, 45,'ATTRIBUTE','MultiSensor_03_Luminance','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_POWER_VERSION_2_V7                                         0x04
INSERT INTO "zwaveAttribute" VALUES(49, 46,'ATTRIBUTE','MultiSensor_04_Power','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_RELATIVE_HUMIDITY_VERSION_2_V7                             0x05
INSERT INTO "zwaveAttribute" VALUES(49, 47,'ATTRIBUTE','MultiSensor_05_Relative_Humidity','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_VELOCITY_VERSION_2_V7                                      0x06
INSERT INTO "zwaveAttribute" VALUES(49, 48,'ATTRIBUTE','MultiSensor_06_Velocity','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_DIRECTION_VERSION_2_V7                                     0x07
INSERT INTO "zwaveAttribute" VALUES(49, 49,'ATTRIBUTE','MultiSensor_07_Direction','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_ATMOSPHERIC_PRESSURE_VERSION_2_V7                          0x08
INSERT INTO "zwaveAttribute" VALUES(49, 50,'ATTRIBUTE','MultiSensor_08_Atmospheric_Pressure','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_BAROMETRIC_PRESSURE_VERSION_2_V7                           0x09
INSERT INTO "zwaveAttribute" VALUES(49, 51,'ATTRIBUTE','MultiSensor_09_Barometric_Pressure','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_SOLAR_RADIATION_VERSION_2_V7                               0x0A
INSERT INTO "zwaveAttribute" VALUES(49, 52,'ATTRIBUTE','MultiSensor_10_Solar_Radiation','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_DEW_POINT_VERSION_2_V7                                     0x0B
INSERT INTO "zwaveAttribute" VALUES(49, 53,'ATTRIBUTE','MultiSensor_11_Dew_Point','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_RAIN_RATE_VERSION_2_V7                                     0x0C
INSERT INTO "zwaveAttribute" VALUES(49, 54,'ATTRIBUTE','MultiSensor_12_Rain_Rate','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_TIDE_LEVEL_VERSION_2_V7                                    0x0D
INSERT INTO "zwaveAttribute" VALUES(49, 55,'ATTRIBUTE','MultiSensor_13_Tide_Level','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_WEIGHT_VERSION_3_V7                                       0x0E
INSERT INTO "zwaveAttribute" VALUES(49, 56,'ATTRIBUTE','MultiSensor_14_Weight','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_VOLTAGE_VERSION_3_V7                                       0x0F
INSERT INTO "zwaveAttribute" VALUES(49, 57,'ATTRIBUTE','MultiSensor_15_Voltage','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_CURRENT_VERSION_3_V7                                       0x10
INSERT INTO "zwaveAttribute" VALUES(49, 58,'ATTRIBUTE','MultiSensor_16_Current','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_CO2_LEVEL_VERSION_3_V7                                     0x11
INSERT INTO "zwaveAttribute" VALUES(49, 59,'ATTRIBUTE','MultiSensor_17_CO2_Level','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_AIR_FLOW_VERSION_3_V7                                      0x12
INSERT INTO "zwaveAttribute" VALUES(49, 60,'ATTRIBUTE','MultiSensor_18_Air_Flow','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_TANK_CAPACITY_VERSION_3_V7                                 0x13
INSERT INTO "zwaveAttribute" VALUES(49, 61,'ATTRIBUTE','MultiSensor_19_Tank_Capacity','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_DISTANCE_VERSION_3_V7                                      0x14
INSERT INTO "zwaveAttribute" VALUES(49, 62,'ATTRIBUTE','MultiSensor_20_Distance','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_ANGLE_POSITION_VERSION_4_V7                                0x15
INSERT INTO "zwaveAttribute" VALUES(49, 63,'ATTRIBUTE','MultiSensor_21_Angle_Position','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_ROTATION_V5_V7                                             0x16
INSERT INTO "zwaveAttribute" VALUES(49, 64,'ATTRIBUTE','MultiSensor_22_Rotation','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_WATER_TEMPERATURE_V5_V7                                    0x17
INSERT INTO "zwaveAttribute" VALUES(49, 65,'ATTRIBUTE','MultiSensor_23_Water_Temperature','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_SOIL_TEMPERATURE_V5_V7                                     0x18
INSERT INTO "zwaveAttribute" VALUES(49, 66,'ATTRIBUTE','MultiSensor_24_Soil_Temperature','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_SEISMIC_INTENSITY_V5_V7                                    0x19
INSERT INTO "zwaveAttribute" VALUES(49, 67,'ATTRIBUTE','MultiSensor_25_Seismic_Intensity','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_SEISMIC_MAGNITUDE_V5_V7                                    0x1A
INSERT INTO "zwaveAttribute" VALUES(49, 68,'ATTRIBUTE','MultiSensor_26_Seismic_Magnitude','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_ULTRAVIOLET_V5_V7                                          0x1B
INSERT INTO "zwaveAttribute" VALUES(49, 69,'ATTRIBUTE','MultiSensor_27_Ultraviolet','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_ELECTRICAL_RESISTIVITY_V5_V7                               0x1C
INSERT INTO "zwaveAttribute" VALUES(49, 70,'ATTRIBUTE','MultiSensor_28_Electrical_Resistivity','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_ELECTRICAL_CONDUCTIVITY_V5_V7                              0x1D
INSERT INTO "zwaveAttribute" VALUES(49, 71,'ATTRIBUTE','MultiSensor_29_Electrical_Conductivity','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_LOUDNESS_V5_V7                                             0x1E
INSERT INTO "zwaveAttribute" VALUES(49, 72,'ATTRIBUTE','MultiSensor_30_Loudness','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_MOISTURE_V5_V7                                             0x1F
INSERT INTO "zwaveAttribute" VALUES(49, 73,'ATTRIBUTE','MultiSensor_31_Moisture','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_FREQUENCY_V6_V7                                            0x20
INSERT INTO "zwaveAttribute" VALUES(49, 74,'ATTRIBUTE','MultiSensor_32_Frequency','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_TIME_V6_V7                                                 0x21
INSERT INTO "zwaveAttribute" VALUES(49, 75,'ATTRIBUTE','MultiSensor_33_Time','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_TARGET_TEMPERATURE_V6_V7                                   0x22
INSERT INTO "zwaveAttribute" VALUES(49, 76,'ATTRIBUTE','MultiSensor_34_Target_Temperature','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_PARTICULATE_MATTER_2_5_V7_V7                               0x23
INSERT INTO "zwaveAttribute" VALUES(49, 77,'ATTRIBUTE','MultiSensor_35_Particulate_Matter','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_FORMALDEHYDE_CH2O_LEVEL_V7_V7                              0x24
INSERT INTO "zwaveAttribute" VALUES(49, 78,'ATTRIBUTE','MultiSensor_36_Formaldehyde_CH20_Level','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_RADON_CONCENTRATION_V7_V7                                  0x25
INSERT INTO "zwaveAttribute" VALUES(49, 79,'ATTRIBUTE','MultiSensor_37_Radon_Concentration','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_METHANE_DENSITY_CH4_V7_V7                                  0x26
INSERT INTO "zwaveAttribute" VALUES(49, 80,'ATTRIBUTE','MultiSensor_38_Methane_Density_CH4','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_VOLATILE_ORGANIC_COMPOUND_V7_V7                            0x27
INSERT INTO "zwaveAttribute" VALUES(49, 81,'ATTRIBUTE','MultiSensor_39_Volatile_Organic_Compound','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_CARBON_MONOXIDE_CO_LEVEL_V7_V7                             0x28
INSERT INTO "zwaveAttribute" VALUES(49, 82,'ATTRIBUTE','MultiSensor_40_Carbon_Monoxide_CO','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_SOIL_HUMIDITY_V7_V7                                        0x29
INSERT INTO "zwaveAttribute" VALUES(49, 83,'ATTRIBUTE','MultiSensor_41_Soil_Humidity','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_SOIL_REACTIVITY_V7_V7                                      0x2A
INSERT INTO "zwaveAttribute" VALUES(49, 84,'ATTRIBUTE','MultiSensor_42_Soil_Reactivity','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_SOIL_SALINITY_V7_V7                                        0x2B
INSERT INTO "zwaveAttribute" VALUES(49, 85,'ATTRIBUTE','MultiSensor_43_Soil_Salinity','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_HEART_RATE_V7_V7                                           0x2C
INSERT INTO "zwaveAttribute" VALUES(49, 86,'ATTRIBUTE','MultiSensor_44_Heart_Rate','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_BLOOD_PRESSURE_V7_V7                                       0x2D
INSERT INTO "zwaveAttribute" VALUES(49, 87,'ATTRIBUTE','MultiSensor_45_Blood_Pressure','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_MUSCLE_MASS_V7_V7                                          0x2E
INSERT INTO "zwaveAttribute" VALUES(49, 88,'ATTRIBUTE','MultiSensor_46_Muscle_Mass','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_FAT_MASS_V7_V7                                             0x2F
INSERT INTO "zwaveAttribute" VALUES(49, 89,'ATTRIBUTE','MultiSensor_47_Fat_Mass','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_BONE_MASS_V7_V7                                            0x30
INSERT INTO "zwaveAttribute" VALUES(49, 90,'ATTRIBUTE','MultiSensor_48_Bone_Mass','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_TOTAL_BODY_WATER_TBW_V7_V7                                 0x31
INSERT INTO "zwaveAttribute" VALUES(49, 91,'ATTRIBUTE','MultiSensor_49_Total_Body_Water','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_BASIC_METABOLIC_RATE_BMR_V7_V7                             0x32
INSERT INTO "zwaveAttribute" VALUES(49, 92,'ATTRIBUTE','MultiSensor_50_Basic_Metabolic_Rate','STRING','R',4,"0");
--#define SENSOR_MULTILEVEL_GET_BODY_MASS_INDEX_BMI_V7_V7                                  0x33
INSERT INTO "zwaveAttribute" VALUES(49, 93,'ATTRIBUTE','MultiSensor_51_Body_Mass_Index','STRING','R',4,"0");
-- Acceleration_X_Axis 0x34 (added in v8)
INSERT INTO "zwaveAttribute" VALUES(49, 94,'ATTRIBUTE','MultiSensor_52_Acceleration_X_Axis','STRING','R',4,"0");
-- Acceleration_Y_Axis 0x35 (added in v8)
INSERT INTO "zwaveAttribute" VALUES(49, 95,'ATTRIBUTE','MultiSensor_53_Acceleration_Y_Axis','STRING','R',4,"0");
-- Acceleration_Z_Axis 0x36 (added in v8)
INSERT INTO "zwaveAttribute" VALUES(49, 96,'ATTRIBUTE','MultiSensor_54_Acceleration_Z_Axis','STRING','R',4,"0");
-- Smoke Density 0x37 (added in v8)
INSERT INTO "zwaveAttribute" VALUES(49, 97,'ATTRIBUTE','MultiSensor_55_Smoke_Density','STRING','R',4,"0");

COMMIT;
