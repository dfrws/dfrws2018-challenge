-- Upgrade apron.db from version 15 to 16.
BEGIN TRANSACTION;

-- Add column to store the max buffer size of a device
ALTER TABLE zigbeeDevice ADD COLUMN bufferSize INTEGER NOT NULL DEFAULT 48;

-- Add table for secure/unsecure command class support.
CREATE TABLE zwaveCCSupportType(
    nodeId INTEGER,
    cmdClass INTEGER,
    secure VARCHAR(256) NOT NULL, -- SECURE, UNSECURE, or UNKNOWN
    FOREIGN KEY (nodeId) REFERENCES zwaveDevice(nodeId),
    FOREIGN KEY (cmdClass) REFERENCES zwaveCmdClass(cmdClass)
);

CREATE UNIQUE INDEX deviceCommandClass ON zwaveCCSupportType(nodeId, cmdClass);

-- Add barrier operator command class
INSERT INTO "zwaveCmdClass" VALUES(102,'COMMAND_CLASS_BARRIER_OPERATOR');
INSERT INTO "zwaveCCSupport" VALUES(102,64,7,9,'SECURE_BARRIER_ADDON');
INSERT INTO "zwaveProfiles" VALUES(102,9,27);
INSERT INTO "zwaveAttribute" VALUES(102,27,'ATTRIBUTE','BARRIER_STATE','UINT8','R/W',1);

-- Add column for default value to zwaveAttribute table
ALTER TABLE zwaveAttribute ADD COLUMN defaultValue VARCHAR(256);

-- Add attributes corresponding to barrier alarms.  Only used for "N" type
-- attributes, which we can't query or write. "N" stands for "Notification".
INSERT INTO "zwaveAttribute" VALUES(113,28,'ATTRIBUTE','BARRIER_OPERATION_ALARM_STATE','UINT8','N',0,"0");
INSERT INTO "zwaveAttribute" VALUES(113,29,'ATTRIBUTE','PERIPHERAL_SENSOR_ALARM_STATE','UINT8','N',0,"0");
INSERT INTO "zwaveAttribute" VALUES(113,30,'ATTRIBUTE','DEVICE_TAMPER_ALARM_STATE','BOOL','N',0,"FALSE");

-- Add table for manufacturer specific notification support.  Note that multiple
-- notifications may map to the same attribute.
CREATE TABLE zwaveDeviceNotificationAttributeMapping(
    manufacturerNum INTEGER,
    productType INTEGER,
    productNum INTEGER,
    alarmType INTEGER,
    eventType INTEGER,
    notificationName VARCHAR(256),
    attributeId INTEGER,
    updateValue VARCHAR(256),
    updateValueDataType VARCHAR(32),
    FOREIGN KEY (manufacturerNum, productType, productNum) REFERENCES zwaveDevice (manufacturerNum, productType, productNum),
    FOREIGN KEY (attributeId) REFERENCES zwaveAttribute (attributeId)
);

INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,12336,6,68,'Unable_To_Perform_Operation',28,'1','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,12336,6,69,'Unattended_Operation_Disabled',28,'2','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,12336,6,70,'Requested_Operation_Failed',28,'3','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,12336,6,0,'Notifications_Cleared',28,'0','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,12336,6,73,'Sensor_Not_Detected',29,'1','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,12336,6,74,'Sensor_Low_Battery',29,'2','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,12336,6,0,'Notifications_Cleared',29,'0','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,12336,7,0,'Tamper_Alarm_Cleared',30,'FALSE','BOOL');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,12336,7,3,'Tamper_Alarm_Triggered',30,'TRUE','BOOL');

INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,13616,6,68,'Unable_To_Perform_Operation',28,'1','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,13616,6,69,'Unattended_Operation_Disabled',28,'2','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,13616,6,70,'Requested_Operation_Failed',28,'3','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,13616,6,0,'Notifications_Cleared',28,'0','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,13616,6,73,'Sensor_Not_Detected',29,'1','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,13616,6,74,'Sensor_Low_Battery',29,'2','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,13616,6,0,'Notifications_Cleared',29,'0','UINT8');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,13616,7,0,'Tamper_Alarm_Cleared',30,'FALSE','BOOL');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(335,18244,13616,7,3,'Tamper_Alarm_Triggered',30,'TRUE','BOOL');

-- ZB_ColorHue
-- Cluster: 0x0300
-- Attribute: 0x0000
-- Description: Sets the hue value of the light
-- Values: Range 0 - 254. The hue in degrees shall be related to the CurrentHue attribute 
--         by the relationship Hue = CurrentHue x 360 / 254 
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(768,50393088,'ZB_ColorHue','ATTRIBUTE','UINT8','R/W');

-- ZB_ColorSaturation
-- Cluster: 0x0300
-- Attribute: 0x0001
-- Description: Sets the saturation value of the light
-- Values: Range 0 - 254. The saturation shall be related to the CurrentSaturation attribute 
--         by the relationship Saturation = CurrentSaturation/254
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(768,50393089,'ZB_ColorSaturation','ATTRIBUTE','UINT8','R/W');

-- ZB_ColorCurrentX
-- Cluster: 0x0300
-- Attribute: 0x0003
-- Description: Sets the value of the normalized chromaticity value x as defined in the CIE xyY Color Space
-- Values: Range 0x0000 - 0xFEFF. The value of x shall be related to the CurrentX attribute by the relationship 
--         x = CurrentX / 65536 (CurrentX in the range 0 to 65279 inclusive)
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(768,50393091,'ZB_ColorCurrentX','ATTRIBUTE','UINT16','R/W');

-- ZB_ColorCurrentY
-- Cluster: 0x0300
-- Attribute: 0x0004
-- Description: Sets the value of the normalized chromaticity value y as defined in the CIE xyY Color Space
-- Values: Range 0x0000 - 0xFEFF. The value of y shall be related to the CurrentY attribute by the relationship 
--         y = CurrentY / 65536 (CurrentY in the range 0 to 65279 inclusive)
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(768,50393092,'ZB_ColorCurrentY','ATTRIBUTE','UINT16','R/W');

-- ZB_ColorMode
-- Cluster: 0x0300
-- Attribute: 0x0008
-- Description: Indicates which attributes are determining the color of the device
-- Values: Range 0 - 2. 
--         0 indicates color is controlled by CurrentHue and CurrentSaturation
--         1 indicates color is controlled by CurrentX and CurrentY
--         2 indicates color is controlled by ColorTemperature
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(768,50393096,'ZB_ColorMode','ATTRIBUTE','UINT8','R');

-- ZB_CheckInInterval
-- Cluster: 0x0020
-- Attribute: 0x0000
-- Description: Indicdates how often a sleepy device checks in with the hub
-- Values: Range 0x0000000 - 0x006E0000 in 1/4 seconds (ex: a value of 4 is one second)
--         0 indicates polling is turned off and the device will not check-in with the hub
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(32,2158592,'ZB_CheckInInterval','ATTRIBUTE','UINT32','R/W');

-- WK_TransitionTime
-- Cluster: 0xFFFF
-- Attribute: 0x0000
-- Description: Sets the default transition time when changing the level attribute
-- Values: Range 0 - 65535 representing the time in 1/10th per second
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(65535,4294901760,'WK_TransitionTime','ATTRIBUTE','UINT16','R/W');

COMMIT;

