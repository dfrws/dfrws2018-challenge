-- Upgrade apron.db from version 9 to 10.
BEGIN TRANSACTION;

-- Add support for OTA Bootload
INSERT OR REPLACE INTO "zigbeeCluster" VALUES(25,'OTA Bootload');

INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(25,1699842,'ZB_CurrentFileVersion','ATTRIBUTE','UINT32','R');

COMMIT;
