-- Upgrade apron.db from version 28 to 29.
BEGIN TRANSACTION;

-- bluetooth and zwave already enforce unique indexes in device state tables
CREATE UNIQUE INDEX zigbeeNodeAttribute ON zigbeeDeviceState(globalId, endpointId, attributeId);
CREATE UNIQUE INDEX zigbeeGroupAttribute ON zigbeeGroupState(groupId, attributeId);
CREATE UNIQUE INDEX lutronNodeAttribute ON lutronDeviceState(lNodeId, attributeId);

COMMIT;
