-- Upgrade apron.db from version 11 to 12.
BEGIN TRANSACTION;

ALTER TABLE masterDevice ADD COLUMN lastUpdate INTEGER NOT NULL DEFAULT 0;
ALTER TABLE masterDevice ADD COLUMN failedTxAttempts INTEGER NOT NULL DEFAULT 0;
UPDATE masterDevice SET lastUpdate=strftime('%%s','now');
UPDATE masterDevice SET failedTxAttempts=0;

ALTER TABLE zigbeeDeviceState ADD COLUMN lastUpdate INTEGER NOT NULL DEFAULT 0;
ALTER TABLE zwaveDeviceState ADD COLUMN lastUpdate INTEGER NOT NULL DEFAULT 0;
ALTER TABLE lutronDeviceState ADD COLUMN lastUpdate INTEGER NOT NULL DEFAULT 0;
UPDATE zigbeeDeviceState SET lastUpdate=strftime('%%s','now');
UPDATE zwaveDeviceState SET lastUpdate=strftime('%%s','now');
UPDATE lutronDeviceState SET lastUpdate=strftime('%%s','now');

COMMIT;
