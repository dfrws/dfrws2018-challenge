-- Upgrade apron.db from version 26 to 27.
BEGIN TRANSACTION;

ALTER TABLE bluetoothDevice ADD COLUMN modelNumber INTEGER NOT NULL DEFAULT 1;
ALTER TABLE bluetoothDeviceAttribute ADD COLUMN manufacturerName VARCHAR(256) NOT NULL DEFAULT 'Leedarson';
ALTER TABLE bluetoothDeviceAttribute ADD COLUMN modelNumber INTEGER NOT NULL DEFAULT 1;

-- New Bluetooth Attributes
INSERT INTO bluetoothAttribute VALUES(3,'Color_Temperature','UINT32','R/W');

-- New Bluetooth Device Attributes for C-Sleep Bulbs
INSERT INTO bluetoothDeviceAttribute(attributeId, manufacturerName, modelNumber) VALUES(1,'Leedarson',5);
INSERT INTO bluetoothDeviceAttribute(attributeId, manufacturerName, modelNumber) VALUES(2,'Leedarson',5);
INSERT INTO bluetoothDeviceAttribute(attributeId, manufacturerName, modelNumber) VALUES(3,'Leedarson',5);

COMMIT;
