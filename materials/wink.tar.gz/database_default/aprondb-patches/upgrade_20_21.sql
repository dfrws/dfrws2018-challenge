-- Upgrade apron.db from version 20 to 21.
BEGIN TRANSACTION;

-- Add support for various types of andersen sensors.  NULL for productNum means any matching value will be accepted.  Andersen
-- sensor product nums range from 16768 to 16799.  These will not collide with the translator ID's because endpoint range differs
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(376,23108,NULL,6,22,'Window/Door_is_Open',34,'TRUE','BOOL','2-127');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(376,23108,NULL,6,23,'Window/Door_is_Closed',34,'FALSE','BOOL','2-127');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(376,23108,NULL,6,1,'Manual_Lock_Operation',35,'FALSE','BOOL','2-127');
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(376,23108,NULL,6,2,'Manual_Unlock_Operation',35,'TRUE','BOOL','2-127');

INSERT INTO "zwaveDeviceConfigurationParameters" VALUES(376,23108,NULL,1,36,'Serial_RSSI','2-127');
INSERT INTO "zwaveDeviceConfigurationParameters" VALUES(376,23108,NULL,2,37,'Remove_Endpoint','2-127');
INSERT INTO "zwaveDeviceConfigurationParameters" VALUES(376,23108,NULL,3,38,'Refresh_Endpoint','2-127');

COMMIT;
