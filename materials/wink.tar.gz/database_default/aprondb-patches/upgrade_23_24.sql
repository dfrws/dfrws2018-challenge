-- Upgrade apron.db from version 23 to 24.
BEGIN TRANSACTION;

-- Adds support for ZWave Thermostat Fan Mode
INSERT OR REPLACE INTO "zwaveCmdClass" VALUES(68,'COMMAND_CLASS_THERMOSTAT_FAN_MODE');
INSERT OR REPLACE INTO "zwaveCmdClass" VALUES(69,'COMMAND_CLASS_THERMOSTAT_FAN_STATE');

-- add attributes 40 and 41 to thermostat profile
-- zwaveProfiles(cmdClass,profileId,attributeId)
INSERT OR REPLACE INTO "zwaveProfiles" VALUES(68,8,40);
INSERT OR REPLACE INTO "zwaveProfiles" VALUES(68,8,41);
INSERT OR REPLACE INTO "zwaveProfiles" VALUES(69,8,42);

-- add Thermostat Fan Mode and Thermostat Fan Mode Supported to zwaveAttributes
-- zwaveAttribute(cmdClass, attributeId, attr_cmd, description, dataType, read_write, commandKey)
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(68,40,'ATTRIBUTE','ThermostatFanMode','STRING','R/W',1,NULL); /* THERMOSTAT_FAN_MODE_SET */
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(68,41,'ATTRIBUTE','ThermostatFanModeSupported','UINT16','R',4,NULL); /* THERMOSTAT_FAN_MODE_SUPPORTED_GET */
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(69,42,'ATTRIBUTE','ThermostatFanState','STRING','R',2,NULL); /* THERMOSTAT_FAN_STATE_GET */

COMMIT;
