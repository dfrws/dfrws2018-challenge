-- Upgrade apron.db from version 13 to 14.
BEGIN TRANSACTION;

-- ZB_FanMode
-- Cluster: 0x0202
-- Attribute: 0x0000
-- Description: Sets the mode of a fan
-- Values: OFF=0x00, LOWEST=0x01, LOW=0x02, MEDIUM=0x03, HIGH=0x04, 
--         ON=0x05, AUTO=0x06, SMART=0x07, BREEZE=0x08, THERMOSTATIC0x09
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(514,33746944,'ZB_FanMode','ATTRIBUTE','UINT8','R/W');

-- ZB_FanTimer
-- Cluster: 0x0202
-- Attribute: 0x0002 (MFG SPECIFIC)
-- Description: Sets the duration the fan should run in minutes
-- Values: 0x0000 to 0xFFFF
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(514,33746946,'ZB_FanTimer','ATTRIBUTE','UINT8','R/W');

-- ZB_FanTimer
-- Cluster: 0x0202
-- Attribute: 0x0003 (MFG SPECIFIC)
-- Description: Sets the direction the fan should run
-- Values: FORWARD=TRUE, REVERSE=FALSE
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(514,33746947,'ZB_FanDirection','ATTRIBUTE','UINT8','R/W');

-- ZB_ColorTemperature
-- Cluster: 0x0300
-- Attribute: 0x0007
-- Description: Sets the color temperature of a device in Kelvins
-- Values: 1 to 65279 calculated by Value = 1,000,000 / ColorTemperature, giving a color 
--         temperature range from 1,000,000 Kelvins to 15.32 Kelvins). 
--         UNDEFINED=0, INVALID=65535
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(768,50393095,'ZB_ColorTemperature','ATTRIBUTE','UINT16','R/W');

COMMIT;
