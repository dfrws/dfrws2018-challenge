-- Upgrade apron.db from version 5 to 6.
BEGIN TRANSACTION;

-- Add support for a product identifier.  This is the basic cluster model identifier hashed into 
-- a 16 bit field
ALTER TABLE zigbeeDevice ADD COLUMN productId INTEGER NOT NULL DEFAULT 0;
UPDATE zigbeeDevice SET productId=0;

COMMIT;
