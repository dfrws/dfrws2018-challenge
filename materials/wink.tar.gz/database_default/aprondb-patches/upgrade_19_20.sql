-- Upgrade apron.db from version 19 to 20.
BEGIN TRANSACTION;

-- add a flag to indicate when the set value for group state has been updated.
ALTER TABLE zigbeeGroup ADD COLUMN active BOOLEAN NOT NULL DEFAULT TRUE;

COMMIT;
