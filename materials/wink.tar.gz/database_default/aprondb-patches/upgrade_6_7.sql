
-- Upgrade apron.db from version 6 to 7.
BEGIN TRANSACTION;

ALTER TABLE zwaveDeviceState ADD COLUMN setValueChangedFlag BOOLEAN NOT NULL DEFAULT FALSE;

UPDATE zwaveDeviceState SET setValueChangedFlag='FALSE';

COMMIT;
