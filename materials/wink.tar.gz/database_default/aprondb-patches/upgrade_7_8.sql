-- Upgrade apron.db from version 7 to 8.
BEGIN TRANSACTION;

-- Enable 
INSERT OR REPLACE INTO "zwaveProfiles" VALUES(64,8,16);

-- Add Thermostat Modes Supported to zwaveAttributes
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(64,16,'ATTRIBUTE','ThermostatModeSupported','UINT16','R',4); /* COMMAND_CLASS_THERMOSTAT_MODE - GET */
    
COMMIT;
