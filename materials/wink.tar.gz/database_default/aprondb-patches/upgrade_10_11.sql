-- Upgrade apron.db from version 10 to 11.
BEGIN TRANSACTION;

-- Add support for new configuration command class attributes
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112, 19,'ATTRIBUTE','Beeper_On_Off','BOOL','R/W',4);
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112, 20,'ATTRIBUTE','Vacation_Mode','BOOL','R/W',4);
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112, 21,'ATTRIBUTE','Lock_Alarm_Mode','UINT8','R/W',4);
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112, 22,'ATTRIBUTE','Alarm_Sensitivity','UINT8','R/W',4);
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112, 23,'ATTRIBUTE','Auto_Lock_On_Off','BOOL','R/W',4);
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(113, 24,'ATTRIBUTE','Alarm_Notifications_On_Off','BOOL','W',6);
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112, 25,'ATTRIBUTE','User_Code_Length','UINT8','R/W',4);
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112, 26,'ATTRIBUTE','Occupied_Users_Bitmask','UINT32','R',4);

-- Update existing configuration parameter attributes to be more descriptive
UPDATE zwaveAttribute SET description='Siren_Strobe_Mode' WHERE attributeId=17;
UPDATE zwaveAttribute SET description='Auto_Stop_Time' WHERE attributeId=18;

-- Specify that there should be only one entry in the zwaveDeviceState table
-- with a particular nodeId, endpoint, and attributeId.  In order to do this, we
-- need to insert the constrain before the database is built.  so, we copy the
-- database to a dummy table, delete the original, apply the constraint, and
-- then copy the data back over.
CREATE TABLE tempZwaveDeviceState(
    nodeId INTEGER,
    endpoint INTEGER,
    attributeId INTEGER,
    value_get VARCHAR(256),
    value_set VARCHAR(256),
    setValueChangedFlag BOOLEAN NOT NULL DEFAULT FALSE
);

INSERT INTO tempZwaveDeviceState SELECT * FROM zwaveDeviceState;
DELETE FROM zwaveDeviceState;
CREATE UNIQUE INDEX nodeAttribute ON zwaveDeviceState(nodeId, endpoint, attributeId);
INSERT OR REPLACE INTO zwaveDeviceState SELECT * FROM tempZwaveDeviceState;
DROP TABLE tempZwaveDeviceState;

-- Remove configuration parameters from device profiles
DELETE FROM "zwaveProfiles" WHERE "cmdClass"="112";

-- Add burglar alarm state to door lock profile
INSERT INTO "zwaveProfiles" VALUES(113, 7, 24);

-- Add table for device specific configuration parameters
CREATE TABLE zwaveDeviceConfigurationParameters(
       manufacturerNum INTEGER,
       productType INTEGER,
       productNum INTEGER,
       configurationParameter INTEGER,
       attributeId INTEGER,
       parameterName VARCHAR(256),
       FOREIGN KEY (manufacturerNum, productType, productNum) REFERENCES zwaveDevice (manufacturerNum, productType, productNum),
       FOREIGN KEY (attributeId) REFERENCES zwaveAttribute (attributeId)
);

-- Add device specific configuration parameters to supported devices
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(335, 8201, 0903, 0, 17, 'Siren_Strobe_Mode');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(335, 8201, 0903, 1, 18, 'Auto_Stop_Time');

INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25409, 20548, 3, 19, 'Beeper_On_Off');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25409, 20548, 4, 20, 'Vacation_Mode');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25409, 20548, 7, 21, 'Lock_Alarm_Mode');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25409, 20548, 8, 22, 'Alarm_Sensitivity');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25409, 20548, 15, 23, 'Auto_Lock_On_Off');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25409, 20548, 16, 25, 'User_Code_Length');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25409, 20548, 6, 26, 'Occupied_Users_Bitmask');

INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25417, 20548, 3, 19, 'Beeper_On_Off');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25417, 20548, 4, 20, 'Vacation_Mode');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25417, 20548, 15, 23, 'Auto_Lock_On_Off');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25417, 20548, 16, 25, 'User_Code_Length');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25417, 20548, 6, 26, 'Occupied_Users_Bitmask');

INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(59, 25419, 20556, 6, 26, 'Occupied_Users_Bitmask');

-- Add battery support for locks
INSERT INTO "zwaveProfiles" VALUES(98, 7, 15);

-- Add table for User Records 
CREATE TABLE deviceUserRecords(
    masterId INTEGER,
    userId INTEGER,
    userName VARCHAR(256),
    userStatus VARCHAR(256),
    userCode VARCHAR(32),
    doUpdate BOOLEAN,
    PRIMARY KEY (masterId, userId),
    FOREIGN KEY ( masterId ) REFERENCES masterDevice ( deviceId )
);

CREATE UNIQUE INDEX deviceUser ON deviceUserRecords(masterId, userId);

-- Add table for the number of user records supported on a device.
CREATE TABLE zwaveDeviceUserRecordSupport(
    manufacturerNum INTEGER,
    productType INTEGER,
    productNum INTEGER,
    numRecords INTEGER,
    PRIMARY KEY (manufacturerNum, productType, productNum)
);

-- Add 32 user records for the Schlage Z-wave Locks.
INSERT OR REPLACE INTO "zwaveDeviceUserRecordSupport" VALUES(59, 25409, 20548, 32);
INSERT OR REPLACE INTO "zwaveDeviceUserRecordSupport" VALUES(59, 25417, 20548, 32);
INSERT OR REPLACE INTO "zwaveDeviceUserRecordSupport" VALUES(59, 25419, 20556, 19);

COMMIT;
