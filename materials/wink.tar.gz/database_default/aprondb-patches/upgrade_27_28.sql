-- Upgrade apron.db from version 27 to 28.
BEGIN TRANSACTION;

-- Make Alarm_Notifications_On_Off R/W, so we can store the value in the hub db and report it
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(113, 24,'ATTRIBUTE','Alarm_Notifications_On_Off','BOOL','R/W',6,NULL);

-- Add refresh interval for sleepy devices
ALTER TABLE zwaveAttribute ADD COLUMN sleepyRefreshInterval VARCHAR(40) NOT NULL DEFAULT 'NEVER'; -- NEVER, HOURLY, TWICE DAILY, DAILY
UPDATE zwaveAttribute SET sleepyRefreshInterval='DAILY' WHERE attributeId=15;

COMMIT;
