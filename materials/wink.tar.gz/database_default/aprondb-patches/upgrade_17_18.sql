-- Upgrade apron.db from version 17 to 18.
BEGIN TRANSACTION;

-- add a flag to indicate when the set value for group state has been updated.
ALTER TABLE masterDevice ADD COLUMN active BOOLEAN NOT NULL DEFAULT TRUE;

COMMIT;

