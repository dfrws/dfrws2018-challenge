-- Upgrade apron.db from version 3 to 4.
BEGIN TRANSACTION;

-- Add cluster and attributes for Quirky Smart Switch 
INSERT OR REPLACE INTO "zigbeeCluster" VALUES(64544, 'Quirky Smart Switch');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(64544,4230017024,'Mode','ATTRIBUTE','UINT8','R/W');

-- Cluster 0xFC20, Attributes 0x0000, 0x0001, 0x0002, 0x0003
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(64544,4230017025,'LED Fast Flash Rate','ATTRIBUTE','UINT8','R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(64544,4230017026,'LED Slow Flash Rate','ATTRIBUTE','UINT8','R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(64544,4230017027,'LED Error Flash Rate','ATTRIBUTE','UINT8','R/W');

INSERT OR REPLACE INTO "zigbeeDeviceType" VALUES(2,'On/Off Output');

-- Support for Norm
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681408,'ZB_LocalTemperature','ATTRIBUTE','FLOAT','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681411,'ZB_AbsMinHeatSetpointLimit','ATTRIBUTE','FLOAT','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681412,'ZB_AbsMaxHeatSetpointLimit','ATTRIBUTE','FLOAT','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681413,'ZB_AbsMinCoolSetpointLimit','ATTRIBUTE','FLOAT','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681414,'ZB_AbsMaxCoolSetpointLimit','ATTRIBUTE','FLOAT','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681425,'ZB_OccupiedCoolingSetpoint','ATTRIBUTE','FLOAT','R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681426,'ZB_OccupiedHeatingSetpoint','ATTRIBUTE','FLOAT','R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681433,'ZB_MinSetpointDeadBand','ATTRIBUTE','INT8','R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681435,'ZB_ControlSequenceOfOperation','ATTRIBUTE','UINT8','R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681436,'ZB_SystemMode','ATTRIBUTE','UINT8','R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681438,'ZB_ThermostatRunningMode', 'ATTRIBUTE','UINT8','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681417,'ZB_HVACSystemConfiguration','ATTRIBUTE','UINT8','R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(513,33681480,'ZB_RevValveActiveCool','ATTRIBUTE','BOOL','R/W');  /* Quirky MFG Specific */
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1029,67497984,'ZB_RelativeHumidityMeasuredValue','ATTRIBUTE','FLOAT','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1029,67497985,'ZB_RelativeHumidityMinMeasuredValue','ATTRIBUTE','FLOAT','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1029,67497986,'ZB_RelativeHumidityMaxMeasuredValue','ATTRIBUTE','FLOAT','R');

-- Add support for IAS Zone Device Type
INSERT OR REPLACE INTO "zigbeeDeviceType" VALUES(1026,'IAS Zone');

-- Add support for IAS Zone Cluster
INSERT OR REPLACE INTO "zigbeeCluster" VALUES(1280,'IAS Zone');

INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1280,83947520,'ZoneState','ATTRIBUTE','UINT8','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1280,83947521,'ZoneType','ATTRIBUTE','UINT16','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1280,83947522,'ZoneStatus','ATTRIBUTE','UINT16','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1280,83947536,'IasCieAddress','ATTRIBUTE','UINT64','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1280,83947537,'ZoneID','ATTRIBUTE','UINT8','R');

-- Add support for power configuration attributes
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1,127008,'BatteryVoltage','ATTRIBUTE','UINT8','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1,127029,'BatteryAlarmMask','ATTRIBUTE','UINT8','R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1,127030,'BatteryVoltageMinThreshold','ATTRIBUTE','UINT8','R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1,127031,'BatteryVoltageThreshold1','ATTRIBUTE','UINT8','R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1,127032,'BatteryVoltageThreshold2','ATTRIBUTE','UINT8','R/W');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(1,127033,'BatteryVoltageThreshold3','ATTRIBUTE','UINT8','R/W');

-- Add support for basic cluster attributes
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(0,61440,'ZCLVersion','ATTRIBUTE','UINT8','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(0,61441,'ApplicationVersion','ATTRIBUTE','UINT8','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(0,61442,'StackVersion','ATTRIBUTE','UINT8','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(0,61443,'HWVersion','ATTRIBUTE','UINT8','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(0,61444,'ManufacturerName','ATTRIBUTE','STRING','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(0,61445,'ModelIdentifier','ATTRIBUTE','STRING','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(0,61446,'DateCode','ATTRIBUTE','STRING','R');
INSERT OR REPLACE INTO "zigbeeAttribute" VALUES(0,61447,'PowerSource','ATTRIBUTE','UINT8','R');

COMMIT;
