-- Upgrade apron.db from version 21 to 22.
BEGIN TRANSACTION;

-- Andersen sensors send us an unlocked notification when the door opens...this is wrong
-- Make sure we update lock state to reflect unlocked when we get a open notification
INSERT INTO "zwaveDeviceNotificationAttributeMapping" VALUES(376,23108,NULL,6,22,'Window/Door_is_Open',35,'TRUE','BOOL','2-127');

-- Updating the attribute type to UINT8
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112,37,'ATTRIBUTE','Remove_Endpoint','UINT8','R/W',4,NULL);
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112,38,'ATTRIBUTE','Refresh_Endpoint','UINT8','R/W',4,NULL);

-- Create a device type covering the lutron zigbee remote
INSERT OR REPLACE INTO "zigbeeDeviceType" VALUES(2080,'HA Non-Color Lighting Remote');
INSERT OR REPLACE INTO "zigbeeDeviceType" VALUES(14,'HA Ceiling Fan');
INSERT OR REPLACE INTO "zigbeeDeviceType" VALUES(81,'HA Smart Plug');
INSERT OR REPLACE INTO "zigbeeDeviceType" VALUES(2,'HA On/Off Output');
INSERT OR REPLACE INTO "zigbeeDeviceType" VALUES(1026,'HA IAS Zone');

COMMIT;
