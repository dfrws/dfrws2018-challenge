-- Upgrade apron.db from version 16 to 17.
BEGIN TRANSACTION;

-- add a flag to indicate when the set value for group state has been updated.
ALTER TABLE zigbeeGroupState ADD COLUMN setValueChangedFlag BOOLEAN NOT NULL DEFAULT FALSE;
UPDATE zigbeeGroupState SET setValueChangedFlag='FALSE';

-- Add column to specify endpoints for config params and notifcation mappings
ALTER TABLE zwaveDeviceConfigurationParameters ADD COLUMN endpoints STRING NOT NULL DEFAULT 0;
ALTER TABLE zwaveDeviceNotificationAttributeMapping ADD COLUMN endpoints STRING NOT NULL DEFAULT 0;

INSERT INTO "zwaveCCSupport" VALUES(32,15,1,1,'REPEATER_SLAVE');
INSERT INTO "zwaveCCSupport" VALUES(32,7,1,1,'NOTIFICATION_SENSOR');

-- these attributes map to Andersen specific configuration command class entries for the root device

-- Buzzer_Volume
-- Command Class: 0x70
-- Parameter: 1
-- Description: Sets the volume of the Verilock Translator buzzer
-- Values: Range 0 - 100
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112,31,'ATTRIBUTE','Buzzer_Volume','UINT8','R/W',4,NULL);

-- Discovery_Mode
-- Command Class: 0x70
-- Parameter: 2
-- Description: Places the translator in dsicovery mode so devices can be added or removed
-- Values: Set 0=Disable, 1=Enabled,  Get 0=User Disabled, 1=User Enabled, 2=Timed Out, 3=Failure
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112,32,'ATTRIBUTE','Discovery_Mode','UINT8','R/W',4,NULL);

-- Sleep_Mode
-- Command Class: 0x70
-- Parameter: 3
-- Description: Turn sleep mode on/off. Buzzer and LEDs do not operation when sleep mode is enabled
-- Values: FALSE=Sleep Mode Off, TRUE=Sleep Mode On 
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112,33,'ATTRIBUTE','Sleep_Mode','BOOL','R/W',4,NULL);

INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(376, 23108, 16718, 1, 31, 'Buzzer_Volume', '0');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(376, 23108, 16718, 2, 32, 'Discovery_Mode', '0');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(376, 23108, 16718, 3, 33, 'Sleep_Mode', '0');


-- The following attributes map to notification sensor multi-channel endpoints in a Andersen Verilock Translator.
-- The values can be refreshed by writing a 1 to cfg param 3 of the endpoint

-- CLOSE_STATE
-- Command Class: 0x71
-- Description: Indicates if a notfication sensor is open of closed
-- Values: TRUE=Open, FALSE=Close
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(113,34,'ATTRIBUTE','OPEN/CLOSE_STATE','BOOL','N',0,NULL);

-- LOCK/UNLOCK_STATE
-- Command Class: 0x71
-- Description: Indicates if a notification device is locked or unlocked
-- Values: TRUE=Unlocked, FALSE=Locked
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(113,35,'ATTRIBUTE','LOCK/UNLOCK_STATE','BOOL','N',0,NULL);

INSERT OR REPLACE INTO "zwaveDeviceNotificationAttributeMapping" VALUES(376,23108,16718,6,22,'Window/Door_is_Open',34,'TRUE','BOOL', '2-127');
INSERT OR REPLACE INTO "zwaveDeviceNotificationAttributeMapping" VALUES(376,23108,16718,6,23,'Window/Door_is_Closed',34,'FALSE','BOOL', '2-127');
INSERT OR REPLACE INTO "zwaveDeviceNotificationAttributeMapping" VALUES(376,23108,16718,6,1,'Manual_Lock_Operation',35,'FALSE','BOOL', '2-127');
INSERT OR REPLACE INTO "zwaveDeviceNotificationAttributeMapping" VALUES(376,23108,16718,6,2,'Manual_Unlock_Operation',35,'TRUE','BOOL', '2-127');

-- Serial_RSSI
-- Command Class: 0x70
-- Parameter: 1
-- Description: Contains the 24 bit serial# and the RSSI
-- Values: Bytes 1-3 is the unique serial #, Byte 4 is RSSI range 0x62 - 0xAA
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112,36,'ATTRIBUTE','Serial_RSSI','UINT32','R',4,NULL);

-- Remove_Endpoint
-- Command Class: 0x70
-- Parameter: 2
-- Description: Used as a mechanism to remove a sensor from the endpoint
-- Values: Write a 1 to this parameter to remove the endpoint. Reading has no value.
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112,37,'ATTRIBUTE','Remove_Endpoint','UINT32','R/W',4,NULL);

-- Refresh_Endpoint
-- Command Class: 0x70
-- Parameter: 3
-- Description: Used as a mechanism to refresh to notifcation based attributes (34 and 35)
-- Values: Write a 1 to this parameter to force updates for attribute 34 and 35. Reading has no value.
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112,38,'ATTRIBUTE','Refresh_Endpoint','UINT32','R/W',4,NULL);

INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(376, 23108, 16718, 1, 36, 'Serial_RSSI', '2-127');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(376, 23108, 16718, 2, 37, 'Remove_Endpoint', '2-127');
INSERT OR REPLACE INTO "zwaveDeviceConfigurationParameters" VALUES(376, 23108, 16718, 3, 38, 'Refresh_Endpoint', '2-127');

COMMIT;

