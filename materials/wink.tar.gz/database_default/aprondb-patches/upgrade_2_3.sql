
-- Upgrade apron.db from version 2 to 3.
BEGIN TRANSACTION;

ALTER TABLE zigbeeDevice ADD COLUMN manufacturerCode INTEGER NOT NULL DEFAULT 0;
ALTER TABLE zigbeeDeviceState ADD COLUMN setValueChangedFlag BOOLEAN NOT NULL DEFAULT FALSE;

UPDATE zigbeeDevice SET manufacturerCode=0;
UPDATE zigbeeDeviceState SET setValueChangedFlag='FALSE';

COMMIT;
