-- Upgrade apron.db from version 8 to 9.
BEGIN TRANSACTION;

-- Add support for configuration command class
INSERT OR REPLACE INTO "zwaveCmdClass" VALUES(112,'COMMAND_CLASS_CONFIGURATION');
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112, 17,'ATTRIBUTE','ConfigurationParameter_0','UINT32','R/W',4);
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(112, 18,'ATTRIBUTE','ConfigurationParameter_1','UINT32','R/W',4);

-- Add these to the binary switch profile
INSERT OR REPLACE INTO "zwaveProfiles" VALUES(112, 2, 17);
INSERT OR REPLACE INTO "zwaveProfiles" VALUES(112, 2, 18);

COMMIT;
