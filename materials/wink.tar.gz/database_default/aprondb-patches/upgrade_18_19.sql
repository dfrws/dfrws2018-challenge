-- Upgrade apron.db from version 18 to 19.
BEGIN TRANSACTION;

-- add attribute 39 to zwaveAttribute - thermostat setpoint units
INSERT OR REPLACE INTO "zwaveAttribute" VALUES(67,39,'ATTRIBUTE','ThermostatUnits','STRING','R/W',2,NULL);

-- add attribute 39 to thermostat profile
INSERT OR REPLACE INTO "zwaveProfiles" VALUES(67,8,39);

COMMIT;
