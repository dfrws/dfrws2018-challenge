BEGIN TRANSACTION;

INSERT INTO ActionRequired(ActionRequiredID, Description) VALUES(6, "No Action Supported");

INSERT INTO VersionInfo(Version, PreviousVersion, Author, Description)
VALUES (5, 4, "Kyle Barco", "Added the No Action Supported Value to the ActionRequired table");

COMMIT TRANSACTION;
