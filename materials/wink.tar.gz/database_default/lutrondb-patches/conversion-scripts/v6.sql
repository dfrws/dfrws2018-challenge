-- Added the RemoteAccessInfo table to store credentials

BEGIN TRANSACTION;

-- Create the RemoteAccessInfo table
DROP TABLE IF EXISTS RemoteAccessInfo;
CREATE TABLE RemoteAccessInfo
(
   [RemoteAccessInfoId] INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
   [UserName] TEXT NOT NULL,
   [Password] TEXT NOT NULL,
   [InTopic] TEXT NOT NULL,
   [OutTopic] TEXT NOT NULL,
   CONSTRAINT LimitOne CHECK (RemoteAccessInfoId = 1)
);

-- Since we've limited the table to contain only one entry, insert that entry now
-- and it can be modified later
INSERT INTO RemoteAccessInfo (RemoteAccessInfoID, UserName, Password, InTopic, OutTopic)
VALUES(1, '', '', '', '');

-- Now create a trigger to prevent deleting this entry
DROP TRIGGER IF EXISTS BlockRemoteAccessInfoDelete;
CREATE TRIGGER BlockRemoteAccessInfoDelete
BEFORE DELETE ON RemoteAccessInfo
BEGIN
   SELECT RAISE(FAIL, "Cannot delete Remote Access Info records");
END;

-- Update the version number
INSERT INTO VersionInfo(Version, PreviousVersion, Author, Description)
VALUES (7, 6, "David Dolan", "Added a table to store Remote Access credentials");

COMMIT TRANSACTION;

