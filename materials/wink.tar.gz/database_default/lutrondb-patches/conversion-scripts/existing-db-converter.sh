#!/bin/sh

# Initialize all global variables
defaultDbFilePath=""
dbFilePath=""
scriptDir=""
quiet=""

USAGE="Usage: $0 -d <path-to-default-db> -a <path-to-active-db> -c <path-to-conversion-scripts> [-q]"

# logs a message to the system log, and, if the quiet variable has
# not been set, echoes the message to the terminal
log(){
	# log the message
	logger $1

	# only log the message if the quiet option has not been provided
	# (just check to see if the quiet variable has been set)
	if [ -z "$quiet" ]; then
		# the quiet option hasn't been provided, so echo the message
		echo "$1"
	fi
}

# prints the usage string and exits with an error message
printUsageAndExit(){
	echo $USAGE >&2
	exit 1
}

# Process the command line arguments
# -d => full path to default database
# -a => full path to active database
# -c => full path conversion script directory
# -q => quiet output
while [ "$1" != "" ]; do
	case $1 in
		-d)
			shift
			if [ ! -f "$1" ]; then
				log "\"$1\" is not a file"
				printUsageAndExit
			fi
			defaultDbFilePath=$1
			;;
		-a)
			shift
			if [ ! -f "$1" ]; then
				log "\"$1\" is not a file"
				printUsageAndExit
			fi
			dbFilePath=$1
			;;
		-c)
			shift
			if [ ! -d "$1" ]; then
				log "\"$1\" is not a directory"
				printUsageAndExit
			fi
			scriptDir=$1
			;;
		-q)
			quiet=yes
			;;
		*)
			log "Invalid option: \"$1\""
			printUsageAndExit
			;;
	esac
	shift
done

if [ -z "$defaultDbFilePath" ]; then
	log "Default database is not set"
	printUsageAndExit
fi

if [ -z "$dbFilePath" ]; then
	log "Active database is not set"
	printUsageAndExit
fi

if [ -z "$scriptDir" ]; then
	log "Conversion script path is not set"
	printUsageAndExit
fi

# Get the version of the default database
# this will be the final version of the runtime database
# if everything goes according to plan
finalVersion=$(sqlite3 -batch $defaultDbFilePath "SELECT Version FROM CurrentVersionInfo")

# Get the current version of the runtime db
currentVersion=$(sqlite3 -batch $dbFilePath "SELECT Version FROM CurrentVersionInfo")

# see if a conversion is actually required
# note: this is not the assignment operator, strings use "=" for equality
if [ "$currentVersion" = "$finalVersion" ]; then
	log "Current database version is $currentVersion, no schema conversion is required"
else
	# Try to find the first conversion script based on the file name format v1.sql
	conversionScript=$(find $scriptDir -maxdepth 1 -name v$currentVersion.sql)
	if [ -z $conversionScript ]; then
		# if the conversion script was not found, then log a message and exit	
		log "Conversion script $conversionScript not found"
		exit 1
	fi

	log "Converting $dbFilePath schema from $currentVersion to $finalVersion"

	# if file is found start the conversion loop
	# this will run as long as the conversion script string isn't the empty string
	while [ "$conversionScript" ]; do
		# State the conversion operation
		log "Applying schema conversion from version $currentVersion..."

		# Execute the script in the sql file
		sqliteConversionResult=$(sqlite3 -batch -bail $dbFilePath ".read $conversionScript" 2>&1)
		sqliteConversionReturnCode=$?

		# Check if the conversion script was applied.  If not, break out of the loop.  The check outside
		# of the loop will exit since the versions will not match.
		if [ $sqliteConversionReturnCode -ne 0 ]; then
			log "Database schema conversion failed while applying script $conversionScript: $sqliteConversionResult"
			exit 1
		fi

		# Get the version from db (script is supposed to set the version to the next one)
		newVersion=$(sqlite3 -batch $dbFilePath "SELECT Version FROM CurrentVersionInfo")

		# DO NOT CONTINUE LOOP EXECUTION: if the version is not updated as this can lead to infinite loop
		# note: this is not the assignment operator, strings use "=" for equality
		if [ "$currentVersion" = "$newVersion" ]; then
			log "Schema conversion failed while converting from $currentVersion; version number is not updated by $conversionScript"
			exit 1
		fi
	
		# Set the new version as the current version, then get the file and continue the loop
		currentVersion=$newVersion
		conversionScript=$(find $scriptDir -maxdepth 1 -name v$currentVersion.sql)
	done

	# make sure that the current version matches the expected final version
	if [ "$currentVersion" != "$finalVersion" ]; then
		log "Database schema conversion failed: Final version ($currentVersion) does not match expected final version ($finalVersion)"
		exit 1
	else
		# Successfully applied schema changes.  Log a message.
		log "Database $dbFilePath schema successfully converted to version $finalVersion"
	fi
fi

# Update the BusinessRules and SupportedDevices tables in the runtime database. 
# This will happen regardless of whether a schema conversion was required or not.
log "Applying data conversions to $dbFilePath"

sql="
ATTACH DATABASE '$defaultDbFilePath' AS defaultdb;

BEGIN TRANSACTION;

DELETE FROM main.BusinessRules;
DELETE FROM main.SupportedDevices;

INSERT INTO main.BusinessRules SELECT * FROM defaultdb.BusinessRules;

INSERT INTO main.SupportedDevices (SupportedDeviceID, DeviceInfoID)
SELECT SupportedDeviceID, DeviceInfoID FROM defaultdb.SupportedDevices;

COMMIT TRANSACTION;"

# run the query, and get the return code and any
# error strings which may be sent to stderr
sqliteResultString=$(sqlite3 -batch -bail $dbFilePath "$sql" 2>&1)
sqliteReturnCode=$?

# if the return code is not zero, then the conversion failed
if [ $sqliteReturnCode -ne 0 ]; then
	log "Database conversion failed: $sqliteResultString"
	exit 1
else
	log "Successfully applied data conversions from $defaultDbFilePath to $dbFilePath"
fi

# If we got here, everything was successful.
log "Database $dbFilePath successfully converted to version $finalVersion"

exit 0
