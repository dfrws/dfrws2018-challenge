-- The button number values for 2B and 2BRL Pico buttons are incorrect

BEGIN TRANSACTION;

-- Fix the button numbers for the 2B Pico
UPDATE ButtonInfo SET ButtonNumber = 0 WHERE DeviceInfoID = 23 AND ComponentNumber = 2;
UPDATE ButtonInfo SET ButtonNumber = 2 WHERE DeviceInfoID = 23 AND ComponentNumber = 4;

-- Fix the button numbers for the 2BRL Pico
UPDATE ButtonInfo SET ButtonNumber = 0 WHERE DeviceInfoID = 24 AND ComponentNumber = 2;
UPDATE ButtonInfo SET ButtonNumber = 2 WHERE DeviceInfoID = 24 AND ComponentNumber = 4;
UPDATE ButtonInfo SET ButtonNumber = 3 WHERE DeviceInfoID = 24 AND ComponentNumber = 5;
UPDATE ButtonInfo SET ButtonNumber = 4 WHERE DeviceInfoID = 24 AND ComponentNumber = 6;

INSERT INTO VersionInfo(Version, PreviousVersion, Author, Description)
VALUES(3, 2, "Kyle Barco", "Fixed button numbers for Picos");

COMMIT TRANSACTION;
