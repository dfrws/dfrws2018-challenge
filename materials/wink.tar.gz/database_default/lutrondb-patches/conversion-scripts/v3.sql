-- Fix an issue that caused extra buttons to be added to the Button table
-- This only occurred the second (or later) time a device
-- of the same device class was added to the database

PRAGMA foreign_keys = ON;

BEGIN TRANSACTION;

-- Delete any buttons which never should have been added in the first place
DELETE FROM Button WHERE ButtonID IN
	(SELECT ButtonID FROM Button
	JOIN ButtonGroup USING(ButtonGroupID)
	WHERE ButtonGroup.DeviceID != Button.DeviceID);

-- Drop the old trigger, and add the new one
DROP TRIGGER IF EXISTS AddNewDevice;

-- Describe ADDNEWDEVICE
CREATE TRIGGER AddNewDevice
AFTER INSERT
ON Device
FOR EACH ROW
BEGIN
	INSERT INTO Led (DeviceID,LedInfoID,ActionRequired)
		SELECT
			new.DeviceID,
			LedInfoID,
			(SELECT CASE WHEN LinkNodeTypeID = 0 THEN 1 ELSE 0 END
				FROM DeviceInfo
				WHERE DeviceInfoID = new.DeviceInfoID)
		FROM LedInfo
		WHERE LedInfo.DeviceInfoID = new.DeviceInfoID;
	INSERT INTO LedController (DeviceID,LedControllerInfoID,ActionRequired)
		SELECT new.DeviceID,LedControllerInfoID,0
		FROM LedControllerInfo
		WHERE LedControllerInfo.DeviceInfoID = new.DeviceInfoID;
	INSERT INTO ButtonController (DeviceID,ButtonControllerInfoID,ActionRequired)
		SELECT new.DeviceID,ButtonControllerInfoID,0
		FROM ButtonControllerInfo
		WHERE ButtonControllerInfo.DeviceInfoID = new.DeviceInfoID;
	INSERT INTO ButtonGroup (DeviceID,ButtonGroupTypeID,ButtonGroupInfoID,ActionRequired)
		SELECT
			new.DeviceID,
			DefaultButtonGroupTypeID,
			ButtonGroupInfoID,
			(SELECT CASE WHEN LinkNodeTypeID = 0 THEN 1 ELSE 0 END
				FROM DeviceInfo
				WHERE DeviceInfoID = new.DeviceInfoID)
		FROM ButtonGroupInfo
		WHERE ButtonGroupInfo.DeviceInfoID = new.DeviceInfoID;
	INSERT INTO Button (DeviceID,ButtonGroupID,Name,ButtonInfoID,ActionRequired,ButtonEventBitmap)
		SELECT
			new.DeviceID,
			ButtonGroup.ButtonGroupID,
			'Button ' || (ButtonInfo.ButtonNumber + 1),
			ButtonInfo.ButtonInfoID,
			(SELECT CASE WHEN LinkNodeTypeID = 0 THEN 1 ELSE 0 END
				FROM DeviceInfo
				WHERE DeviceInfoID = new.DeviceInfoID),
			(SELECT DefaultButtonEventBitmap FROM ButtonTypeDefaults
				JOIN ButtonInfo USING(ButtonTypeID)
				WHERE ButtonInfo.DeviceInfoID = new.DeviceInfoID)
		FROM ButtonInfo JOIN ButtonGroupInfo USING(ButtonGroupInfoID)
		JOIN ButtonGroup ON (ButtonInfo.ButtonGroupInfoID = ButtonGroup.ButtonGroupInfoID
			AND ButtonGroup.DeviceID = new.DeviceID)
		WHERE ButtonInfo.DeviceInfoID = new.DeviceInfoID;
	INSERT INTO SensorConnection (DeviceID,Name,SensorConnectionInfoID,ActionRequired)
		SELECT
			new.DeviceID,
			'Sensor Connection ' || SensorConnectionInfo.SensorConnectionNumber,
			SensorConnectionInfo.SensorConnectionInfoID,
			(SELECT CASE WHEN LinkNodeTypeID = 0 THEN 1 ELSE 0 END
				FROM DeviceInfo
				WHERE DeviceInfoID = new.DeviceInfoID)
		FROM SensorConnectionInfo
		WHERE SensorConnectionInfo.DeviceInfoID = new.DeviceInfoID;
	INSERT INTO ZoneController (DeviceID,ZoneControllerInfoID,ActionRequired)
		SELECT new.DeviceID,ZoneControllerInfo.ZoneControllerInfoID,0
		FROM ZoneControllerInfo
		WHERE ZoneControllerInfo.DeviceInfoID = new.DeviceInfoID;
	INSERT INTO SwitchLegController (DeviceID,SwitchLegControllerInfoID,LoadTypeID,ActionRequired)
		SELECT
			new.DeviceID,
			SwitchLegControllerInfo.SwitchLegControllerInfoID,
			SwitchLegControllerInfo.LoadTypeID,
			CASE WHEN LoadTypeID IN (36,49) THEN 3 ELSE 0 END
		FROM SwitchLegControllerInfo
		WHERE SwitchLegControllerInfo.DeviceInfoID = new.DeviceInfoID;
	UPDATE Device SET IntegrationID = (SELECT NextIntegrationID FROM GetNextIntegrationID)
		WHERE ((DeviceID = new.DeviceID) AND
			(new.DeviceInfoID <> 16) AND
			(NOT EXISTS (SELECT DeviceID FROM SwitchLegController
				WHERE switchlegcontroller.DeviceID = new.DeviceID)));
END;

-- Update the version number
INSERT INTO VersionInfo(Version, PreviousVersion, Author, Description)
VALUES (4, 3, "Kyle Barco", "Fixed an issue related to pico button groups");

COMMIT TRANSACTION;

