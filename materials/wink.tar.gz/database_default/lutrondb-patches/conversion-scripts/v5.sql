-- Added the GetObjectName view and a trigger which will allow
-- us to use UPDATE queries on the view by instead updating the underlying tables

BEGIN TRANSACTION;

-- Create the GetObjectName view
DROP VIEW IF EXISTS GetObjectName;
CREATE VIEW GetObjectName AS
SELECT DeviceID AS ObjectID, 5 AS ObjectTypeID, Name FROM Device
UNION
SELECT ButtonID AS ObjectID, 57 AS ObjectTypeID, Name FROM Button
UNION
SELECT OccupancyGroupID AS ObjectID, 38 AS ObjectTypeID, Name FROM OccupancyGroup
UNION
SELECT SensorConnectionID AS ObjectID, 156 AS ObjectTypeID, Name FROM SensorConnection
ORDER BY ObjectTypeID;

-- Create the UpdateObjectName trigger
-- this trigger allow us to use an UPDATE query on the view to update
-- the Name column by performing the query on the appropriate table instead
DROP TRIGGER IF EXISTS UpdateObjectName;
CREATE TRIGGER UpdateObjectName
INSTEAD OF UPDATE OF Name
ON GetObjectName
FOR EACH ROW
BEGIN
	UPDATE Device SET Name = new.Name
		WHERE Device.DeviceID = new.ObjectID AND new.ObjectTypeID = 5;
	UPDATE Button SET Name = new.Name
		WHERE Button.ButtonID = new.ObjectID AND new.ObjectTypeID = 57;
	UPDATE OccupancyGroup SET Name = new.Name
		WHERE OccupancyGroup.OccupancyGroupID = new.ObjectID AND new.ObjectTypeID = 38;
	UPDATE SensorConnection SET Name = new.Name
		WHERE SensorConnection.SensorConnectionID = new.ObjectID AND new.ObjectTypeID = 156;
END;

-- Update the version number
INSERT INTO VersionInfo(Version, PreviousVersion, Author, Description)
VALUES (6, 5, "Kyle Barco", "Added support for changing object names based on object ID/type");

COMMIT TRANSACTION;

