'use strict'
/**
 * Prototype for read-only BLE characteristics
 * @param {string}      uuid         UUID for this characteristic.
 * @param {function}    dataFunction Called when this characteristic is read.
 *                                   Must accept an error-first callback as a parameter.
 * @param {string}      descriptors  Bleno descriptors for this characteristic.
 * @param {function}    [debug]      Optional debug printing function.
 * @return {null}       null
 */
var StatusCharacteristic = function(uuid, dataFunction, descriptors, debug) {
    this.constructor.super_.call(this, {
        uuid: uuid,
        properties: ['read'],
        value: null,
        descriptors: descriptors,
        onReadRequest: onReadRequest // Hack attack: see comment above onReadRequest()
    })
    this.debug = debug || function () {}
    this.dataFunction = dataFunction
    this.dataCache = null
}

var dataCallback = function (callback) {
    return function(err, data) {
        this.dataCache = null
        if (err) {
            this.debug('dataCallback: Error: ' + err.message)
            this.debug('dataCallback: Stack: ' + err.stack)
            callback(this.RESULT_UNLIKELY_ERROR, null)
        } else if (data) {
            this.debug('caching data: ' + data)
            this.dataCache = data
            var value = new Buffer(data)
            this.debug('dataCallback: data="' + data + '", value="' + value.toString('hex') + '"')
            callback(this.RESULT_SUCCESS, value)
        } else {
            this.debug('dataCallback: null')
            callback(this.RESULT_SUCCESS, new Buffer(''))
        }
    }
}

// The 'right' way to implement the method onReadRequest() is to define it
// as part of the object prototype. However, util.inherits() will overwrite
// all methods of the child class with the methods of the parent class. This
// means that, in order to declare your own method, the you must declare the
// prototype _after_ calling util.inherits(). That doesn't work here, since
// we need to require('bleno') to inherit from bleno.Characteristic, and
// we don't want to require('bleno') in this module.
// See this link for more info about prototypical inheritance in JS:
// http://stackoverflow.com/questions/13474710/util-inherits-alternative-or-workaround

//StatusCharacteristic.prototype.onReadRequest = function(offset, callback) {
function onReadRequest(offset, callback) {
    this.debug('onReadRequest: offset ' + offset)
    if (offset === 0) {
        // If offset is 0, get new data using the dataFunction.
        // The dataCallback will cache the new data for use when
        // offset is non-zero.
        this.dataFunction(dataCallback(callback).bind(this))
    } else {
        // if offset is non-zero, use the cache to service the request.
        if (this.dataCache && offset <= this.dataCache.length) {
            var cachedSubstring = this.dataCache.substring(offset)
            this.debug('using cached data: ' + cachedSubstring)
            callback(this.RESULT_SUCCESS, new Buffer(cachedSubstring))
        } else {
            callback(this.RESULT_INVALID_OFFSET, null)
        }
    }
}

module.exports = StatusCharacteristic