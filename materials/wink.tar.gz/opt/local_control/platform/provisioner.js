'use strict'
var cadence       = require('cadence')
  , logger        = require('prolific').createLogger('platform.provisioner')
  , scripts       = require('./scripts')
  , supplicant    = require('./supplicant')
  , crypto        = require('crypto')
  , path          = require('path')
  , fs            = require('fs')
  , debug         = require('debug')('platform:provisioner')

/*
 * Provisioner is responsible for provisioning and backdoor-upgrade. It
 * should only be accessed through the Manager class.
 */
function Provisioner(manager) {
    this.scripts = scripts
    this.manager = manager
    this.supplicantPath = '/database/wpa_supplicant.conf'
    this.tokenPath = '/database/token'
    this.tokenPathUpgrade = '/database/token_lci_upgrade'
    this.cfurlPath = '/database/cf_url'
    this.cfcertPath = '/database/cf_cert'
    this.relayUrlPath = '/data/upgradeUrl'
    this.relayMd5Path = '/data/upgradeMd5'
    this.pubkeyPath = path.join(__dirname, '..', 'upgradeKey.pem')
}

Provisioner.prototype.provisionHub = cadence(function (async, options) {
    debug('Provisioner.provisionHub')
    logger.info('provisionHub', { options: options })
    var gotUpgradePackage = (options.cfurl && options.cfcert && options.cfurlSign && options.cfcertSign)
    async(function () { //eslint-disable-line consistent-return
        if (!options.ssid) {
            logger.error('provisionHub', {message: 'request missing ssid'})
            return [async.break, {success: false, code: 400, message: 'missing SSID'}]
        }
        if (!supplicant.validatePSK(options.pass)) {
            logger.error('provisionHub', {message: 'PSK not valid', PSK: options.pass})
            return [async.break, {success: false, code: 400, message: 'PSK is invalid'}]
        }
    }, function () {
        // if we got backdoor upgrade info, validate and write it to file
        if (gotUpgradePackage) {
            this.validateAndWriteHubUpgradePacket(options, async())
        }
    }, function (upgradeStatus) { //eslint-disable-line consistent-return
        if (gotUpgradePackage && !upgradeStatus.success) {
            return [async.break, upgradeStatus]
        }
    }, function () {
        // generate and write supplicant
        var wpa_supplicant = supplicant.generate(options.ssid, options.pass)
        this.writePrivileged(this.supplicantPath, wpa_supplicant, async())
        if (options.token && !gotUpgradePackage) {
            // write token to regular location if we're not doing a backdoor upgrade
            this.writePrivileged(this.tokenPath, options.token, async())
        } else {
            async(function () {
                // write token to special location if we're doing a backdoor upgrade
                if (options.token && gotUpgradePackage) {
                    this.writePrivileged(this.tokenPathUpgrade, options.token, async())
                }
            }, [function () {
                // try to remove the token from the regular location
                fs.unlink(this.tokenPath, async())
            }, function (err) {
                // Swallow all errors, such as:
                //    EACCES (which should never happen, but could if DB perms are wrong)
                //    ENOENT (which might happen)
                //    Anything else (we can't afford to die here)
                logger.info('provisioning', {error: err.code, message: 'failed to remove token'})
            }])
        }
    }, function () {
        this.manager.checkSoftApStatus(async())
    }, function (softAP) {
        if (gotUpgradePackage) {
            this.scripts.stopApAndUpgradeHub()
        }
        else if (softAP) this.scripts.stopAp()
        else this.scripts.reboot()
        return {success: true}
    })
})

Provisioner.prototype.validateSignature = function(pubkey, field, signature) {
    var verifier = crypto.createVerify('RSA-SHA256')
    verifier.update(field)
    var success = false
    try {
        // this will throw if the data is not actually 'hex'
        success = verifier.verify(pubkey, signature, 'hex')
    } catch (e) {
        success = false
    }
    return success
}

Provisioner.prototype.validateAndWriteHubUpgradePacket = cadence(function (async, options) { //eslint-disable-line consistent-return
    debug('provisioner.validateAndWriteHubUpgradePacket')
    if (!options.cfurl || !options.cfcert || !options.cfurlSign || !options.cfcertSign) {
        return {success: false, code: 400, message: 'missing cfurl, cfcert, or signatures'}
    }

    // validate the signatures
    options.cfurl = options.cfurl.replace(/\\n/g, '\n')
    options.cfcert = options.cfcert.replace(/\\n/g, '\n')
    var pubkey = fs.readFileSync(this.pubkeyPath, 'utf8')
    var success = this.validateSignature(pubkey, options.cfcert, options.cfcertSign)
                && this.validateSignature(pubkey, options.cfurl, options.cfurlSign)
    if (!success) {
        return {success: false, code: 401, message: 'bad signature'}
    }
    logger.info('backdoor upgrade', {message: 'validated upgrade signatures'})

    // check that the domain is hub-updates.winkapp.com and that the string only appears once
    if (options.cfurl.indexOf('sw_pkg_url=https://hub-updates.winkapp.com/') !== 0
        || options.cfurl.lastIndexOf('sw_pkg_url') !== 0) {
        return {success: false, code: 401, message: 'domain is not winkapp'}
    }

    // write the cf_url and cf_cert files
    async(function () {
        this.writePrivileged(this.cfurlPath, options.cfurl, async())
        this.writePrivileged(this.cfcertPath, options.cfcert, async())
    }, function () {
        return {success: true}
    })
})

Provisioner.prototype.upgradeHub = cadence(function (async, request) {
    debug('wifi.upgradeHub')
    logger.info('upgradeHub', { request: request.body })
    async(function () {
        this.validateAndWriteHubUpgradePacket(request, async())
    }, function (upgradeStatus) {
        if (upgradeStatus.success) {
            this.scripts.upgradeHub()
            return {success: true}
        } else {
            return upgradeStatus
        }
    })
})

Provisioner.prototype.upgradeRelay = cadence(function (async, options) { //eslint-disable-line consistent-return
    debug('wifi.upgradeRelay')
    if (!options.url || !options.md5 || !options.urlSign || !options.md5Sign) {
        return {success: false, code: 400, message: 'missing url, md5, or signatures'}
    }
    else {
        var pubkey = fs.readFileSync(this.pubkeyPath, 'utf8')
        var success = this.validateSignature(pubkey, options.url, options.urlSign)
                    && this.validateSignature(pubkey, options.md5, options.md5Sign)
        if (!success) {
            return {success: false, code: 401, message: 'bad signature'}
        }
        else {
            async(function () {
                fs.writeFile(this.relayUrlPath, options.url, async())
                fs.writeFile(this.relayMd5Path, options.md5, async())
            }, function () {
                fs.chmodSync(this.relayUrlPath, parseInt('0755', 8))
                fs.chmodSync(this.relayMd5Path, parseInt('0755', 8))
                this.scripts.upgradeRelay()
                return {success: true}
            })
        }
    }
})

// Tries to write to a file. If permissions are insufficient,
// tries to chmod the file.
Provisioner.prototype.writePrivileged = cadence(function (async, file, data) {
    async([function () {
        fs.writeFile(file, data, async())
    }, /^EACCES$/, function () {
        logger.info('file write', {error: 'EACCES', message: 'attempted to write to privileged file -- unlocking the file now'})
        async(function () {
            this.scripts.unlock(file, async())
        }, function () {
            fs.writeFile(file, data, async())
        })
    }])
})

module.exports = Provisioner