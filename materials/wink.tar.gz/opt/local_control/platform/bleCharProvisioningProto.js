'use strict'
/**
 * Prototype for write-only BLE provisioning characteristics
 * @param {string}      uuid         UUID for this characteristic.
 * @param {function}    actionFunction Called when this characteristic is written.
 *                                   Must accept an error-first callback as a parameter.
 * @param {string}      descriptors  Bleno descriptors for this characteristic.
 * @param {function}    [debug]      Optional debug printing function.
 * @return {null}       null
 */
var ProvisioningCharacteristic = function(uuid, actionFunction, descriptors, debug) {
    this.constructor.super_.call(this, {
        uuid: uuid,
        properties: ['write'],
        value: null,
        descriptors: descriptors,
        onWriteRequest: onWriteRequest
    })
    this.debug = debug || function () {}
    this.actionFunction = actionFunction
}

// See comment in the Status Characteristic file to see why this is not implemented
// as a prototype on the class ProvisioningCharacteristic.
//ProvisioningCharacteristic.prototype.onWriteRequest = function(data, offset, withoutResponse, callback) {
function onWriteRequest(data, offset, withoutResponse, callback) {
    this.debug('onWriteRequest: offset ' + offset)
    this.actionFunction(data, offset, function (err) {
        if (err) {
            this.debug('callback: Error: ' + err.message)
            this.debug('callback: Stack: ' + err.stack)
            callback(this.RESULT_UNLIKELY_ERROR)
        } else {
            this.debug('callback: success')
            callback(this.RESULT_SUCCESS)
        }
    }.bind(this))
}

module.exports = ProvisioningCharacteristic
