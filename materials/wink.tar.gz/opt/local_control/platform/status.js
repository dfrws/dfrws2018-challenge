'use strict'
var cadence     = require('cadence')
  , logger      = require('prolific').createLogger('platform.status')
  , debug       = require('debug')('platform:status')
  , wiretools   = require('./wirelessTools')
  , helper      = require('../util/ifaceHelper')
  , fs          = require('fs')
  , path        = require('path')
  , os          = require('os')
  , isReachable = require('is-reachable')
  , ps          = require('ps-node')
  , netstat     = require('node-netstat')
  , netStates   = require('./statusNetStates')
  , winkStates  = require('./statusWinkStates')

/*
 * Status is responsible for providing network/port/wink status. It
 * should only be accessed through the Manager class.
 */
function Status() {
    this.platform = os.platform()
    this.wt = wiretools
    this.netstat = netstat
    this.urlConnCheck = 'http://www.google.com'
    this.urlConnCheck80 = 'http://www.portquiz.net:80'
    this.urlConnCheck8080 = 'http://www.portquiz.net:8080'
    this.urlConnCheck9092 = 'http://www.portquiz.net:9092'
    this.portWinkSocket = 9092
    this.filepathToken = '/database/token'
    this.filepathOauth = '/database/oauth'
}

Status.prototype.wpaSuppLocation = function () {
    var location
    this.platform === 'darwin' ?
        location = path.join(__dirname, '..', 't', 'fixtures', 'database', 'wpa_supplicant.conf') :
        location = path.join('/', 'database', 'wpa_supplicant.conf')
    return location
}

Status.prototype.currentSsid = cadence(function (async) {
    async([function () {
        fs.readFile(this.wpaSuppLocation(), async())
    }, /^ENOENT$/, function () {
        logger.debug('currentSsid', {message: 'no wpa_supplicant.conf, returning null'})
        return [async.break, null]
    }], function (supplicant) {
        try {
            var ret = supplicant.toString().match(/ssid="(.*)"/)[1]
            logger.debug('currentSsid', {message: 'extracted SSID "' + ret + '" from wpa_supplicant.conf'})
            return ret
        } catch (e) {
            logger.info('currentSsid', {message: 'Had a wpa supplicant but couldn\'t extract SSID'})
            return null
        }
    })
})

Status.prototype.networksVisible = cadence(function (async) {
    debug('status.networksVisible')
    async(function() {
        this.wt.iwlist.scan(helper.getIface(), async())
    }, function (scanData) {
        logger.debug('networksVisible', {networks: scanData})
        return [scanData]
    })
})

Status.prototype.checkSoftApStatus = cadence(function (async){
    debug('status.checkSoftApStatus')
    async(function () {
        this.wt.iwconfig.status(helper.getIface(), async())
    }, function (status) {
        // When we are in soft-ap, mode == 'Master'
        logger.debug('check softAP status', {mode: status.mode})
        return (status.mode === 'master' || status.mode === 'Master')
    })
})

Status.prototype.checkConnectivity = cadence(function(async, url) {
    async(function () {
        isReachable(url, async())
    }, function (reachable) {
        debug('status.checkConnectivity: ' + url + (reachable ? ' is ' : ' is NOT ') + 'reachable')
        return reachable
    })
})

Status.prototype.portState = cadence(function(async) {
    var badPorts = []
    async(function () {
        this.checkConnectivity(this.urlConnCheck80, async())
    }, function (p80) { //eslint-disable-line consistent-return
        if (!p80) {
            logger.info('portState', {status: 'E-HostDown'})
            return [async.break, 'E-HostDown']
        }
        this.checkConnectivity(this.urlConnCheck8080, async())
    }, function (p8080) {
        if (!p8080) {
            badPorts.push('8080')
        }
        this.checkConnectivity(this.urlConnCheck9092, async())
    }, function (p9092) {
        if (!p9092) {
            badPorts.push('9092')
        }
    }, function () {
        if (badPorts.length === 0) {
            logger.info('portState', {status: 'OK'})
            return 'OK'
        } else {
            logger.info('portState', {status: 'Ports blocked', blockedPorts: badPorts})
            return 'B-' + badPorts.join(',')
        }
    })
})

Status.prototype.networkState = cadence(function (async) {
    debug('status.networkState')
    var netStatus = netStates.ERROR.text
    async(function () {
        this.checkSoftApStatus(async())
        this.currentSsid(async())
    }, function (softAp, currentSsid) {
        logger.debug('network state part 1', {softAp: softAp, currentSsid: currentSsid})
        if (softAp) {
            if (!currentSsid) {
                netStatus = netStates['SAP-Unprovisioned'].text
            } else {
                netStatus = netStates['SAP-Provisioned'].text
            }
        } else {
            async(function () {
                this.wt.wpa.status(helper.getIface(), async())
            }, function (wpa_cli) {
                logger.debug('network state part 2', {wpa_state: wpa_cli.wpa_state, ip: wpa_cli.ip})
                switch (wpa_cli.wpa_state) {
                    // https://w1.fi/cgit/hostap/tree/src/common/defs.h#n154
                    // https://w1.fi/cgit/hostap/tree/wpa_supplicant/wpa_supplicant.c#n594
                    default:
                    case 'INACTIVE':
                    case 'INTERFACE_DISABLED':
                        netStatus = netStates['CIP-Unknown'].text
                        break
                    case 'DISCONNECTED':
                        netStatus = netStates['CIP-Disconnected'].text
                        break
                    case 'SCANNING':
                        netStatus = netStates['CIP-Scanning'].text
                        break
                    case 'AUTHENTICATING':
                        netStatus = netStates['CIP-Authenticating'].text
                        break
                    case 'ASSOCIATING':
                    case 'ASSOCIATED':
                    case '4WAY_HANDSHAKE':
                    case 'GROUP_HANDSHAKE':
                        netStatus = netStates['CIP-Associating'].text
                        break
                    case 'COMPLETED':
                        if (!wpa_cli.ip) {
                            netStatus = netStates['CIP-Configuring'].text
                        } else {
                            async(function () {
                                this.checkConnectivity(this.urlConnCheck, async())
                            }, function (connected) {
                                if (!connected) {
                                    netStatus = netStates['CON-NoInternet'].text
                                } else {
                                    netStatus = netStates['CON-Internet'].text
                                }
                            })
                        }
                        break
                }
            })
        }
    }, function () {
        logger.info('network state: ' + netStatus)
        return netStatus
    })
})

Status.prototype.getPid = cadence(function (async, processName) {
    async(function () {
        (os.platform() === 'darwin' ?
            ps.lookup({command: processName, psargs: '-o tty,pid,command'}, async()) :
            ps.lookup({command: processName}, async())
        )
    },function (resultList) {
        if(resultList.length >= 1) {
            return resultList[resultList.length - 1].pid
        } else {
            return null
        }
    })
})

Status.prototype.checkPortIsInUse = cadence(function (async, port) {
    debug('status.checkPortIsInUse: checking ' + port)
    var inUse = false
    async(function () {
        // The netstat implementation on the hub is old/underpowered, so we have
        // to override the netstat library's default command and parser.
        this.netstat.commands.linux = {
            cmd: 'netstat',
            args: ['-ane']
        }
        this.netstat.parsers.linux = function (line, callback) {
            var parts = line.split(/\s/).filter(String)
            if (!parts.length || (parts.length !== 6 && parts.length !== 8)) { // 6 for hub, 8 for circle-ci
                return undefined
            }
            var item = {
                protocol: parts[0],
                local: parts[3],
                remote: parts[4],
                state: parts[5],
                pid: '-'
            }
            return callback(this.netstat.utils.normalizeValues(item))
        }.bind(this)
        this.netstat({done: async()}, function (data) {
            if (data.remote.port === port) {
                if (data.state === 'ESTABLISHED') {
                    inUse = true
                }
            }
        })
    }, function () {
        logger.debug('checkPortIsInUse', {port: port, inUse: String(inUse)})
        return inUse
    })
})

Status.prototype.checkFileExists = cadence(function (async, file) {
    async([function () {
        fs.stat(file, async())
    }, /^ENOENT$/, function () {
        logger.debug('checkFileExists', {message: file + ' does NOT exist'})
        return [async.break, false]
    }], function (stat) {
        logger.debug('checkFileExists', {message: file + (stat.isFile() ? ' is ' : ' is NOT ') + 'a file'})
        return (stat.isFile())
    })
})

Status.prototype.winkState = cadence(function (async) {
    var winkStatus = 'ERROR'
    async(function() {
        this.networkState(async())
    }, function (netState) {
        // First, check if we have a network connection.
        if (netState.search(/^CON-/) === -1) {
            async(function () {
                this.checkFileExists(this.filepathToken, async())
                this.checkFileExists(this.filepathOauth, async())
            }, function (token, oauth) {
                if (oauth) {
                    winkStatus = winkStates['WAI-WifiHaveOauth'].text
                } else if (token) {
                    winkStatus = winkStates['WAI-WifiNoOauth'].text
                } else {
                    winkStatus = winkStates['WAI-Tokens'].text
                }
            })
        } else {
            async(function () {
                this.checkPortIsInUse(this.portWinkSocket, async())
            }, function (portInUse) {
                if (portInUse) {
                    winkStatus = winkStates['CON-Authenticated'].text
                } else {
                    winkStatus = winkStates['CIP-Connecting'].text
                }
            })
        }
    }, function () {
        logger.info('wink state: ' + winkStatus)
        return winkStatus
    })
})

module.exports = Status