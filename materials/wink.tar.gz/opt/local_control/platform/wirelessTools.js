'use strict'
var wt      = require('wireless-tools')
  , exec    = require('child_process').exec

/* This is a wrapper which allows us to use 'sudo' with the wireless-tools package */

var WirelessTools = {
    useSudo: false,
    _vanillaExec: exec,
    _exec: function () {
        var command = arguments[0]
        var opts, cb
        if (arguments.length === 3) {
            opts = arguments [1]
            cb = arguments [2]
        } else {
            opts = {}
            cb = arguments [1]
        }

        opts.timeout = opts.timeout || 2000 // set default timeout to 2000ms

        if (WirelessTools.useSudo) {
            WirelessTools._vanillaExec('sudo ' + command, opts, cb)
        } else {
            WirelessTools._vanillaExec(command, opts, cb)
        }
    },
    iwlist: wt.iwlist,
    iwconfig: wt.iwconfig,
    ifconfig: wt.ifconfig,
    wpa: wt.wpa
}

WirelessTools.iwlist.exec = WirelessTools._exec
WirelessTools.iwconfig.exec = WirelessTools._exec
WirelessTools.ifconfig.exec = WirelessTools._exec
WirelessTools.wpa.exec = WirelessTools._exec

module.exports = WirelessTools
