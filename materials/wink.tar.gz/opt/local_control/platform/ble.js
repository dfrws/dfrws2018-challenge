'use strict'
var cadence  = require('cadence')
  , debug    = require('debug')('platform:ble')
  , logger   = require('prolific').createLogger('platform.ble')
  , util     = require('util')
  , ids      = require('./bleIdentifiers')
  , manager  = require('./manager')
  , Config   = require('../util/config')
  , bleno    //require('bleno') happens in init()
  , StatusCharacteristic = require('./bleCharStatusProto')
  , ProvisioningCharacteristic = require('./bleCharProvisioningProto')

function Ble (datastore) {
    this.config = new Config(datastore)
    this.manager = manager
    logger.info('startup', { event : 'initialization' })
    this.provisioningLegacyData = {}
}

Ble.prototype.init = cadence(function (async) {
    async(function () {
        // Hack attack: it is bad practice to use "require" to dynamically load
        // modules because "require" is a synchronous operation. However,
        // require('bleno') automatically starts bleno's initialization. As far
        // as I can tell, this is the only way to control the initialization.
        // In the Local Control Server, there are some cases where we don't
        // want bleno to start (e.g. when running on the Relay).
        bleno = require('bleno')
        var services = this.initServices()

        // By default bleno uses the hostname (require('os').hostname()) as the value
        // for the device name (0x2a00) characterisic, to match the behaviour of OS X.
        // A custom device name can be specified by setting the BLENO_DEVICE_NAME
        // environment variable.
        process.env.BLENO_DEVICE_NAME = ids.name // eslint-disable-line no-process-env
        // bleno uses a 100 ms advertising interval by default.
        // A custom advertising interval can be specified by setting the
        // BLENO_ADVERTISING_INTERVAL enviroment variable with the desired value in milliseconds:
        process.env.BLENO_ADVERTISING_INTERVAL = 500 // eslint-disable-line no-process-env

        bleno.on('stateChange', function(state) {
            debug('on -> stateChange: ' + state)
            logger.debug('advertisement', {message: 'Adapter state change', state: state})
            if (state === 'poweredOn') {
                debug('trying to start advertising and set services')
                // iOS clients have a hard time connecting to an iBeacon, so use a regular advert
                bleno.startAdvertising(ids.name, services.serviceUuids, function(error) {
                    if (error) {
                        debug('startAdvertising error: '  + error.message)
                        logger.error('advertisement', {message: 'Failed to start advertising', error: error.message})
                    }
                })
                bleno.setServices(services.serviceList, function (error) {
                    debug('setServices: '  + (error ? 'error ' + error : 'success'))
                })
            } else {
                bleno.stopAdvertising()
            }
        })

        bleno.on('advertisingStart', function(error) {
            debug('on -> advertisingStart: ' + (error ? 'error ' + error : 'success'))
            if (error) {
                logger.error('advertisingStart', { error : error })
            } else {
                logger.info('advertisement started')
            }
        })
        bleno.on('advertisingStop', function(error) {
            debug('on -> advertisingStop: ' + (error ? 'error ' + error : 'success'))
            if (error) {
                logger.error('advertisingStop', { error : error })
            } else {
                logger.info('advertisement stopped')
            }
        })
        bleno.on('servicesSet', function(error) {
            debug('on -> servicesSet: ' + (error ? 'error ' + error : 'success'))
            if (error) {
                logger.error('servicesSet', { error : error })
            }
        })

        logger.info('ble.init finished')
    })
})

Ble.prototype.initServices = function () {
    var BlenoPrimaryService = bleno.PrimaryService
    var BlenoCharacteristic = bleno.Characteristic
    var BlenoDescriptor = bleno.Descriptor

    util.inherits(StatusCharacteristic, BlenoCharacteristic)
    util.inherits(ProvisioningCharacteristic, BlenoCharacteristic)

    var hubStatusChars = this.initCharacteristics(
        ids.hubStatus.characteristics,
        StatusCharacteristic,
        BlenoDescriptor,
        manager
    )
    var hubStatusService = new BlenoPrimaryService({
        uuid: ids.hubStatus.uuid,
        characteristics: hubStatusChars
    })

    var hubProvisioningChars = this.initCharacteristics(
        ids.hubProvisioning.characteristics,
        ProvisioningCharacteristic,
        BlenoDescriptor,
        this
    )
    var hubProvisioningService = new BlenoPrimaryService({
        uuid: ids.hubProvisioning.uuid,
        characteristics: hubProvisioningChars
    })

    var hubLegacyProvisioningChars = this.initCharacteristics(
        ids.hubLegacyProvisioning.characteristics,
        ProvisioningCharacteristic,
        BlenoDescriptor,
        this
    )
    var hubLegacyProvisioningService = new BlenoPrimaryService({
        uuid: ids.hubLegacyProvisioning.uuid,
        characteristics: hubLegacyProvisioningChars
    })

    return {
        // don't list ids.hubStatus.uuid in serviceUuids because we can only
        // advertise one 128-bit uuid. This doesn't stop the service from
        // being usable.
        // https://github.com/sandeepmistry/bleno/blob/73742a857c55272f3011565d972c83b75a4035ce/README.md#start-advertising
        // Include the legacy provisioning characteristic until iOS clients support the new one
        serviceUuids: [ids.hubProvisioning.uuid, ids.hubLegacyProvisioning.uuid],
        serviceList: [hubStatusService, hubProvisioningService, hubLegacyProvisioningService]
    }
}

/**
 * Constructs new instances of a Bleno Characteristic. "Marc, why do you use this
 * monstrosity to generate your Bleno characteristics dynamically instead of statically
 * defining them??" This way, my characteristic prototypes are short and reusable.
 * I suggest taking a look at the bleno examples for characteristics, and then at
 * the characteristic prototypes in this project.
 * @param  {[Object]} charMap          Hash map of desired characteristics.
 *                                     The key is used as an internal identifier.
 *                                     Each object in the map must contain
 *                                     members 'name', 'uuid', and 'function'.
 * @param  {Class}    CharPrototype    Class to use for characteristic generation. Must
 *                                     accept parameters 'uuid', 'function',
 *                                     'descriptors', 'debug'.
 * @param  {Class}    DescripPrototype Class to use for descriptor generation.
 * @param  {Object}   functionBase     Object, which must have a member function
 *                                     with the same name as each 'function' entry
 *                                     in the charHashMap.
 * @return {[Object]}                  Array of Bleno Characteristics.
 */
Ble.prototype.initCharacteristics = function (charMap, CharPrototype, DescripPrototype, functionBase) {
    var characteristicArray = []
    for (var id in charMap) { //eslint-disable-line guard-for-in
        var descriptor = new DescripPrototype({
            uuid: '2901', // user description
            value: charMap[id].name
        })
        var characterisic = new CharPrototype(
            charMap[id].uuid,
            functionBase[charMap[id].function].bind(functionBase),
            [descriptor],
            require('debug')('platform:ble:characteristic:' + id)
        )
        characteristicArray.push(characterisic)
    }
    return characteristicArray
}

// The following three functions are used by the BLE provisioning characteristics
Ble.prototype.provisionClear = function (data, offset, callback) {
    debug('ble.provisionClear')
    this.provisioningData = null
    callback(null)
}

Ble.prototype.provisionData = function (data, offset, callback) {
    debug('ble.provisionData offset: ' + offset + ' data: ' + data.toString())
    logger.info('provisionData', {offset: offset, data: data.toString()})
    if (offset) {
        if (!this.provisioningData || this.provisioningData.length < offset) {
            logger.error('ble.provisioningData attempted invalid offset', {offset: offset, length: this.provisioningData.length})
            callback(new Error('Invalid offset'))
        }
        else {
            this.provisioningData = this.provisioningData.substring(0, offset) + data.toString()
        }
    }
    else {
        this.provisioningData = data.toString()
    }
    callback(null)
}

Ble.prototype.provisionActivate = function (data, offset, callback) {
    logger.info('provisionActivate', {data: this.provisioningData})
    var parsedJson = null
    try {
        parsedJson = JSON.parse(this.provisioningData)
    } catch (e) {
        callback(new Error('Invalid JSON'))
        return
    }
    this.manager.provisionHub(parsedJson, function (err, status) {
        if (err) {
            callback(err)
        } else if (!status.success) {
            callback(new Error(status.message))
        } else {
            callback(null)
        }
    })
}

// These are functions used for provisioning with the legacy uuids and
// provisioning method on iOS clients. They will first write the Token,
// then the PSK (optional), then the SSID.
Ble.prototype.provisionLegacyToken = function (data, offset, callback) {
    this.provisioningLegacyData = {}
    this.provisioningLegacyData.token = data.toString()
    logger.info('provisionLegacyToken', {token: this.provisioningLegacyData.token})
    callback(null)
}
Ble.prototype.provisionLegacyPsk = function (data, offset, callback) {
    this.provisioningLegacyData.pass = data.toString()
    logger.info('provisionLegacyPsk', {psk: this.provisioningLegacyData.pass})
    callback(null)
}
Ble.prototype.provisionLegacySsid = function (data, offset, callback) {
    this.provisioningLegacyData.ssid = data.toString()
    logger.info('provisionLegacySsid', {ssid: this.provisioningLegacyData.ssid})
    this.manager.provisionHub(this.provisioningLegacyData, function (err, status) {
        if (err) {
            callback(err)
        } else if (!status.success) {
            callback(new Error(status.message))
        } else {
            callback(null)
        }
    })
}

module.exports = Ble
