'use strict'
function pskIsEmpty (psk) {
    if (!psk ||
        psk === ''){
        return true
    } else {
        return false
    }
}

function pskIsWepHex (psk) {
    /**
     * check for 10, 26, and 32 char strings.
     * 58 char strings, which are 256-bit WEP keys, are not supported
     * by our version of wpa_supplicant (v2.1) 
    **/
    var re = /^[0-9A-Fa-f]+$/
    if ( psk.length === 10 ||
         psk.length === 26 ||
         psk.length === 32) {
        return re.test(psk)
    } else {
        return false
    }

}

function pskIsWep (psk) {
    /** 
     * check for 5, 13, and 16 char strings
     * 29 char strings, which are 256-bit WEP keys, are not supported
     * by our version of wpa_supplicant (v2.1) 
    **/
    if ( psk.length === 5 ||
         psk.length === 13 ||
         psk.length === 16) {
        return true
    } else {
        return false
    }
}

function pskIsWpa (psk) {
    /* check for 8 - 63 char strings */
    return (psk.length >= 8 && psk.length <= 63)
}

function wepStrToHex (wepStr) {
    var hexStr = ''
    for (var i = 0; i < wepStr.length; i++) {
        hexStr = hexStr + wepStr.charCodeAt(i).toString(16)
    }
    return hexStr
}

var generate = function (ssid, psk){
    var wpaSupplicant, wepHex, wepStr

    var configHeader = 'ctrl_interface=/var/run/wpa_supplicant' + '\n' +
                        'update_config=1' + '\n' +
                        'ap_scan=1' + '\n' +
                        'fast_reauth=1' + '\n' +
                        'bgscan=""'
    var networkHeader = 'network={' + '\n' +
                        '\t' + 'scan_ssid=1' + '\n'

    var networkBodyTop = '\t' + 'ssid="' + ssid + '"' + '\n'

    var networkNoPass = '\t' + 'key_mgmt=NONE' + '\n'

    var networkShared = '\t' + 'auth_alg=SHARED' + '\n'

    function priority (num) {
        return '\t' + 'priority=' + num.toString() + '\n'
    }

    function wepBlock (prio, pskString, shared) {
        var ret = '\n\n' +
                    networkHeader +
                    priority(prio) +
                    networkNoPass +
                    pskString
        if (shared) ret = ret + networkShared
        ret = ret + '}'
        return ret
    }
    
    if (pskIsEmpty(psk)) {
        wpaSupplicant = configHeader +  
                            '\n\n' +
                            networkHeader +
                            networkBodyTop +
                            networkNoPass +
                            '}'
    } else {
        wpaSupplicant = configHeader
        if (pskIsWpa(psk)) {
            wpaSupplicant = wpaSupplicant + 
                            '\n\n' +
                            networkHeader +
                            priority(0) +
                            networkBodyTop +
                            '\t' + 'psk="' + psk + '"' + '\n' +
                            '}'
        }
        if (pskIsWepHex(psk)) {
            wepHex = '\t' + 'wep_key0=' + psk + '\n'
            wpaSupplicant = wpaSupplicant + wepBlock(2, wepHex) + wepBlock(1, wepHex, true)
        } else if (pskIsWep(psk)) {
            wepStr = '\t' + 'wep_key0="' + psk + '"' + '\n'
            wepHex = '\t' + 'wep_key0=' + wepStrToHex(psk) + '\n'
            wpaSupplicant = wpaSupplicant + wepBlock(4, wepStr) + wepBlock(3, wepStr, true)
                                          + wepBlock(2, wepHex) + wepBlock(1, wepHex, true)
        }
    }

    return wpaSupplicant
}

var validatePSK = function (psk){
    if (pskIsEmpty(psk) ||
        pskIsWpa(psk) ||
        pskIsWep(psk) ||
        pskIsWepHex(psk)) {
        return true
    } else {
        return false
    }
}

module.exports = {
    generate: generate,
    validatePSK: validatePSK
}
