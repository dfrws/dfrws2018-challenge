'use strict'
var cadence         = require('cadence')
  , logger          = require('prolific').createLogger('platform.manager')
  , debug           = require('debug')('platform:manager')
  , Status          = require('./status')
  , Provisioner     = require('./provisioner')
  , pollingtoevent  = require('polling-to-event')
  , netStates       = require('./statusNetStates')
  , winkStates      = require('./statusWinkStates')

/*
 * Manager is the public interface for platform-related
 * operations, i.e. provisioning and getting network status.
 */
function Manager() {
    this.status = new Status
    this.provisioner = new Provisioner(this)
    this.pollingToEvent = pollingtoevent

    this.currentSsid = this.status.currentSsid.bind(this.status)
    this.networksVisible = this.status.networksVisible.bind(this.status)
    this.checkSoftApStatus = this.status.checkSoftApStatus.bind(this.status)
    this.portState = this.status.portState.bind(this.status)

    this.upgradeRelay = this.provisioner.upgradeRelay.bind(this.provisioner)
    this.upgradeHub = this.provisioner.upgradeHub.bind(this.provisioner)

    // Objects to hold the current state and last failure reason for wifi/wink connection
    this._network = {
        state: null,
        polling: false,
        lastFail: null
    }
    this._wink = {
        state: null,
        polling: false,
        lastFail: null
    }
}

Manager.prototype.networksVisibleBle = cadence(function (async) {
    debug('manager.networksVisible')
    async(function () {
        this.status.networksVisible.call(this.status, async()) //eslint-disable-line no-useless-call
    }, function (netArray) {
        netArray.sort(function (a, b) {
            return b.signal - a.signal // sort in descending order by signal strength
        })
        var networkReport = '['
        for (var net in netArray) {
            if (!netArray[net].ssid || !netArray[net].security || !netArray[net].quality ||
                    !netArray[net].signal || !netArray[net].noise) {
                debug('skipping ' + netArray[net].ssid + ' because of missing info')
                continue
            }
            var networkString = '{'
            networkString += netArray[net].ssid + ','
            netArray[net].security = {
                'wpa2': '2',
                'wpa' : 'a',
                'wep' : 'e',
                'open': 'o'
            }[netArray[net].security] || netArray[net].security
            networkString += netArray[net].security + ','
            networkString += netArray[net].quality + ','
            networkString += netArray[net].signal + ','
            networkString += netArray[net].noise
            networkString += '}'
            if (networkReport.length + networkString.length < 498) { // 498 = 500 - '[]'.length
                // keep the total length of our report under 500 chars
                networkReport += networkString
            }
        }
        networkReport += ']'
        logger.info('networksVisibleBle', {output: networkReport})
        return networkReport
    })
})

Manager.prototype.networkState = cadence(function (async) { //eslint-disable-line consistent-return
    debug('manager.networkState')
    if (this._network.polling) {
        debug('currently polling, returning cached value: ' + this._network.state)
        return this._network.state
    } else {
        async(function () {
            this.status.networkState(async())
        })
    }
})

Manager.prototype.winkState = cadence(function (async) { //eslint-disable-line consistent-return
    debug('manager.winkState')
    if (this._wink.polling) {
        debug('currently polling, returning cached value: ' + this._wink.state)
        return this._wink.state
    } else {
        async(function () {
            this.status.winkState(async())
        })
    }
})

Manager.prototype.provisionHub = cadence(function (async, options) {
    debug('manager.provisionHub')
    async(function () {
        this.provisioner.provisionHub(options, async())
    }, function (provStatus) { //eslint-disable-line consistent-return
        if (!provStatus.success) {
            return [async.break, provStatus]
        }
    }, function () {
        // Create an event emitter that checks network state / wink state and emits an event
        // when there is a state change, using the pollingToEvent library.
        logger.info('provisionHub', {message: 'provisioning success, starting status polling'})
        debug('starting network and wink state polling loops')
        // First, clear any old emitters
        if (this._network.emitter) {
            this._network.emitter.removeAllListeners()
            this._network.emitter = undefined
        }
        if (this._wink.emitter) {
            this._wink.emitter.removeAllListeners()
            this._wink.emitter = undefined
        }

        var emitterOpts = {
            longpolling: true, // notify when data from the last poll differs from previous polled data
            interval: 1000 //ms
        }

        // Create the new emitters, and initialize our state
        this._network.polling = true
        this._network.lastFail = null
        this._network.state = 'ERROR'
        this._network.emitter = this.pollingToEvent(this.status.networkState.bind(this.status), emitterOpts)
        this._network.emitter.on('longpoll', this.handleNetLongpoll.bind(this))
        this._network.emitter.on('error', this.handleNetError.bind(this))

        this._wink.polling = true
        this._wink.lastFail = null
        this._wink.state = 'ERROR'
        this._wink.emitter = this.pollingToEvent(this.status.winkState.bind(this.status), emitterOpts)
        this._wink.emitter.on('longpoll', this.handleWinkLongpoll.bind(this))
        this._wink.emitter.on('error', this.handleWinkError.bind(this))

        return {success: true}
    })
})

Manager.prototype.handleNetLongpoll = function(data) {
    debug('_network.emitter longpoll: data=' + data + ', last _network.state=' + this._network.state)
    logger.info('new network state: ' + data)
    try {
        if (netStates[data].isFinalState) { // if the new state is not in our array, this will throw
            this._network.polling = false
            this._network.emitter.removeAllListeners()
            this._network.lastFail = null
        }
        if (netStates[data].index < netStates[this._network.state].index) {
            // TODO: Probably need better determination of "what was the error?"
            // Might need to grep wpa_cli's stdout
            if (netStates[this._network.state].failText) {
                this._network.lastFail = netStates[this._network.state].failText
                logger.info('net network lastFail: ' + this._network.lastFail)
            }
        }
        this._network.state = data
    } catch (e) {
        // fallback to the ERROR state
        this._network.state = winkStates.ERROR.text
    }
}

Manager.prototype.handleNetError = function(err) {
    debug('_network.emitter error: message=' + err.message + ' stack=' + err.stack)
    this._network.polling = false
}

Manager.prototype.handleWinkLongpoll = function(data) {
    debug('_wink.emitter longpoll: data=' + data + ', last _wink.state=' + this._wink.state)
    logger.info('new wink state: ' + data)
    try {
        if (winkStates[data].isFinalState) { // if the new state is not in our array, this will throw
            this._wink.polling = false
            this._wink.emitter.removeAllListeners()
            this._wink.lastFail = null
        }
        if (winkStates[data].index < winkStates[this._wink.state].index) {
            // TODO: how do we assign `EWK-ConnectAPIFail` `EWK-AuthAPIFail` `EWK-ConnectAgentFail` `EWK-AuthAgentFail`
            // Probably grep a text file that hub.c writes
            this._wink.lastFail = 'EWK-NotImplemented'
        }
        this._wink.state = data
    } catch (e) {
        // fallback to the ERROR state
        this._wink.state = winkStates.ERROR.text
    }
}

Manager.prototype.handleWinkError = function(err) {
    debug('_wink.emitter error: message=' + err.message + ' stack=' + err.stack)
    this._wink.polling = false
}

Manager.prototype.lastNetFailure = cadence(function (async) { // eslint-disable-line no-unused-vars
    debug('manager.lastNetFailure: ' + this._network.lastFail)
    logger.info('lastNetFailure: ' + this._network.lastFail)
    return this._network.lastFail
})

Manager.prototype.lastWinkFailure = cadence(function (async) { // eslint-disable-line no-unused-vars
    debug('manager.lastWinkFailure: ' + this._wink.lastFail)
    logger.info('lastWinkFailure: ' + this._wink.lastFail)
    return this._wink.lastFail
})


/* Create an instance of the Manager class and assign it to module.exports
 * Because 'require' caches the value assigned to module.exports, all calls
 * to require(this_file_name) will return this same instance, ensuring that
 * it is a singleton in our application. This allows us to present one
 * consistent state to any other modules that use this module. */
module.exports = new Manager()
