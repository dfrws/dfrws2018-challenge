'use strict'
var cadence = require('cadence')
var exec = require('child_process').exec
var spawn = require('child_process').spawn
var abend = require('abend')

function scriptExec (command) {
    return cadence(function (async) { exec(command, async()) })
}

function scriptSpawn (command, args, stdioOpt) {
    var stdio = stdioOpt || [0,1,2]
    return function () {
        var child = spawn(command, args, { detached: true, stdio: stdio })
        child.unref()
    }
}

function punt (f, timeout) {
    return function () { setTimeout(function () { f(abend) }, timeout) }
}

var unlock = cadence(function (async, filename) {
    async(function () {
        exec('sudo chmod 777 ' + filename, async())
    })
})

exports.punt = punt
exports.scriptExec = scriptExec
exports.scriptSpawn = scriptSpawn
exports.unlock = unlock
exports.stopAp = punt(scriptExec('sync; sleep 2; sudo /root/wifi/run_ap.sh stop; sudo /etc/init.d/S41wireless start; sudo /root/wifi/join-timeout.sh &'), 250)
exports.stopApAndUpgradeHub = punt(scriptExec('sync; monit stop -g wink-services; sleep 2; sudo /root/wifi/run_ap.sh stop; sudo /etc/init.d/S41wireless start; sudo killall -9 upgrade.sh; sudo killall -9 run_upgrade.sh; sudo /root/platform/run_upgrade.sh &'), 250)
exports.upgradeHub = punt(scriptExec('sudo killall -9 upgrade.sh; sync; sleep 2; sudo /root/platform/upgrade.sh'), 250)
exports.upgradeRelay = punt(scriptSpawn('/system/bin/am', ['start', '-S', 'com.wink.winkupgrade/.UpgradeActivity']), 250)
exports.reboot = punt(scriptExec('sync; sleep 2; sudo reboot'), 250)
