'use strict'
var cadence       = require('cadence')
  , logger        = require('prolific').createLogger('platform.http')
  , debug         = require('debug')('platform:http')
  , Dispatcher    = require('inlet/dispatcher')
  , Authenticator = require('inlet/authenticator')
  , Config        = require('../util/config')
  , os            = require('os')
  , manager      = require('./manager')

function Wifi (datastore) {
    this.config = new Config(datastore)
    this.platform = os.platform()
    this.manager = manager
    logger.info('startup', { event : 'initialization' })
}

Wifi.prototype.dispatcher = function () {
    var dispatcher = new Dispatcher(this)
    dispatcher.dispatch('GET /', 'status')
    switch (this.platform) {
        case 'android':
            dispatcher.dispatch('POST /upgrade', 'upgradeRelay')
            break
        default:
            dispatcher.dispatch('POST /', 'provisionHub')
            dispatcher.dispatch('POST /upgrade', 'upgradeHub')
            break
    }
    return dispatcher.createDispatcher()
}

Wifi.prototype.authenticate = cadence(function (async, request) {
    debug('wifi.authenticate')
    async(function () {
        this.manager.checkSoftApStatus(async())
        this.readTokens(async())
    }, function (softAP, tokens, valid) {
        var authorized = (softAP ||
            (Authenticator.isBearer(request)
                && tokens.indexOf(request.authorization.credentials) >= 0
                && valid))
        if (!authorized) {
            logger.error('not authorized')
            request.raise(401, 'not authorized')
        }
    })
})

Wifi.prototype.readTokens = cadence(function (async){
    async(function () {
        this.config.read(async())
    } , function () {
        var tokens = this.config.extractTokens()
        var valid = this.config.tokensValid()
        return [tokens, valid]
    })
})

Wifi.prototype.status = cadence(function (async, request) {
    debug('wifi.status')
    async(function () {
        this.authenticate(request, async())
    }, function () {
        this.manager.winkState(async())
        this.manager.networkState(async())
        this.manager.lastNetFailure(async())
        this.manager.lastWinkFailure(async())
    }, function (winkState, networkState, lastNetFailure, lastWinkFailure) {
        return {
            wink: winkState,
            network: networkState,
            netFail: lastNetFailure,
            winkFail: lastWinkFailure
        }
    })
})

Wifi.prototype.provisionHub = cadence(function (async, request) {
    debug('wifi.provisionHub')
    async(function () {
        this.authenticate(request, async())
    }, function () {
        this.manager.provisionHub(request.body, async())
    }, function (status) { //eslint-disable-line consistent-return
        if (status.success) {
            return status
        } else {
            request.raise(status.code, status.message)
        }
    })
})

Wifi.prototype.upgradeHub = cadence(function (async, request) {
    debug('wifi.upgradeHub')
    async(function () {
        this.manager.upgradeHub(request.body, async())
    }, function (status) { //eslint-disable-line consistent-return
        if (status.success) {
            return status
        } else {
            request.raise(status.code, status.message)
        }
    })
})

Wifi.prototype.upgradeRelay = cadence(function (async, request) {
    debug('wifi.upgradeRelay')
    async(function () {
        this.manager.upgradeRelay(request.body, async())
    }, function (status) { //eslint-disable-line consistent-return
        if (status.success) {
            return status
        } else {
            request.raise(status.code, status.message)
        }
    })
})

module.exports = Wifi
