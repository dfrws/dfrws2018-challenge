#!/bin/bash

COMMONNAME='aau'
DIRECTORY=''
FORCE='false'
SHOWHELP='false'
VERBOSE='false'

while getopts ':c:d:fhv' opt; do
  case "${opt}" in
    c) COMMONNAME="${OPTARG}" ;;
    d) DIRECTORY="${OPTARG}" ;;
    f) FORCE='true' ;;
    h) SHOWHELP='true' ;;
    v) VERBOSE='true' ;;
    *) error "Unexpected option ${opt}" ;;
  esac
done

if [ $VERBOSE == 'true' ]; then
    set -x
fi

if [ $SHOWHELP == 'true' ]; then
    echo
    echo "$(basename $0) - generate ca certificate"
    echo " "
    echo "$(basename $0) [options]"
    echo " "
    echo "options:"
    echo "-h               show brief help"
    echo "-v               verbose output"
    echo "-c [CN]          specify Common Name (default: aau)"
    echo "-d [directory]   specify a directory to store output in (optional)"
    echo "-f               force re-generation"
    exit 0
fi

# Change directory and create it if needed
if [ -n "$DIRECTORY" ]; then
    if [ ! -d "$DIRECTORY" ]; then
        mkdir -p "$DIRECTORY"
    fi
    cd "$DIRECTORY"
fi

if [ $FORCE == 'true' ]; then
    rm -f $COMMONNAME.{key,crt,sha1,sha256,der}
fi

if [ -e $COMMONNAME.key ]; then
    keysize=$(openssl rsa -in $COMMONNAME.key -noout -text | grep "Private-Key")
    if [ "$keysize" == 'Private-Key: (1024 bit)' ]; then
        exit 0
    fi
fi

echo "Removing old certificate data from config.json..."
rm config.json # hack so we remove the old certificate hash from config.json

echo "Generating RSA keypair $COMMONNAME.key. This may take a while..."
# Generate the cert and private key
openssl req -x509 -newkey rsa:1024 -days 3650 -nodes -subj /CN=$COMMONNAME -keyout $COMMONNAME.key -out $COMMONNAME.crt
# Generate SHA1
openssl x509 -sha1 -in $COMMONNAME.crt -noout -fingerprint > $COMMONNAME.sha1
# Generate SHA256
openssl x509 -sha256 -in $COMMONNAME.crt -noout -fingerprint > $COMMONNAME.sha256
# Generate DER
openssl x509 -inform pem -outform der -in $COMMONNAME.crt > $COMMONNAME.der

chmod 0444 $COMMONNAME.{crt,sha1,sha256,der}
chmod 0400 $COMMONNAME.key

exit 0
