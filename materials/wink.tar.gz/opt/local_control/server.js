#!/usr/bin/env node
'use strict'
/*
    ___ usage: en_US ___
    usage: node server.js [options]

    options:

    -s, --start     [services]  list of services to start (default: aau,ble,wifi,heartbeat)
    -d, --dryrun                print config to console and quit (default: false)
    -v, --verbose               turn on debugging output
    -c, --console               redirect output to console instead of logfile
    -u, --uid       [uid]       uid for dropping permissions to (also specify gid)
    -g, --gid       [gid]       gid for dropping permissions to (also specify uid)

    ___ usage ___
*/

var cadence  = require('cadence')

require('arguable')(module, cadence(function (async, options) {
    // set NODE_ENV to 'production' for the Connect module
    if (options.params.verbose) { process.env.DEBUG = '*' } // eslint-disable-line no-process-env
    else { process.env.NODE_ENV = 'production' } // eslint-disable-line no-process-env

    var server   = require('./process/server')
      , os       = require('os')
      , path     = require('path')
      , fs       = require('fs')
      , execFile = require('child_process').execFile

    var platform = os.platform()
    var config = {
        heartbeat_port     : 8886
      , aau_port           : 8888
      , wifi_port          : 80
      , hub_listen_port    : 9876
      , dryrun             : false
      , start              : (platform === 'android' ? 'aau,wifi,heartbeat' : 'aau,wifi,ble,heartbeat')
      , console            : false
    }

    // Check for command line params
    config.start = options.params.start || config.start
    config.console = options.params.console || config.console
    config.dryrun = options.params.dryrun || config.dryrun
    config.uid = Number(options.params.uid)
    config.gid = Number(options.params.gid)

    // On the hub, store data in /database. On the Relay, store in /data/local/ssl
    if (platform === 'linux') {config.datastore = path.join('/database', 'local_control_data')}
    else if (platform === 'android') {config.datastore = path.join('/data', 'local', 'ssl')}
    else {config.datastore = path.join(__dirname, '.', 'datastore')}

    // On the hub, log to a FIFO. On the Relay, log to a file in datastore
    if (!config.console) {
        if (platform === 'linux') {config.log_file = '/var/log/local-control-fifo'}
        else if (platform === 'android') {config.log_file = path.join(config.datastore, 'local_control_log.txt')}
        try {
            var fd = fs.openSync(config.log_file, 'w')
            fs.writeSync(fd, 'Local control server startup. ')
            fs.writeSync(fd, 'Spooling FTL drives... ')
            fs.writeSync(fd, 'Engage! ')
            require('prolific').sink = fs.createWriteStream(null, {fd: fd})
            console.log('Local control logs will be written to ' + config.log_file)  // eslint-disable-line no-console
        } catch (error) {
            console.error('Couldn\'t open logfile at ' + config.log_file + ', logging to stdout instead.')  // eslint-disable-line no-console
        }
    }

    // If we're on OSX, listen on 8887 instead of 80 so we don't need root
    if (platform === 'darwin') { config.wifi_port = 8887 }
    // If we're running on OSX ('darwin'), listen for the hub on all interfaces. Otherwise, only listen on localhost
    if (platform === 'darwin') { config.hub_listen_ip = '0.0.0.0' }
    else { config.hub_listen_ip = '127.0.0.1' }

    // Set variables to generate an SSL certificate using the generate-cert.sh script
    var script_interpreter = { android : '/system/bin/sh' }[platform] || '/bin/bash'
    var script_path = path.join(__dirname, './generate-cert.sh')
    config.cert = path.join(config.datastore, 'aau.crt')
    config.key = path.join(config.datastore, 'aau.key')
    config.ca = config.cert

    // Catch all uncaught exceptions and log them, then exit
    // We do this dirty deed to protect against a module that is calling 'process.exit()'
    // too early, before stack traces can get printed to screen. 
    // TODO: This whole chunk should be removed ASAP, when 'arguable' is updated to not call
    // process.exit() in arguable/exit.js (newer than 0.0.37??)
    process.on('uncaughtException', function(err) {
        console.error('Caught fatal exception: ' + err) // eslint-disable-line no-console
        console.error(err.stack) // eslint-disable-line no-console
        throw err
    })

    async(function (){
        execFile(script_interpreter, [script_path, '-d', config.datastore], async())
    }, function (){
        if (config.dryrun) {
            console.log(config) // eslint-disable-line no-console
            return
        }
        server(config, async())
    })
}))
