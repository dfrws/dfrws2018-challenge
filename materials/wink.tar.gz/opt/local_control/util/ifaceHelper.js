'use strict'
/* Helper functions that will run on both OSX and linux */

var os = require('os')

var platformDefault = os.platform()
var cachedIface

var clearCachedIface = function () {
    cachedIface = undefined
}

var getIface = function (platformArg) {
    if (cachedIface) {
        return cachedIface
    }

    var platform = platformArg || platformDefault
    var ifaces  = os.networkInterfaces()
    var prefix = { darwin : 'en' }[platform] || 'wlan'

    for (var iface in ifaces) {
        if (iface.indexOf(prefix) === 0) {
            cachedIface = iface
            return iface
        }
    }
    /* Set the fallback interface name to 'wlan0' (used in hub + relay).
     * On occasion, os.networkInterfaces() does not return all interfaces.
     * This was observed when the hub was trying to connect to an invalid
     * wifi network. */
    cachedIface = 'wlan0'
    return 'wlan0'
}

var getIp = function (iface) { //eslint-disable-line consistent-return
    var ifaces  = os.networkInterfaces()
    var entry
    if (ifaces[iface]) {
        for (var i = 0; i < ifaces[iface].length; i++) {
            entry = ifaces[iface][i]
            if (entry.family === 'IPv4'){
                return entry.address
            }
        }
    }
}

module.exports = {
    getIface: getIface,
    getIp: getIp,
    clearCachedIface: clearCachedIface
}
