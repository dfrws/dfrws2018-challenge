'use strict'
var cadence = require('cadence')
var path = require('path')
var fs = require('fs')
var crypto = require('crypto')
var sequester = require('sequester')
var uuid = require('node-uuid')
var debug = require('debug')('aau:config')

function Configuration (directory) {
    this.directory = directory
    this.configFile = path.join(this.directory, 'config.json')
    this.sha256File = path.join(this.directory, 'aau.sha256')
    this.lock = sequester.createLock()
}

Configuration.prototype.read = cadence(function (async) {
    debug('config.read')
    async(function () {
        this.lock.share(async())
    }, [function () {
        this.lock.unlock()
    }], [function () {
        async(function () {
            fs.readFile(this.configFile, 'utf8', async())
        }, function (file) {
            try {
                var config = JSON.parse(file)
                this.id = config.id
                this.tokens = config.tokens
                this.devices_readonly = {}
                this.devices_writable = {}
                debug('config.read: successfully read')
            } catch (error) {
                throw new Error('ENOENT')
            }
        })
    }, /^ENOENT$/, function () {
        debug('config.read: ENOENT')
        async(function () {
            this._resetIdAndTokens(async())
            this.devices_readonly = {}
            this.devices_writable = {}
        })
    }])
})

Configuration.prototype.write = cadence(function (async) {
    debug('config.write')
    async(function () {
        this.lock.exclude(async())
    }, [function () {
        this.lock.unlock()
    }], function () {
        var config = {
            id: this.id,
            tokens: this.tokens
        }
        fs.writeFile(this.configFile, JSON.stringify(config), async())
    })
})

Configuration.prototype.resetIdAndTokens = cadence(function (async) {
    debug('config.resetIdAndTokens')
    async(function () {
        this._resetIdAndTokens(async())
    }, function () {
        this.write(async())
    })
})

Configuration.prototype._resetIdAndTokens = cadence (function (async) {
    debug('config._resetIdAndTokens')
    async(function () {
        crypto.randomBytes(16, async())
        this.readSha256(async())
    }, function (bytes, sha256) {
        var now = Date.now() / 1000
        this.id = { created_at: now, local_control_id: uuid.v4(bytes), sha256: sha256 }
        this.tokens = { access_tokens: [], updated_at: now }
    })
})

Configuration.prototype.extractTokens = function () {
    debug('config.extractTokens')
    return this.tokens.access_tokens.map(function (object) {
        return object.client_token
    })
}

Configuration.prototype.writeTokenArray = cadence(function (async, tokenArray) {
    debug('config.writeTokenArray')
    this.tokens.access_tokens = tokenArray
    this.tokens.updated_at = Date.now() / 1000
    this.write(async())
})

Configuration.prototype.readSha256 = cadence(function (async) {
    debug('config.readSha256')
    async(function () {
        fs.readFile(path.join(this.directory, 'aau.sha256'), 'utf8', async())
    }, function (data) {
        return data.substr('SHA256 Fingerprint='.length, data.length - ('SHA256 Fingerprint='.length + 1))
    })
})

Configuration.prototype.tokensValid = function () {
    debug('config.tokensValid')
    var now = Date.now() / 1000
    var oneWeekInSec = 60*60*24*7
    if (this.tokens.updated_at > (now - oneWeekInSec)) {
        debug('tokens valid')
        return true
    }
    else {
        debug('tokens invalid')
        return false
    }
}

module.exports = Configuration
