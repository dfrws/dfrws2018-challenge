'use strict'
/*
    ___ usage: en_US ___

    description:

    Launch a single process that runs all of the server's services. The services
    will listen on different ports, but all services will share the same network
    interface and public IP address.

    ___ usage ___
*/

var cadence = require('cadence')
  , abend = require('abend')
  , Resolver = require('conduit/resolver')
  , Authenticator = require('conduit/authenticator/static')
  , Transport = require('conduit/transport/reactive')
  , createListener = require('conduit/listener')
  , tcpContextualizer = require('conduit/tcp')
  , connect = require('connect')
  , net = require('net')
  , path = require('path')

module.exports = cadence(function (async, config) {
    var fs = require('fs')
      , AAU = require('../aau/http')
      , Advertisement = require('../aau/advertisement')
      , Heartbeat = require('../heartbeat/http')
      , Wifi = require('../platform/http')
      , Ble = require('../platform/ble')
      , http = require('http')
      , https = require('https')
      , logger = require('prolific').createLogger('process.server')
      //, blocked = require('blocked')
      //, debug = require('debug')('process:server')

    async(function () {
        require('prolific').setLevel('debug')
        logger.info('startup', { event : 'initialization', config : config })
        fs.readFile(config.ca, async())
        fs.readFile(config.key, async())
        fs.readFile(config.cert, async())
    }, function (ca, key, cert) {
        var tlsOpts = {
            ca   : ca
          , key  : key
          , cert : cert
          // RC4 is _really_ fast, but is (not practically) breakable
          // ECDHE is faster than DHE, though our current node version doesn't support them.
          , ciphers : 'RC4:AES128-GCM-SHA256:AES128-SHA256:AES128-SHA:' +
                        //'ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:' +
                        //'ECDHE-RSA-AES128-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:' +
                        'HIGH:!3DES:!DES:!MD5:!aNULL:!eNULL:!EXPORT:!PSK:!AES256-GCM-SHA384'
          , honorCipherOrder : true
        }
        config.start.split(/,/).forEach(function (service) {
            switch (service) { // eslint-disable-line default-case
                case 'heartbeat':
                    var heartbeat = new Heartbeat()
                    var heartbeatServer = http.createServer(heartbeat.dispatcher().server())
                    heartbeatServer.listen(config.heartbeat_port, '0.0.0.0', async())
                    break
                case 'wifi':
                    var wifi = new Wifi(config.datastore)
                    var handler = connect()
                        .use(function (req, res, next) {
                            // Older android versions send a bogus heading
                            if (req.headers['content-encoding'] === 'UTF-8') {
                                delete req.headers['content-encoding']
                            }
                            next()
                        })
                        .use(wifi.dispatcher().server())
                    var wifiServer = http.createServer(handler)
                    wifiServer.listen(config.wifi_port, '0.0.0.0', async())
                    break
                case 'ble':
                    var ble = new Ble(config.datastore)
                    ble.init(async())
                    break
                case 'aau':
                    var aau = new AAU()
                    var transport = new Transport(aau)
                    var authenticator = new Authenticator('aau')
                    var resolver = new Resolver(authenticator, transport, {})
                    var conduit = net.createServer(createListener(tcpContextualizer, resolver, function(error) {
                        // Hack attack: sometimes, depending on timing, the LCI may try
                        // to write a packet after the other end of the socket goes down,
                        // causing an abend() due to EPIPE. Catch and ignore it instead.
                        if (error && error.code === 'EPIPE') {
                            logger.info('caught EPIPE', error)
                        } else {
                            abend(error)
                        }
                    }))
                    var advertisement = new Advertisement()

                    setInterval(aau.keepAlive.bind(aau), 1000 * 2)
                    aau.resolver = resolver
                    aau.advertisement = advertisement
                    async(function () {
                        aau.initialize(config.datastore, async())
                    }, function () {
                        conduit.listen(config.hub_listen_port, config.hub_listen_ip)
                        // check for expired tokens once per hour
                        setInterval(function() {aau.updateTokens(aau.config.extractTokens(), aau.config.tokensValid())}, 1000 * 60 * 60)
                        advertisement.start(config.aau_port, aau.config.id.local_control_id)
                        // check IP every minute
                        setInterval(advertisement.checkIp.bind(advertisement), 1000 * 60)
                    }, function () {
                        var aauServer = https.createServer(tlsOpts, aau.dispatcher().server())
                        aauServer.listen(config.aau_port, '0.0.0.0', async())
                    })
                    break
            }
        })
    }, function () {
        // drop permissions now that we've started the servers
        if ((!isNaN(config.gid)) && (!isNaN(config.uid))) {
            fs.chownSync(config.datastore, config.uid, config.gid)
            fs.chmodSync(config.datastore, parseInt('0700', 8))  // Must have rwx perms on directory
            fs.chownSync(path.join(config.datastore, 'config.json'), config.uid, config.gid)
            fs.chmodSync(path.join(config.datastore, 'config.json'), parseInt('0600', 8))  // Must have at least rw on config file
            process.setgid(config.gid)
            process.setuid(config.uid)
            logger.info('startup', { event : 'dropped permissions to uid ' + process.getuid() + ' and gid ' + process.getgid() })
        }
    }, function () {
    /* Disabling for staging release due to lack of testing!
        // check for a blocked event loop every 100ms
        // https://github.com/tj/node-blocked/blob/master/Readme.md
        blocked(function(ms){
            debug('BLOCKED FOR %sms', ms | 0);
        })
    }, function () { */
        logger.info('startup', { event : 'startup complete' })
    })
})

Error.stackTraceLimit = Infinity
