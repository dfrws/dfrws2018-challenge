'use strict'
var SSDP       = require('node-ssdp').Server
  , os         = require('os')
  , logger     = require('prolific').createLogger('aau.advertisement')
  , wifiHelper = require('../util/ifaceHelper')
  , debug      = require('debug')('aau:advertisement')
  , version    = require('../package.json').version

function Advertisement () {
    this.platform = os.platform()
    this.SSDP = SSDP
    this.wifiHelper = wifiHelper
}

Advertisement.prototype.start = function (port, uuid) {
    this.version = version.match(/[0-9]+/)[0] // take our major version number from package.json
    this.port = port
    this.UDN = 'uuid:' + uuid
    this.modelName = (this.platform === 'android' ? 'Wink Relay' : 'Wink Hub')
    this.USNDevice = 'urn:wink-com:device:' + (this.platform === 'android' ? 'relay' : 'hub') + ':' + this.version
    this.USNService = 'urn:wink-com:service:fasterLights:' + this.version
    // UPNP versions are integers, and must be backwards compatible with old versions of the
    // same service / device. If a non-backwards-compatible change is made, a new service
    // or device type must be used.
    this._checkIp()
}

Advertisement.prototype.checkIp = function () {
    this._checkIp()
}

Advertisement.prototype.changeId = function (uuid) {
    this.UDN = 'uuid:' + uuid
    if (this.server) {
        this._stop()
        this._start()
    }
}

Advertisement.prototype._checkIp = function () {
    debug('advertisement._checkIp')
    var newIface = this.wifiHelper.getIface(this.platform)
    var newIp = this.wifiHelper.getIp(newIface)
    if (!newIp) {
        logger.error('checkIp', { event : 'couldn\'t get IP' })
        this.ip = undefined
        if (this.server) this._stop()
        return
    }
    if (newIp !== this.ip) {
        logger.info('checkIp', { event: 'IP changed', 'old IP': this.ip, 'new IP': newIp } )
        this.iface = newIface
        this.ip = newIp
        if (this.server) this._stop()
        this._start()
    }
    debug('ip did not change: ' + newIp)
}

Advertisement.prototype._start = function () {
    if (this.ip === '192.168.0.1') {
        logger.error('start', { message: 'IP detected as 192.168.0.1, not starting advertisement' })
        return  // TODO: this is a hack so we don't run in soft-ap
    }
    logger.info('start', { 'options': {iface: this.iface, ip: this.ip} } )

    // We could do this all in the initializer for lower overhead, but then we'd
    // have to reach into this.server._location when our IP changes.
    this.server = new this.SSDP({
        logLevel: 'ERROR', // switch to 'TRACE' to get lots of output
        udn: this.UDN,
        adInterval: 1800000, // in ms, default 10,000. UPNP spec calls for minimum 1,800,000ms
        allowWildcards: false, // default false
        location: 'https://' + this.ip + ':' + this.port
    })
    this.server.addUSN('upnp:rootdevice')
    this.server.addUSN(this.USNDevice)
    this.server.addUSN(this.USNService)

    this.server.start()
}

Advertisement.prototype._stop = function () {
    this.server.stop()
    this.server = null
}

Advertisement.prototype.description = function () {
    var xml =
        '<?xml version="1.0"?>' + '\n' +
        '<root xmlns="urn:schemas-wink-com:device-1-0">' + '\n' +
            '<specVersion>' + '\n' +
                '<major>1</major>' + '\n' +
                '<minor>0</minor>' + '\n' +
            '</specVersion>' + '\n' +
            '<URLBase>https://' + this.ip + ':' + this.port + '</URLBase>' + '\n' +
            '<device>' + '\n' +
                '<deviceType>' + this.USNDevice + '</deviceType>' + '\n' +
                '<friendlyName>' + this.modelName + '</friendlyName>' + '\n' +
                '<manufacturer>Wink, Inc.</manufacturer>' + '\n' +
                '<manufacturerURL>http://www.wink.com</manufacturerURL>' + '\n' +
                '<modelDescription>' + this.modelName + '</modelDescription>' + '\n' +
                '<modelName>' + this.modelName + '</modelName>' + '\n' +
                '<modelNumber/>' + '\n' +
                '<modelURL>http://www.wink.com</modelURL>' + '\n' +
                '<serialNumber/>' + '\n' +
                '<UDN>' + this.UDN + '</UDN>' + '\n' +
                '<UPC/>' + '\n' +
                '<iconList/>' + '\n' +
                '<presentationURL/>' + '\n' +
                '<serviceList>' + '\n' +
                    '<service>' + '\n' +
                        '<serviceType>' + this.USNService + '</serviceType>' + '\n' +
                        '<serviceId>urn:wink-com:serviceId:fasterLights</serviceId>' + '\n' +
                        '<controlURL/>' + '\n' +
                    '</service>' + '\n' +
                '</serviceList>' + '\n' +
            '</device>' + '\n' +
        '</root>'
    return xml
}

module.exports = Advertisement
