'use strict'
/* To add new attributes, add them to the 'mappings[]' array.
 * Each attribute needs a conversion function defined for
 * serialization/deserialization.
*/

function Mapping (radioType, attributeId, fieldName, attributeValueToFieldValue, fieldValueToAttributeValue, mutability, sendToHub) {
    this.radioType = radioType              // Hub radio type
    this.attributeId = attributeId          // Hub attribute ID
    this.fieldName = fieldName              // API field name
    this.aToF = attributeValueToFieldValue  // Conversion function from Hub to API
    this.fToA = fieldValueToAttributeValue  // Conversion function from API to Hub
    this.writable = (mutability === 'RW')   // 'R' or 'RW'
    // the 'sendToHub' parameter is a hack to work around the client's behaviour of sending down lots
    // of parameters. See comment in Hub.prototype.checkLastReadingEqualsDesired()
    this.onlySendIfDifferentFromLastReading = (sendToHub === 'onlySendIfDifferentFromLastReading')  // 'onlySendIfDifferentFromLastReading' or 'sendAlways'
}

function onOffToBoolean (value) {
    return value === 'ON'
}

function booleanToOnOff (value) {
    return value ? 'ON' : 'OFF'
}

function trueFalseToBoolean (value) {
    return value === 'TRUE'
}

function booleanToTrueFalse (value) {
    return value ? 'TRUE' : 'FALSE'
}

function byteToFloat (value) {
    return parseFloat((value / 255 ).toFixed(3))
}

function floatToByte (value) {
    return parseInt((value * 255).toFixed(0), 10)
}

function byte254ToFloat (value) {
    return parseFloat((value / 254 ).toFixed(3))
}

function floatToByte254 (value) {
    // Return 0 - 254
    return parseInt((value * 254).toFixed(0), 10)
}

function xyToFloat (value) {
    // Input 1 - 65279
    // Return 0 - 1
    return parseFloat((value / 65536).toFixed(5))
}

function floatToXy (value) {
    // Input 0 - 1
    // Return 1 - 65279
    return Math.min(65279, (65536 * value).toFixed(0))
}

function kelvinToFloat (value) {
    // Input 1 - 65279
    // Return 15.31 - 1,000,000
    return parseFloat((1000000 / Math.min(value, 65279)).toFixed(0))
}

function floatToKelvin (value) {
    // Input 1 - 1,000,000
    // Return 1 - 65279
    return Math.max(1, Math.min(65279, (1000000 / value).toFixed(0)))
}

function colorIntToString (value) {
    return {
        0: 'hsb',
        1: 'xy',
        2: 'color_temperature'
    }[value]
}

function colorStringToInt (value) {
    return {
        'hsb': 0,
        'xy': 1,
        'color_temperature': 2
    }[value]
}

function intToPercent (value) {
    return (Math.min(100, Math.max(0, value)) / 100).toFixed(3)
}

function percentToInt (value) {
    return (Math.min(1, Math.max(0, value)) * 100).toFixed(0)
}

function alarmModeIntToString (value) {
    return {
        0: null,
        1: 'alert',
        2: 'tamper',
        3: 'forced_entry'
    }[value]
}

function alarmModeStringToInt (value) {
    return {
        null: 0,
        'alert': 1,
        'tamper': 2,
        'forced_entry': 3
    }[value]
}

function alarmSensitivityToPercent (value) {
    return {
        1: 1.0,
        2: 0.8,
        3: 0.6,
        4: 0.4,
        5: 0.2
    }[value]
}

function alarmPercentToSensitivty (value) {
    if (value > 0.8) return 1
    else if (value > 0.6) return 2
    else if (value > 0.4) return 3
    else if (value > 0.2) return 4
    else return 5
}

// Radio type constants
var ZIGBEE = 0
var ZWAVE = 1
var LUTRON = 2
var KIDDE = 3
var RELAY = 4
var BLUETOOTH = 5

var mappings = [
    ///////////////////////////////////////////////////////////////////
    // See the "Mapping()" function for an explanation of parameters //
    ///////////////////////////////////////////////////////////////////

    //////////////////////////////////////////
    // Zigbee Binary Switches + Light Bulbs //
    //////////////////////////////////////////
    new Mapping(ZIGBEE, 1, 'powered', onOffToBoolean, booleanToOnOff, 'RW', 'sendAlways'),
    new Mapping(ZIGBEE, 2, 'brightness', byteToFloat, floatToByte, 'RW', 'sendAlways'),
    new Mapping(ZIGBEE, 50393088, 'hue', byte254ToFloat, floatToByte254, 'RW', 'sendAlways'),
    new Mapping(ZIGBEE, 50393089, 'saturation', byte254ToFloat, floatToByte254, 'RW', 'sendAlways'),
    new Mapping(ZIGBEE, 50393091, 'color_x', xyToFloat, floatToXy, 'RW', 'sendAlways'),
    new Mapping(ZIGBEE, 50393092, 'color_y', xyToFloat, floatToXy, 'RW', 'sendAlways'),
    new Mapping(ZIGBEE, 50393095, 'color_temperature', kelvinToFloat, floatToKelvin, 'RW', 'sendAlways'),
    new Mapping(ZIGBEE, 50393096, 'color_model', colorIntToString, colorStringToInt, 'R', 'N/A'),
    //new Mapping(ZIGBEE, 4230017024, 'powered', onOffToBoolean, booleanToOnOff, 'sendAlways'),
    // ^^ We can't handle 2 attributes named 'powered', so we won't support attribute 4230017024

    /////////////////////////////////////////
    // Zwave Binary Switches + Light Bulbs //
    /////////////////////////////////////////
    new Mapping(ZWAVE, 2, 'powered', trueFalseToBoolean, booleanToTrueFalse, 'RW', 'sendAlways'),
    new Mapping(ZWAVE, 3, 'brightness', byteToFloat, floatToByte, 'RW', 'sendAlways'),

    /////////////////
    // ZWave Locks //
    /////////////////
    new Mapping(ZWAVE, 10, 'locked', trueFalseToBoolean, booleanToTrueFalse, 'RW', 'sendAlways'),
    new Mapping(ZWAVE, 15, 'battery', intToPercent, percentToInt, 'R', 'N/A'),
    // Lock configuration is an expensive operation, send only if desired state differs from last reading
    new Mapping(ZWAVE, 19, 'beeper_enabled', trueFalseToBoolean, booleanToTrueFalse, 'RW', 'onlySendIfDifferentFromLastReading'),
    new Mapping(ZWAVE, 20, 'vacation_mode_enabled', trueFalseToBoolean, booleanToTrueFalse, 'RW', 'onlySendIfDifferentFromLastReading'),
    new Mapping(ZWAVE, 21, 'alarm_mode', alarmModeIntToString, alarmModeStringToInt, 'RW', 'onlySendIfDifferentFromLastReading'),
    new Mapping(ZWAVE, 22, 'alarm_sensitivity', alarmSensitivityToPercent, alarmPercentToSensitivty, 'RW', 'onlySendIfDifferentFromLastReading'),
    new Mapping(ZWAVE, 23, 'auto_lock_enabled', trueFalseToBoolean, booleanToTrueFalse, 'RW', 'onlySendIfDifferentFromLastReading'),
    new Mapping(ZWAVE, 24, 'alarm_enabled', trueFalseToBoolean, booleanToTrueFalse, 'RW', 'onlySendIfDifferentFromLastReading'),
    // new Mapping(ZWAVE, 25, 'key_code_length', , , 'RW', 'onlySendIfDifferentFromLastReading'),
    // new Mapping(ZWAVE, 26, 'keys_in_use', , , 'R', 'N/A'),
    // ^^ User code related attributes (25+26) are not exposed in LCI

    //////////////////////////////////////////
    // Lutron Binary Switches + Light Bulbs //
    //////////////////////////////////////////
    // Lutron bulbs use brightness = 0 for powered off, then brightness 1-255 for brightness
    new Mapping(LUTRON, 1, 'brightness', byteToFloat, floatToByte, 'RW', 'sendAlways'),

    ///////////////////////
    // Relay dumb switch //
    ///////////////////////
    new Mapping(RELAY, 2, 'powered', trueFalseToBoolean, booleanToTrueFalse, 'RW', 'sendAlways'),

    /////////////////////
    // BLE Light Bulbs //
    /////////////////////
    new Mapping(BLUETOOTH, 1, 'powered', onOffToBoolean, booleanToOnOff, 'RW', 'sendAlways'),
    new Mapping(BLUETOOTH, 2, 'brightness', byteToFloat, floatToByte, 'RW', 'sendAlways'),
    new Mapping(BLUETOOTH, 3, 'color_temperature', kelvinToFloat, floatToKelvin, 'RW', 'sendAlways')
]

var convertersByRadioType = {}
var writableVars = []
var supportedVars = []
var onlySendIfDifferentFromLastReading = []

mappings.forEach(function (mapping) {
    var radioType = convertersByRadioType[mapping.radioType]
    if (radioType == null) {
        radioType = convertersByRadioType[mapping.radioType] = { byFieldName: {}, byAttributeId: {}, nameToId: {}, idToName: {} }
    }
    radioType.byAttributeId[mapping.attributeId] = mapping.aToF
    radioType.byFieldName[mapping.fieldName] = mapping.fToA
    radioType.nameToId[mapping.fieldName] = mapping.attributeId
    radioType.idToName[mapping.attributeId] = mapping.fieldName

    if (supportedVars.indexOf(mapping.fieldName) === -1) {
        supportedVars.push(mapping.fieldName)
    }
    if (mapping.writable && writableVars.indexOf(mapping.fieldName) === -1) {
        writableVars.push(mapping.fieldName)
    }
    if (mapping.onlySendIfDifferentFromLastReading && onlySendIfDifferentFromLastReading.indexOf(mapping.fieldName)) {
        onlySendIfDifferentFromLastReading.push(mapping.fieldName)
    }
})


var convertByFieldName = function (radioType, from) {
    var to = {}
    var converter = convertersByRadioType[radioType]
    for (var fieldName in from) { // eslint-disable-line guard-for-in
        try {
            to[converter.nameToId[fieldName]] = converter.byFieldName[fieldName](from[fieldName])
        }
        catch (err) {
            // do nothing
        }
    }
    return to
}

var convertByAttributeId = function (radioType, from) {
    var to = {}
    var converter = convertersByRadioType[radioType]
    for (var attributeId in from) { // eslint-disable-line guard-for-in
        try {
            to[converter.idToName[attributeId]] = converter.byAttributeId[attributeId](from[attributeId])
        }
        catch (err) {
            // do nothing
        }
    }
    return to
}

var flattenDeviceAttributes = function (device_attributes) {
    var deviceAttributes = {}
    device_attributes.forEach(function (v) {
        deviceAttributes[v.attributeID] = v.value
    })
    return deviceAttributes
}

var expandDeviceAttributes = function (deviceAttributes) {
    var device_attributes = []
    for (var key in deviceAttributes) { // eslint-disable-line guard-for-in
        device_attributes.push({ attributeID: parseInt(key, 10), value: deviceAttributes[key] })
    }
    return device_attributes
}

module.exports = {
    convertByAttributeId: convertByAttributeId,
    convertByFieldName: convertByFieldName,
    flattenDeviceAttributes: flattenDeviceAttributes,
    expandDeviceAttributes: expandDeviceAttributes,
    writableVars: writableVars,
    supportedVars: supportedVars,
    onlySendIfDifferentFromLastReading: onlySendIfDifferentFromLastReading,
    ZIGBEE: ZIGBEE,
    ZWAVE: ZWAVE,
    LUTRON: LUTRON,
    KIDDE: KIDDE,
    RELAY: RELAY,
    BLUETOOTH: BLUETOOTH
}
