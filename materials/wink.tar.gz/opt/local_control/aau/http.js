'use strict'
var cadence       = require('cadence')
  , logger        = require('prolific').createLogger('aau.http')
  , debug         = require('debug')('aau:http')
  , underscore    = require('underscore')
  , Dispatcher    = require('inlet/dispatcher')
  , Authenticator = require('inlet/authenticator')
  , url           = require('url')
  , Config        = require('../util/config')
  , Hub           = require('./hub')
  , os            = require('os')
  , version       = require('../package.json').version

function AAU () {
    this.subscribers = {}
    this.subscriberID = 0
    this._tokens = []
    this._tokensValid = false
    this._desiredStateTimers = {}
    this.drivers = []
    this._desiredStateTimeout = 1000*60*2
    this.platform = os.platform()
}

AAU.prototype.initialize = cadence(function (async, datastore) {
    debug('aau.initialize')
    this.config = new Config(datastore)
    async(function() {
        this.config.read(async())
    }, function () {
        this.config.write(async()) // Write config in case we created a new config (because the config didn't exist)
        this.updateTokens(this.config.extractTokens(), this.config.tokensValid())
        this.hub = new Hub(this)
    }, function () {
        logger.info('startup', { event : 'initialization' })
        debug('aau.initialize finished')
    })
})

AAU.prototype.dispatcher = function () {
    var dispatcher = new Dispatcher(this)
    dispatcher.dispatch('GET /', 'description')
    dispatcher.dispatch('GET /hubs/me', 'versionInfo')
    dispatcher.dispatch('GET /updates.*', 'updates')
    dispatcher.dispatch('GET /devices.*', 'winkDevices')
    dispatcher.dispatch('GET /heartbeat', 'heartbeat')
    dispatcher.dispatch('GET .*', 'get')
    dispatcher.dispatch('PUT /hub_group.*', 'putHubGroup')
    dispatcher.dispatch('PUT .*', 'put')
    dispatcher.dispatch('POST /scenes/inline.*', 'postScene')
    return dispatcher.createDispatcher()
}

AAU.prototype.authenticate = function (request) {
    if (!Authenticator.isBearer(request)) {
        request.raise(401, 'no token provided')
    }
    if (this._tokens.indexOf(request.authorization.credentials) === -1) {
        request.raise(403, 'not authorized')
    }
    if (!this._tokensValid) {
        request.raise(401, 'tokens expired')
    }
}

AAU.prototype.updateTokens = function (tokens, tokensValid) {
    this._tokens = tokens.slice()
    this._tokensValid = tokensValid
}

AAU.prototype.heartbeat = cadence(function () {
    return 'Wink local control server is started'
})

AAU.prototype.description = cadence(function () {
    return this.advertisement.description()
})

AAU.prototype.versionInfo = cadence(function () {
    var versionInfo = {
        model_name: (this.platform === 'android' ? 'Wink Relay' : 'Wink Hub'),
        lci_server_version: version,
        supported_devices: ['light_bulbs', 'binary_switches', 'locks'],
        supported_attributes: this.hub.supportedVars
    }
    return versionInfo
})

AAU.prototype.sendPacket = cadence(function (async, command, record, topic) {
    debug('aau.sendPacket: command ' + command)
    logger.debug('sendPacket', { command: command, record: record })
    async([function () {
        this.resolver.publish('aau', command, record, topic, async())
    }, /^write\safter\send/, function () {
        logger.error('sendPacket', { event : 'Hub socket closed prematurely' })
    }], function () {
        debug('aau.sendPacket: finished')
    })
})

AAU.prototype.packet = cadence(function (async, header, record, topic) {
    debug('aau.packet: header.method ' + header.method)
    logger.debug('packet', { header: header, record: record, topic: topic })
    switch (header.method) {
        case 'authenticate':
            async(function () {
                this.sendPacket('localControlIDResponse', {
                    local_control_id: this.config.id.local_control_id,
                    local_control_public_key_hash: this.config.id.sha256,
                    topic: 0,
                    client_token: 'localControlServer'
                }, async())
            }, function () {
                this.sendPacket('get_devices', {
                    topic: 0,
                    client_token: 'localControlServer'
                }, async())
            })
            break
        case 'localControlIDRequest':
            this.sendPacket('localControlIDResponse', {
                local_control_id: this.config.id.local_control_id,
                local_control_public_key_hash: this.config.id.sha256,
                topic: record.topic,
                client_token: record.client_token
            }, async())
            break
        case 'clientLocalControlTokenSet':
            async(function () {
                this.config.writeTokenArray(record.tokens, async())
            }, function () {
                this.updateTokens(this.config.extractTokens(), this.config.tokensValid())
                this.sendPacket('clientLocalControlTokenResponse', {
                    tokens: this.config.tokens.access_tokens,
                    topic: record.topic,
                    client_token: record.client_token
                }, async())
            })
            break
        case 'clientLocalControlTokenRequest':
            this.sendPacket('clientLocalControlTokenResponse', {
                tokens: this.config.tokens.access_tokens,
                topic: record.topic,
                client_token: record.client_token
            }, async())
            break
        case 'devices':
        case 'deviceDetails':
        case 'deviceState':
            this.hub.processHubPacket(header, record, async())
            break
        case 'localControlCommand':
            switch (record.local_control_command) {
                case 'resetIdAndTokens':
                    logger.warn('packet', { action: 'Resetting ID and Tokens', record: record })
                    async(function () {
                        this.config.resetIdAndTokens(async())
                    }, function (){
                        this.updateTokens(this.config.extractTokens(), this.config.tokensValid())
                        this.advertisement.changeId(this.config.id.local_control_id)
                    })
                    break
                default:
                    logger.error('packet', { error: 'Unsupported local control command' })
            }
            break
        // ------- intentionally unhandled packet types --------- //
        //case 'receipt':
        //case 'ping':
        //case 'error':
        //case 'status':
        //    break
        default:
    }
})

/* generic properties

   readonly: {
          xxx_id                    : numeric-string

        , capabilities              : {}
        , manufacturer_device_model : string
        , manufacturer_device_id    : string
        , manufacturer_device_type  : string || null
        , device_manufacturer       : string || null
        , model_name                : string || null
        , upc_id                    : string || null
        , local_id                  : string || null
        , radio_type                : string || null

        , {:device_type}_id         : numeric-string
        , object_id                 :   ..
        , object_type               : string
        , discovered_at             : seconds since epoch
    }

    writable: {
          name                      : string

        // immutable: added on POST when created for use with /users/me/wink_devices
        , server_object_id          : numeric-string

        // magical: updated automatically
        , created_at                : seconds since epoch (added on POST)
        , updated_at                : seconds since epoch (updated on PUT)
        , last_reading              : { ... }

        // mutable: added on POST, updated on PUT
        , locale                    : string // e.g., 'en_us'
        , units                     : {}
        , hidden_at                 : seconds since epoch

        // updateable: updated on PUT
        , desired_state             : { ... }
    }
 */


AAU.prototype.get = cadence(function (async, request) {
    this.authenticate(request)
    var deviceID = url.parse(request.url).pathname.split('/')[2] || -1
      , deviceReadonly = this.config.devices_readonly[deviceID]
      , deviceWritable = this.config.devices_writable[deviceID]
      , driver = this.drivers[deviceID]

    if ((!deviceReadonly) ||
        (!deviceWritable)) {
        request.raise(404, 'device not found')
    }

    if (!deviceWritable.created_at || !driver) {
        request.raise(501, 'device driver not initialized')
    }

    return { data : this.list_device(deviceID), errors : [], pagination : {} }
})

AAU.prototype.put = cadence(function (async, request) {
    debug('aau.put: request from ' + request.connection.remoteAddress)
    this.authenticate(request)
    debug('aau.put: authenticated ' + request.connection.remoteAddress)
    var options = request.body
      , deviceID = url.parse(request.url).pathname.split('/')[2] || -1
      , deviceReadonly = this.config.devices_readonly[deviceID]
      , deviceWritable = this.config.devices_writable[deviceID]
      , driver = this.drivers[deviceID]

    if (!deviceReadonly || !deviceWritable) {
        request.raise(404, 'not found')
    }

    if (!deviceWritable.created_at || !driver) {
        request.raise(501, 'device driver not initialized')
    }

    if (!deviceWritable.desired_state) {
        request.raise(501, 'device write properties not initialized')
    }

    if (!options || !options.desired_state) {
        request.raise(400, 'no body.desired_state')
    }

    var actor = {
        nonce: options.nonce,
        oauth: 'client_token:' + request.authorization.credentials
    }
    if (!this.downsync(deviceID, options.name, options.desired_state, actor)) {
        request.raise(500, 'error sending desired state')
    }

    debug('aau.put: finished request from ' + request.connection.remoteAddress)
    return { data : this.list_device(deviceID), errors : [], pagination : {} }
})

AAU.prototype.putHubGroup = cadence(function (async, request) {
    debug('aau.putHubGroup: request from ' + request.connection.remoteAddress)
    this.authenticate(request)
    debug('aau.putHubGroup: authenticated ' + request.connection.remoteAddress)
    var options = request.body

    if (!options || !options.desired_state) {
        request.raise(400, 'no body.desired_state')
    }
    if (!options.local_id_array) {
        request.raise(400, 'no body.local_id_array')
    }

    var driver = this.drivers[options.local_id_array[0]] // TODO: find a better way to reference the hub driver
    if (!driver || !driver.sync) {
        request.raise(501, 'hub driver not initialized')
    }

    var actor = {
        nonce: options.nonce,
        oauth: 'client_token:' + request.authorization.credentials
    }
    if (!this.downsyncHubGroup(options.local_id_array, options.desired_state, actor)) {
        request.raise(500, 'at least 1 error sending desired state')
    }

    debug('aau.putHubGroup: finished request from ' + request.connection.remoteAddress)
    return { message : 'group success', errors : [], pagination : {} }
})

AAU.prototype.postScene = cadence(function (async, request) {
    debug('aau.postScene: request from ' + request.connection.remoteAddress)
    this.authenticate(request)
    debug('aau.postScene: authenticated ' + request.connection.remoteAddress)
    var options = request.body

    if (!options || !options.scene) {
        request.raise(400, 'no body.scene')
    }

    if (!Array.isArray(options.scene)) {
        request.raise(400, 'scene request not an array')
    }

    var actor = {
        nonce: options.nonce,
        oauth: 'client_token:' + request.authorization.credentials
    }
    if (!this.processScene(options.scene, actor)) {
        request.raise(500, 'at least 1 error sending desired state')
    }

    debug('aau.postScene: finished request from ' + request.connection.remoteAddress)
    return { message : 'scene success', errors : [], pagination : {} }
})

AAU.prototype.winkDevices = cadence(function (async, request) {
    this.authenticate(request)
    var result

    result = this.list_devices('hub_device')
    return { data : result, errors : [], pagination : { count : result.length } }
})

AAU.prototype.list_devices = function (deviceType) {
    var deviceID, result
    result = []
    for (deviceID in this.config.devices_readonly) {
        if (!this.config.devices_writable[deviceID].created_at) continue
        if ((deviceType) && (deviceType !== this.config.devices_readonly[deviceID].object_type)) continue
        result.push(this.list_device(deviceID))
    }

    return result
}

AAU.prototype.list_device = function (deviceID) {
    debug('aau.list_device: deviceID ' + deviceID)
    var lastReading, result
    lastReading = underscore.extend( {}
                                   , this.config.devices_readonly[deviceID].last_reading
                                   , this.config.devices_writable[deviceID].last_reading)
    result = underscore.extend( {}
                              , underscore.omit(this.config.devices_readonly[deviceID], 'object_id')
                              , this.config.devices_writable[deviceID]
                              , { last_reading : lastReading })
    return result
}

/* Returns deviceID or undefined if device does not exist */
AAU.prototype.lookupDeviceIDbyLocalID = function (local_id) {
    // Optimization: right now, device ID is always local id
    if (this.config.devices_readonly[local_id]) return local_id
    else return undefined

    /*
    var deviceID, deviceReadonly
    for (deviceID in this.config.devices_readonly) {
        deviceReadonly = this.config.devices_readonly[deviceID]
        if (!deviceReadonly) continue
        if (deviceReadonly.local_id == local_id) return deviceID
    }
    */
}

AAU.prototype.unregister = function (local_id) {
    var deviceID = this.lookupDeviceIDbyLocalID(local_id)
    if (deviceID != null) {
        this.desiredStateTimer(deviceID, true)
        delete this.config.devices_readonly[deviceID]
        delete this.config.devices_writable[deviceID]
        delete this.drivers[deviceID]
    }
}

AAU.prototype.register = function (driver, deviceType, deviceParams, lastReadingVars, desiredStateVars) {
    var deviceID, deviceReadonly, deviceWritable, desiredState, lastReading, readOnlyVars

    deviceID = this.lookupDeviceIDbyLocalID(deviceParams.local_id)
    if (deviceID == null) {
        //TODO: How will we assign deviceIDs to non-hub devices? thought: make non-hub devices alpha instead of numeric?
        deviceID = deviceParams.local_id
        this.config.devices_readonly[deviceID] = {}
        this.config.devices_writable[deviceID] = {}
    }

    lastReading = {}
    lastReadingVars.forEach(function (v) { lastReading[v] = null })
    lastReading.connection = false
    desiredState = {}
    desiredStateVars.forEach(function (v) { desiredState[v] = null })

    readOnlyVars = [
        'capabilities', 'manufacturer_device_model', 'manufacturer_device_id', 'manufacturer_device_type'
      , 'device_manufacturer', 'model_name' , 'upc_id', 'local_id', 'radio_type'
    ]

    deviceReadonly = {}
    deviceReadonly[deviceType + '_id'] = deviceID.toString()
    //device_readonly[] gets a copy of last_reading and desired_state with "null" in each value

    underscore.extend(deviceReadonly
                      , { object_id     : deviceID.toString()
                        , object_type   : deviceType
                        , discovered_at : this.config.devices_readonly[deviceID].discovered_at
                        , last_reading  : lastReading
                        , desired_state : desiredState
                        }
                      , underscore.pick(deviceParams, readOnlyVars))

    if (!underscore.isEqual(this.config.devices_readonly[deviceID], deviceReadonly)) {
        deviceReadonly.discovered_at = Date.now() / 1000
        this.config.devices_readonly[deviceID] = deviceReadonly
    }
    deviceWritable =
        underscore.extend({}, this.config.devices_writable[deviceID]
                            , underscore.omit(deviceParams, readOnlyVars)
                            , { desired_state: {} } )
    this.config.devices_writable[deviceID] = deviceWritable
    this.drivers[deviceID] = driver

    return deviceID
}

AAU.prototype.upsync = function (deviceID, deviceName, lastReading, actor) {
    debug('aau.upsync: deviceID ' + deviceID)
    var now, updated, v
      , deviceReadonly = this.config.devices_readonly[deviceID]
      , deviceWritable = this.config.devices_writable[deviceID]
    logger.debug('upsync', { deviceID: deviceID , deviceReading: JSON.stringify(lastReading) } )
    if (!deviceReadonly || !deviceWritable) {
        logger.error('upsync', { message : 'no such device', deviceID : deviceID})
        return
    }

    if (deviceName && (deviceWritable.name !== deviceName)) {
        this.config.devices_writable[deviceID].name = deviceName
        updated = true
    }
    now = Date.now() / 1000

    if (typeof lastReading.connection === 'undefined') lastReading.connection = true
    for (v in deviceReadonly.last_reading) {
        if (typeof lastReading[v] === 'undefined') continue
        if (!deviceWritable.last_reading) deviceWritable.last_reading = {}
        if (deviceWritable.last_reading[v] === lastReading[v]) continue
        deviceWritable.last_reading[v] = lastReading[v]
        updated = true
    }
    if (deviceWritable.created_at) {
        if (! underscore.isEqual(deviceWritable.desired_state, {})) {
            deviceWritable.desired_state = {}
            updated = true
        }
    }

    if (updated && deviceWritable.created_at) {
        deviceWritable.updated_at = now
        this.config.devices_writable[deviceID] = deviceWritable
    }

    this.desiredStateTimer(deviceID, true)

    logger.debug('upsync', { event : 'upsync' , deviceWritable : this.config.devices_writable[deviceID] })
    if (updated) {
        // if actor was undefined, create property 'nonce' so we don't crash
        actor = actor || { nonce: null } // eslint-disable-line no-param-reassign
        this.publish(deviceID, actor.nonce)
    }
}

/* Parses an array of desired states and passes them to the hub driver.
 * Return: false on any error, true on total success */
AAU.prototype.processScene = function (reqArray, actor) {
    var i
      , len = reqArray.length
      , ret = true

    for (i = 0; i < len; i++) {
        if (reqArray[i].local_id) {
            if (!this.downsync(reqArray[i].local_id, reqArray[i].name, reqArray[i].desired_state, actor)) {
                ret = false
            }
        }
        else if (reqArray[i].local_id_array) {
            if (!this.downsyncHubGroup(reqArray[i].local_id_array, reqArray[i].desired_state, actor)) {
                ret = false
            }
        }
        else {
            logger.error('processScene', { message : 'array element has no id field', elementIndex : i })
            ret = false
        }
    }

    return ret
}

/* Sends a desiredState to the hub driver.
 * Return: false on error, true on success */
AAU.prototype.downsync = function (deviceID, deviceName, desiredState, actor) {
    debug('aau.downsync: deviceID ' + deviceID)
    var driver = this.drivers[deviceID]

    if (!driver || !driver.sync) {
        logger.error('downsync', {
            event : 'fetch device driver', message : 'device not initialized', deviceID : deviceID
        })
        return false
    }

    var updated = this.updateDesiredState(deviceID, desiredState)

    if (!driver.sync(deviceID, deviceName, desiredState, actor)) {
        return false
    }

    if (updated) {
        this.publish(deviceID, actor.nonce)
    }

    return true
}

/* Sends a desiredState array to the hub driver.
 * Return: false on any error, true on total success */
AAU.prototype.downsyncHubGroup = function (deviceIDArray, desiredState, actor) {
    debug('aau.downsyncHubGroup: deviceIDArray[0] ' + deviceIDArray[0])
    var arrayLength = deviceIDArray.length
    for (var i = 0; i < arrayLength; i++) {
        this.updateDesiredState(deviceIDArray[i], desiredState)
    }

    var driver = this.drivers[deviceIDArray[0]] // TODO: find a better way to reference the hub driver
    if (!driver || !driver.sync) {
        logger.error('downsync', {
            event : 'fetch device driver', message : 'device not initialized', deviceID : deviceIDArray[0]
        })
        return false
    }

    if (!driver.syncGroup(deviceIDArray, desiredState, actor)) {
        return false
    }

    return true
}

AAU.prototype.updateDesiredState = function (deviceID, desiredState) {
    debug('aau.updateDesiredState: deviceID ' + deviceID)
    var deviceReadonly = this.config.devices_readonly[deviceID]
      , deviceWritable = this.config.devices_writable[deviceID]
      , updated = false

    if (!deviceReadonly || !deviceWritable) {
        logger.error('updateDesiredState', {
            event : 'fetch device', message : 'no such device', deviceID : deviceID
        })
        return updated
    }

    if (underscore.isEqual(desiredState, deviceWritable.desired_state)) return updated

    updated = true
    for (var v in deviceReadonly.desired_state) {
        if (typeof desiredState[v] === 'undefined') {
            delete deviceWritable.desired_state[v]
            continue
        }
        deviceWritable.desired_state[v] = desiredState[v]
    }

    this.desiredStateTimer(deviceID)
    return updated
}

AAU.prototype.desiredStateTimer = function (deviceID, clear) {
    debug('aau.desiredStateTimer: deviceID ' + deviceID)
    clearTimeout(this._desiredStateTimers[deviceID])
    delete this._desiredStateTimers[deviceID]
    if (clear) return

    this._desiredStateTimers[deviceID] = setTimeout(
        (function (scope) {
            return function () { scope.clearDesiredState(deviceID) }
        })(this), this._desiredStateTimeout)
}

AAU.prototype.clearDesiredState = function (deviceID) {
    debug('aau.clearDesiredState: deviceID ' + deviceID)
    var updated = this.updateDesiredState(deviceID, {})
    if (updated) {
        this.publish(deviceID, null)
    }
}

AAU.prototype.publish = function (deviceID, nonce) {
    debug('aau.publish: deviceID ' + deviceID + ' nonce ' + nonce)
    if (!this.config.devices_writable[deviceID]) return
    var data = this.list_device(deviceID, true)
    data.nonce = nonce
    this.publish_device('PUT', data)
}

AAU.prototype.keepAlive = function () {
    this.streamMessage('keep-alive', null)
}

AAU.prototype.publish_device = function (method, object) {
    var path = object.object_type + '/' + object.object_id
      , data = method !== 'DELETE' ? object : null
    this.streamMessage(method, { path : path, data : data })
}

AAU.prototype.publish_notify = function (object) {
    this.streamMessage('PUT', { data : object })
}

AAU.prototype._disconnector = function (event, client, id) {
    return function (error) {
        var message = {
            client: client
        }
        if (error) {
            message.stack = error.stack
        }
        debug('aau._disconnector: [id ' + id + '] event ' + event)
        logger.debug('streaming-' + event, message)
        delete this.subscribers[id]
    }.bind(this)
}

AAU.prototype.updates = cadence(function (async, request) { /*jshint unused: false */
    this.authenticate(request)
    return this.add_subscriber.bind(this)
})

AAU.prototype.add_subscriber = function (response) {
    var client = response.socket.remoteAddress + ':' + response.socket.remotePort
      , sid    = this.subscriberID++
    debug('aau.add_subscriber: [id ' + sid + '] remoteAddress ' + response.socket.remoteAddress)

    this.subscribers[sid] = response

    response
        .on('close', this._disconnector('close', client, sid))
        .on('error', this._disconnector('error', client, sid))

    response.socket.setNoDelay()

    response.setHeader('Content-Type', 'text/event-stream')
    response.setHeader('Cache-Control', 'private, no-cache, max-agent=0')
    response.setHeader('Access-Control-Allow-Origin', '*')
    response.setHeader('Transfer-Encoding', 'none')
}

AAU.prototype.streamMessage = function (event, data) {
    var message = 'event: ' + event + '\r\ndata: ' + JSON.stringify(data) + '\r\n\r\n'
    for (var response in this.subscribers) { // eslint-disable-line guard-for-in
        debug('aau.streamMessage: event ' + event)
        // response.write() is async (it sends data to kernel buffer).
        // It does not accept a callback in this node version (10.40)
        this.subscribers[response].write(message)
    }
}

module.exports = AAU
