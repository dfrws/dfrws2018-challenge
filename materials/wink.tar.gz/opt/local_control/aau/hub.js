'use strict'
/* NOTE WELL:
 *  this module contains intellectural property owned by Wink, Inc.
 *
 * aau/hub.js
 * Summary: communication module between hub process and the local control server
 *
 */


var cadence     = require('cadence')
  , logger      = require('prolific').createLogger('aau.hub')
  , debug       = require('debug')('aau:hub')
  , underscore  = require('underscore')
  , converter   = require('./converter')

function Hub (invoker) {
    this.invoker = invoker
    this.devices = {}
    this.supportedVars = converter.supportedVars
}

Hub.prototype.processHubPacket = cadence(function (async, header, record) {
    debug('hub.processHubPacket: header.method ' + header.method)
    async(function () {
        switch (header.method) {
            case 'devices':
                this.process_devices(record, async())
                break
            case 'deviceDetails':
                // No useful information in these
                break
            case 'deviceState':
                this.process_deviceState(record, async())
                break
            default:
                logger.error('process_device', { event : 'process_device'
                                               , message : 'can\'t handle record type'
                                               , method : header.method
                                               })
                break
        }
    })
})

Hub.prototype.process_devices = cadence(function (async, record) {
    debug('hub.process_devices')
    var activeLocalIDs = []
    var registeredLocalIDs = []
    for (var deviceID in this.devices) { // eslint-disable-line guard-for-in
        registeredLocalIDs.push(this.devices[deviceID].local_id)
    }

    async(function () {
        async.forEach(function (rDevice) {
            var localID = rDevice.deviceID
            activeLocalIDs.push(localID)
            // Register the device if needed
            if (this.lookupDeviceIDbyLocalID(localID) == null) {
                var device = {}
                device.local_id     = localID
                device.device_name  = rDevice.deviceName
                device.radio_type   = rDevice.radioType
                device.object_type  = 'hub_device'
                this.register(device, async())
            }
        })(record.repeated_devices)
    }, function () {
        underscore.difference(registeredLocalIDs, activeLocalIDs).forEach(this.unregister, this)
    })
})

/* hub.lookupDeviceIDbyLocalID returns the deviceID or undefined if the localID doesn't exist */
Hub.prototype.lookupDeviceIDbyLocalID = function (localID) {
    debug('hub.lookupDeviceIDbyLocalID: localID ' + localID)
    // Optimization: for now, deviceIDs always == localID
    if (this.devices[localID]) return localID
    else return undefined

    /*
    for (var deviceID in this.devices){
        if (this.devices[deviceID].local_id == localID) return this.devices[deviceID].device_id
    }
    */
}

Hub.prototype.process_deviceState = cadence(function (async, record) {
    debug('hub.process_deviceState: record.deviceID ' + record.deviceID)
    var lastReading = {}
      , deviceAttributes = []
      , radioType
      , actor
      , deviceID = this.lookupDeviceIDbyLocalID(record.deviceID)

    if (deviceID == null) {
        logger.error('hub.process_DeviceState', {
            record: record,
            message: 'Cannot process deviceState before device initialized'
            // Device is iniatialized by a `devices` packet
        })
        return
    }

    radioType = this.devices[deviceID].radio_type
    // note: it is record.device_attributes, not record.deviceAttributes
    deviceAttributes = converter.flattenDeviceAttributes(record.device_attributes)
    lastReading = converter.convertByAttributeId(radioType, deviceAttributes)
    try {
        lastReading.connection = record.online ? true : false
    }
    catch (err) {
        // pass
    }
    actor = {
        nonce: record.topic,
        client_token: record.client_token
    }
    // Lutron devices (radioType 2) and ZW Dimmers (radio 1) don't have a powered, only a brightness 0-256
    // Brightness 0 means powered off
    if (lastReading.powered == null && lastReading.brightness != null) {
        lastReading.powered = (lastReading.brightness !== 0)
    }

    async(function () {
        this.update(deviceID, lastReading, actor, async())
    })
})

Hub.prototype.unregister = function (localID) {
    debug('hub.unregister: localID ' + localID)
    var deviceID = this.lookupDeviceIDbyLocalID(localID)
    delete this.devices[deviceID]
    this.invoker.unregister(deviceID)
}

/* hub.register is used to register a new device or new device parameters with the AAU */
Hub.prototype.register = cadence(function (async, device) {
    /* device should, at minimum, have the following:
        device.local_id, device.device_name,
        device.radio_type, device.object_type */
    debug('hub.register: device.local_id ' + device.local_id)

    /* hub devices should be registered with:
        params.created_at, params.local_id */
    var getDeviceState = false
    if (!device.params) {
        device.params = {}
        device.params.created_at = Date.now() / 1000
        device.params.local_id = device.local_id
        // this device is being registered for the first time, get a deviceState
        getDeviceState = true
    }
    if (!device.lastReadingVars) { device.lastReadingVars = [ 'connection' ] }
    if (!device.desiredStateVars) { device.desiredStateVars = [ ] }

    // Populate device.lastReadingVars with all field in device.last_reading
    for (var v in device.last_reading) {
        if (!underscore.contains(device.lastReadingVars, v) ) {
            device.lastReadingVars.push(v)
        }
    }
    // Populate device.desiredStateVars
    device.desiredStateVars = underscore.intersection( device.lastReadingVars, converter.writableVars )

    logger.debug('new hub device or attributes', { local_id: device.local_id, event : 'register' }, device)

    var deviceID = this.invoker.register( this,
                           device.object_type,
                           device.params,
                           device.lastReadingVars,
                           device.desiredStateVars )
    device.device_id = deviceID
    this.devices[deviceID] = device

    if (getDeviceState) {
        async(function (){
            this.invoker.sendPacket('getDeviceState', {
                deviceID: device.local_id,
                topic: 0,
                client_token: 'localControlServer'
            }, null, async())
        })
    }
})

/* Upates the last reading in the main local control server module aau/http.js */
Hub.prototype.update = cadence(function (async, deviceID, lastReading, actor) {
    debug('hub.update: deviceID ' + deviceID)
    var device = this.devices[deviceID]
      , registerNeeded = false

    if (!device.last_reading) {
        device.last_reading = {}
    }

    async(function () {
        for (var v in lastReading) {
            // insert all "last reading" characteristics into the device record
            if ( !underscore.contains(device.lastReadingVars, v) ) {registerNeeded = true}
            if (v === 'brightness' && lastReading.brightness === 0) {
                // if brightess == 0, display the last non-zero brightness (default to 1.0)
                device.last_reading.brightness = device.last_reading.brightness || 1.0 // catches undefined and null
                continue
            }
            device.last_reading[v] = lastReading[v]
        }
        if (registerNeeded) { this.register(device, async()) }
    }, function () {
        this.invoker.upsync(deviceID, device.device_name, device.last_reading, actor)
    })
})

/* Translates a desiredState from API attributes and sends them to the hub socket driver
 * Return: false on error, true on success */
Hub.prototype.sync = function (deviceID, deviceName, desiredState, actor) {
    debug('hub.sync: deviceID ' + deviceID)
    var packet = {},
        deviceAttributes = {},
        device = this.devices[deviceID]

    if (!device) {
        logger.error('sync', { event: 'sync', deviceID: deviceID, message: 'unknown deviceID' })
        return false
    }

    this.checkPoweredBrightness(device.radio_type, desiredState)
    this.checkRGB(device.radio_type, desiredState)
    this.checkLastReadingEqualsDesired(device.last_reading, desiredState)
    deviceAttributes = converter.convertByFieldName(device.radio_type, desiredState)
    packet.device_attributes = converter.expandDeviceAttributes(deviceAttributes)
    packet.deviceID = device.local_id
    packet.client_token = actor.oauth
    packet.topic = actor.nonce
    this.invoker.sendPacket('setDeviceAttributes', packet, null, logger.rescue('hub.sync', {
        event: 'sync', deviceID: deviceID
    }))
    return true
}

/* Sends a desiredState for an array of devices from a client to the hub
 * Return: false on any error on any device, true on total success */
Hub.prototype.syncGroup = function (deviceIDs, desiredState, actor) {
    debug('hub.syncGroup: deviceIDs[0] ' + deviceIDs[0])
    var devicesByRadioType = {}
      , ret = true

    // create an array of hashes {radioType: deviceIDs[], radioType2: deviceIDs[]}
    for (var id in deviceIDs) { // eslint-disable-line guard-for-in
        var device = this.devices[deviceIDs[id]]
        if (!device) {
            logger.error('syncGroup', { event: 'syncGroup', group: deviceIDs, deviceID: deviceIDs[id], message: 'unknown deviceID in group' })
            ret = false
            continue
        }
        if (!devicesByRadioType.hasOwnProperty(device.radio_type)) {
            devicesByRadioType[device.radio_type] = []
        }
        devicesByRadioType[device.radio_type].push({deviceID: device.local_id})
    }

    if (underscore.isEmpty(devicesByRadioType)) {
        logger.error('syncGroup', { event: 'syncGroup', group: deviceIDs, message: 'group has no valid deviceIDs' })
        return false
    }


    for (var radioType in devicesByRadioType) { // eslint-disable-line guard-for-in
        this.checkPoweredBrightness(radioType, desiredState)
        this.checkRGB(radioType, desiredState)
        var deviceAttributes = converter.convertByFieldName(radioType, desiredState)
        var packet = {}
        packet.device_attributes = converter.expandDeviceAttributes(deviceAttributes)
        packet.radioType = radioType
        packet.devices = devicesByRadioType[radioType]
        packet.client_token = actor.oauth
        packet.topic = actor.nonce
        this.invoker.sendPacket('setDeviceArrayAttributes', packet, null, logger.rescue('hub.syncGroup', {
            event: 'sync', group: deviceIDs
        }))
    }
    return ret
}

Hub.prototype.checkPoweredBrightness = function (radioType, desiredState) {
    // If we get a 'powered', we may need to manipulate 'brightness'
    // The hub can handle only 'brightness' with no 'powered', but ZW and Lutron devices _require_ 'brightness' always
    // NB: remember that, in js, objects are passed by reference! So this modifies the desiredState directly
    if (desiredState.powered != null) { // checks null and undefined
        if (desiredState.powered === true || desiredState.powered === 'true') {
            // Handle the case where we get a 'powered' with brightness 0
            if (parseFloat(desiredState.brightness) === 0) {
                desiredState.brightness = '1.000'
            }
            else {
                // Handles the case where brightness == undefined or null
                desiredState.brightness = desiredState.brightness || '1.000'
            }
        // Handle the case where powered == false (and brightness is non-zero or not present)
        } else {
            // ZW and Lutron use (brightness = 0) for powered off
            if (radioType == converter.ZWAVE || radioType == converter.LUTRON){ // eslint-disable-line eqeqeq
                desiredState.brightness = 0
            }
            // On the other hand, for Zigbee bulbs, we should not send brightness, so they retain the same value
            if (radioType == converter.ZIGBEE) { // eslint-disable-line eqeqeq
                delete desiredState.brightness
            }
        }
    }
}

Hub.prototype.checkRGB = function (radioType, desiredState) {
    // Client may send both HSB and Color Temp attributes, so
    // we should filter based on the 'color_model' field.
    // The only RGB bulbs are Zigbee, at the moment.
    if (radioType == converter.ZIGBEE) { // eslint-disable-line eqeqeq
        if (desiredState.color_model != null) {
            switch (desiredState.color_model) {
                case 'color_temperature':
                    delete desiredState.hue
                    delete desiredState.saturation
                    delete desiredState.color_x
                    delete desiredState.color_y
                    break
                case 'hsb':
                    delete desiredState.color_temperature
                    delete desiredState.color_x
                    delete desiredState.color_y
                    break
                case 'xy':
                    delete desiredState.color_temperature
                    delete desiredState.hue
                    delete desiredState.saturation
                    break
                default:
                    logger.error('checkRGB', {error: 'Bad color model', desiredState: desiredState})
            }
            delete desiredState.color_model  // read-only attribute
        }
    }
}

Hub.prototype.checkLastReadingEqualsDesired = function (lastReading, desiredState) {
    // Some hub properties are expensive to set, so we should only send them
    // if the property differs from our last reading.
    for (var v in desiredState) {
        if (converter.onlySendIfDifferentFromLastReading.indexOf(v) !== -1) {
            if (desiredState[v] == lastReading[v]) { // eslint-disable-line eqeqeq
                delete desiredState[v]
            }
        }
    }
}

module.exports = Hub
