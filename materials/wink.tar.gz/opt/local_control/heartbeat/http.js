'use strict'
var cadence    = require('cadence')
  , logger     = require('prolific').createLogger('heartbeat.http')
  , Dispatcher = require('inlet/dispatcher')


function Heartbeat () {
    logger.info('startup', { event : 'initialization' })
}

Heartbeat.prototype.dispatcher = function () {
    var dispatcher = new Dispatcher(this)
    dispatcher.dispatch('GET /', 'index')
    return dispatcher.createDispatcher()
}


Heartbeat.prototype.index = cadence(function (async, request) { // eslint-disable-line no-unused-vars
    logger.info('beat')
    return 'AAU Heartbeat Server'
})

module.exports = Heartbeat
