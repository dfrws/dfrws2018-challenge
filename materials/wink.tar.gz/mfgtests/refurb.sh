#!/bin/sh
# /mfgtest/refurb.sh
# Refurbishment mode script for hub

logger -p info -s "Launching refurb mode script"

# Set LED flashing red
set_rgb 200 0 0 0 0 0 flash 250000

# Make sure the ZigBee co-proc is updated
if [ ! -e /database/zigbee-version.txt ]; then
    logger -p crit -s "ZigBee co-proc version unknown"
    exit 1
fi

if [ "$(cat /database/zigbee-version.txt)" != "5.1.2.1" ]; then
    logger -p crit -s "ZigBee co-proc version incorrect"
    exit 1
fi
logger -p info -s "Successfully verified zigbee version"

# Bring up network interface
if /sbin/ifup -a; then
    logger -p info -s "Successfully brought up network interface"
else
    logger -p crit -s "Failed to bring up interface"
    exit 1
fi

# Start wireless radio
insmod /root/wifi/dhd.ko firmware_path="/root/wifi/fw_prod.bin" nvram_path="/root/wifi/nvram.conf" iface_name=wlan0 dhd_sdiod_drive_strength=8
if  /root/wifi/wl up; then
    logger -p info -s "Successfully started wireless radio"
else
    logger -p crit -s "Failed to bring up wireless interface"
    exit 1
fi

# Start bluetooth
insmod /root/bt/compat.ko
insmod /root/bt/bluetooth.ko
insmod /root/bt/hci_uart.ko
/root/bt/brcm_patchram_plus --baudrate 4000000 --use_baudrate_for_download --no2bytes --enable_lpm --enable_hci --bd_addr C4:01:de:ad:be:ef --patchram /root/bt/BCM4334B0_002.001.013.1806.0000_Confocus_Apron_TEST_ONLY.hcd /dev/ttySP0 &
sleep 4
if hciconfig hci0 up; then
    logger -p info -s "Successfully started BT radio"
else
    logger -p crit -s "Failed to bring up BT interface"
    exit 1
fi

# Start ZigbeeHACoord
if ZigBeeHACoord -n 1 -p ttySP4 -Q -I /root/platform/zigbee-ota-images </dev/null >&0 2>&0; then
    logger -p info -s "Successfully started ZigBeeHACoord"
else
    logger -p crit -s "Failed to start ZigBeeHACoord"
    exit 1
fi

# Start Lutron-core
if /usr/sbin/lutron-core; then
    logger -p info -s "Successfully started lutron-core"
else
    logger -p crit -s "Failed to start lutron-core"
    exit 1
fi

# Test Zwave
if zwavetest /dev/ttySP1; then
    logger -p info -s "Successfully tested zwave"
else
    logger -p crit -s "Failed zwavetest"
    exit 1
fi

logger -p info -s "Sleeping for 5 seconds for radios to start"
sleep 5

# Start Apron so we can use aprontest
if /usr/sbin/aprond; then
    logger -p info -s "Successfully started apron"
else
    logger -p crit -s "Failed to start aprond"
    exit 1
fi

logger -p info -s "Sleeping for 10 seconds for apron to start"
sleep 10

# Use aprontest to reset zwave controller, it also handles creating a new z-wave home ID
if aprontest --zwave_controller_reset; then
    logger -p info -s "Successfully reset zwave controller"
else
    logger -p crit -s "Failed to reset zwave controller"
    exit 1
fi

logger -p crit -s "Refurb complete...SUCCESS"

exit 0
