#!/bin/sh

LUTRON_DEV=/dev/ttySP2
LUTRON_COPROC_UPDATE_BIN=/usr/sbin/lutron-coproc-firmware-update-app
LUTRON_CORE_BIN=/usr/sbin/lutron-core
LUTRON_CLIENT_BIN=/usr/sbin/lutron-core-client

lutron_flash () {
    # If you want this to be quiet, add the '-s' flag.
    "$LUTRON_COPROC_UPDATE_BIN" "$LUTRON_DEV"
}

lutron_start () {
    "$LUTRON_CORE_BIN"
    sleep 1
}

lutron_ping () {
    local status

    # Leaving response global for debugging purposes
    response="$("$LUTRON_CLIENT_BIN" \
            -d '{"cmd":"Ping","args":{}}' \
            -o '{"cmd":"PingResponse"}' \
            -t 5
        )" || return 1

    printf "%s\n" "$response" | \
        grep -q '^{"cmd":"PingResponse","args":{"Status":[012]}}$' \
        || return 1

    status="$(printf "%s\n" "$response" | \
        grep -o '"Status":[012]')" \
        || return 1
    status="${status##*:}"
    printf "%d" "$status"
    return 0
}

lutron_enable_rf () {
    response="$("$LUTRON_CLIENT_BIN" \
            -d '{"cmd":"SetFunctionTestsComplete","args":{}}' \
            -o '{"cmd":"SetFunctionTestsCompleteResponse"}' \
            -t 5
        )" || return 1
    [ "$response" = '{"cmd":"SetFunctionTestsCompleteResponse","args":{}}' ] \
        || return 1
}

die () {
    echo FAILED
    exit 1
}

echo "Updating Lutron coprocessor firmware"
lutron_flash || die

echo "Starting Lutron core daemon"
lutron_start || die

redo=true
while "$redo" ; do
    redo=false
    echo "Checking Lutron device status"
    status="$(lutron_ping)" || die
    case "$status" in
        0)
            echo "Device ready for normal operation; no setup needed"
            ;;
        1)
            echo "Device is ready for RF testing"
            ;;
        2)
            echo "Not function tested; Lutron radio not active"
            echo "Enabling Lutron radio"
            lutron_enable_rf || die
            redo=true
            ;;
        *)
            echo "Error parsing device status: Status=<$status> Response=<$response>"
            die
            ;;
    esac
done

echo SUCCESS
exit 0
