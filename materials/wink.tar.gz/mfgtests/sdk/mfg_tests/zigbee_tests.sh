#CF Manufacturing Tests Component

#board_id:APRON


#Zigbee Auto Receive
F_0D0308 ()
{
   echo "" >> /dev/ttyS0
   echo "Launching Zigbee Auto-receive" >> /dev/ttyS0
   
   bad=0

   #./zigbee-autoreceive
   
   if [ "$?" != "0" ]; then
      bad=1
   fi
   
   sleep 2

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Zigbee Auto-receive test [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Zigbee Auto-receive test [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Zigbee Receive - ON
F_0D0309 ()
{
   echo "" >> /dev/ttyS0
   echo "Launching Zigbee Receive - ON" >> /dev/ttyS0
   
   cd /mfgtests/sdk/tools
   bad=0

   echo "custom mfgrx" | ./ZigBeeHACoord -n 1 -p ttySP4 &
   
   if [ "$?" != "0" ]; then
      bad=1
   fi

   sleep 1

   cd /mfgtests/sdk/mfg_tests

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Zigbee Receive - ON [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
      #put code to turn on LED here if desired
   else
      echo "" >> /dev/ttyS0
      echo "Zigbee Receive - ON [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Zigbee RSSI
F_0D0311 ()
{
   echo "" >> /dev/ttyS0
   echo "Launching Zigbee RSSI" >> /dev/ttyS0
   
   cd /mfgtests/sdk/tools
   
   bad=0
   #put code to turn off LED here if desired  &> /dev/null

   sync
   rssiVal=`tail -n 1 /tmp/zigRssi`
   
   if [ "$?" != "0" ]; then
      bad=1
   fi

   cd /mfgtests/sdk/mfg_tests

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Zigbee RSSI [INFOSTART]$rssiVal[INFOEND]" >> /dev/ttyS0
      #put code to turn on LED here if desired
   else
      echo "" >> /dev/ttyS0
      echo "Zigbee RSSI [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Zigbee Transmit - unmodulated
F_0D0312 ()
{
   echo "" >> /dev/ttyS0
   echo "Launching Zigbee Transmit - unmodulated" >> /dev/ttyS0
   
   cd /mfgtests/sdk/tools/
   
   bad=0

   #pass in 3 for power level and 2 to enable the PA boost
   echo "custom mfgtx 3 2" | ./ZigBeeHACoord -n 1 -p ttySP4 &
   
   if [ "$?" != "0" ]; then
      bad=1
   fi

   sleep 1

   cd /mfgtests/sdk/mfg_tests

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Zigbee Transmit - unmodulated [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Zigbee Transmit - unmodulated [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Zigbee radio - OFF
F_0D0313 ()
{
   echo "" >> /dev/ttyS0
   echo "Launching Zigbee radio - OFF" >> /dev/ttyS0
   
   cd /mfgtests/sdk/tools
   
   bad=0

   for n in $(pidof ZigBeeHACoord); do kill -9 $n; done
   echo "" | ./ZigBeeHACoord -n 1 -p ttySP4
   
   ##commenting this out becasue the end of file in a pipe always throws an error
   ## but this is ok
   #if [ "$?" != "0" ]; then
   #   bad=1
   #fi
   
   if [ -e "/tmp/zigRssi" ]; then
      rm /tmp/zigRssi
   fi

   cd /mfgtests/sdk/mfg_tests

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Zigbee radio - OFF [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Zigbee radio - OFF [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}

