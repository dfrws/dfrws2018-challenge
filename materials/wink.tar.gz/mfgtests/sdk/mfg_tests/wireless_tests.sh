#CF Manufacturing Tests Component

#board_id:APRON

#wifi setup
setupwifi () {
   if [ $(lsmod | grep dhd | cut -d ' ' -f 1) ]
   then
      echo "wifi already set up"
   else
      echo "setting up wifi driver"
      /root/wifi/mfg.sh
   fi
}



#Wireless Ping Test
F_050101 () {
   echo "Testing Wireless Ping." >> /dev/ttyS0

   IfName="wlan0"

   echo "[INFOSTART]Enter IP to ping[INFOEND]" >> /dev/ttyS0
   read target_host

   echo "Pinging $target_host..." >> /dev/ttyS0

   if ip a s dev $IfName | grep 'inet ' &> /dev/null
   then
      ping -c 1 -w 3 -I $IfName $target_host &> /dev/null

      if [ $? -eq 0 ]
      then
         echo "" >> /dev/ttyS0
         echo "Wireless Ping [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
      else
         echo "" >> /dev/ttyS0
         echo "Wireless Ping [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
      fi
   
   else
      echo "" >> /dev/ttyS0
      echo "Link not detected. Wireless Ping [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Wifi Receive - ON
F_050102 () {
   echo "" >> /dev/ttyS0
   echo "Launching Wifi Receive - ON" >> /dev/ttyS0

   #setup wifi drivers if necessary
   setupwifi
   /mfgtests/sdk/support/run.sh &> /dev/null

   #put function here
   ipAddr=""

   while true;
   do
      ipAddr=`ifconfig wlan0 | grep inet | cut -d ':' -f 2 | cut -d ' ' -f 0`
      sleep 1;
      if [ ! -z "$ipAddr" ]; then
         echo "Connected!"
         break
      fi
      echo "trying to establish connection..."
   done

   echo "Wifi Receive - ON [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
}


#Wifi RSSI
F_050103 () {
   echo "" >> /dev/ttyS0
   echo "Launching Wifi RSSI" >> /dev/ttyS0
   
   bad=0
   
   #setup wifi drivers if necessary
   setupwifi

   #put function here
   #rssi=cat /proc/net/wireless | grep wlan0 | cut -d "\t" -f 4
   rssi=`wl rssi`

   if [ "$?" != "0" ]; then
      bad=1
   fi

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Wifi RSSI [INFOSTART]$rssi[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Wifi RSSI [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Wifi Transmit - umodulated
F_050104 () {
   echo "" >> /dev/ttyS0
   echo "Launching Wifi Transmit - umodulated" >> /dev/ttyS0
   
   #setup wifi drivers if necessary
   setupwifi

   ./tx_carrier.sh 6

   echo "Wifi Transmit - umodulated [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
}


#Wifi radio - OFF
F_050105 () {
   echo "" >> /dev/ttyS0
   echo "Launching Wifi radio - OFF" >> /dev/ttyS0
   
   bad=0
   
   if pidof wpa_supplicant &> /dev/null
   then
      #wifi must be running as a result of a previous receive test so kill it
      echo "disconnecting and turning off"
      killall wpa_supplicant
      killall udhcpc
      rmmod dhd
      
      if [ "$?" != "0" ]; then
         bad=1
      fi 
   else
      #we must be just turning off a transmit mode
      /root/wifi/wl fqacurcy 0
   
      if [ "$?" != "0" ]; then
         bad=1
      fi
   fi

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Wifi radio - OFF [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Wifi radio - OFF [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Wifi - Get Mac Address
F_050106 () {
   echo "" >> /dev/ttyS0
   echo "Launching Wifi - Get Mac Address" >> /dev/ttyS0
   
   bad=0
   
   #setup wifi drivers if necessary
   setupwifi

   MacAddr=`ip a s dev wlan0 | grep 'link' | cut -d ' ' -f 6`
   
   if [ "$MacAddr" == "" ]; then
      bad=1
   fi

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Wifi - Mac Address [INFOSTART]$MacAddr[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Wifi - Get Mac Address [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}

