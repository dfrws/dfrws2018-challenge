#CF Manufacturing Tests Component

#board_id:APRON


#Kidde receive test
F_0F0003 () {
   echo "Running Kidde receive test..." >> /dev/ttyS0

   echo "" >> /dev/ttyS0
   echo "Enabling Kidde radio" >> /dev/ttyS0
   
   bad=0

   cd /mfgtests/sdk/tools

   #run kidde receive test command here and send output to &> /dev/null
   ./kiddetest /dev/ttySP3 -r > /tmp/kiddedump &
   if [ "$?" != "0" ]; then
      bad=1
   fi

   ALIVEOK=0
      
   echo "Checking chip status..."
   for i in 1 2 3 4 5
   do
      if grep -q 'AFTER' /tmp/kiddedump
      then
         for i in 1 2 3
         do
            sleep 1
            if grep -q 'alive' /tmp/kiddedump
            then
               bad=0
               ALIVEOK=1
               break
            fi
         done
         if [ "$ALIVEOK" == "0" ]
         then 
            echo "[INFOSTART]KIDDE CHIP NOT ALIVE[INFOEND]" >> /dev/ttyS0
            bad=1
         fi
         break
      fi
      sleep 1
   done
      
   #brent start tag
   if [ "0" == $bad ]; then
   #brent end tag
   for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15
   do
      echo "Checking for data..."
      if grep -q '80' /tmp/kiddedump
      then
         echo "got data"
         bad=0
         break
      fi

      sleep 1
      bad=1
   done

   fi

   rm /tmp/kiddedump
   
   cd /mfgtests/sdk/mfg_tests
   
   killall kiddetest &> /dev/null

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Kidde receive test [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Kidde receive test [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}