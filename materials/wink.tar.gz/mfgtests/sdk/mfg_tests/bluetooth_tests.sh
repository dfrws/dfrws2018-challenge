#CF Manufacturing Tests Component

#board_id:APRON


#Bluetooth setup
setupbluetooth () {
   #check to see if Bluetooth is already up
   if [ ! $(pidof brcm_patchram_plus) ]; then
      #It's not up yet so bring it up
      echo "bringing up Bluetooth device first..."
      /mfgtests/sdk/support/run_bt.sh &

      while ! $(hciconfig hci0 up &> /dev/null)
      do
        echo "waiting to finish bring up..."
        sleep 1
      done
 
      cd /mfgtests/sdk/mfg_tests
   fi
}


bt_scan () {
   setupbluetooth

   hcitool lescan > /tmp/btle_devs &> /dev/null &
   for i in `seq 1 10`;
   do
      sleep 1
      echo "scanning..."
      if grep ':' /tmp/btle_devs
      then
         echo "Bluetooth LE device detected!" >> /dev/ttyS0
         killall hcitool
         return 0
      fi
   done

   killall hcitool
   return 1
}


#Bluetooth - Read MAC address
F_100101 () {

   echo "" >> /dev/ttyS0
   echo "Launching Bluetooth - Read Mac Address" >> /dev/ttyS0
   
   bad=0

   MacAddr=`fw_printenv bd_addr | cut -d '=' -f 2`
   
   if [ "$MacAddr" == "" ]; then
      bad=1
   fi

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Bluetooth - Mac Address [INFOSTART]$MacAddr[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Bluetooth - Read Mac Address [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Bluetooth - Write MAC address
F_100102 () {

   #The new MAC address will be next in line on the port so read it.
   while true; do
      echo "[INFOSTART]Enter new MAC address[INFOEND]" >> /dev/ttyS0
      read newMac

      #Do sanity check
      if [ "12" != "$(expr length "$newMac")" ]; then
         echo "[INFOSTART]Improper MAC address value. $newMac[INFOEND]" >> /dev/ttyS0
         echo "MAC address change [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
         break
      fi

      echo "Writing Bluetooth MAC address $newMac..." >> /dev/ttyS0

      #Apron uboot special requirement: must run setenv commands twice.
      fw_setenv bd_addr "$newMac"
      fw_setenv bd_addr "$newMac"
      
      sync
      sync
      sync

      if [ "$?" == "0" ]; then
         echo "" >> /dev/ttyS0
         echo "Bluetooth - Write MAC Address [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
         break
      else
         echo "" >> /dev/ttyS0
         echo "Bluetooth - Write MAC Address [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
         break
      fi
   done
}


#Bluetooth device scan test
F_100103 () {
   echo "Running Bluetooth device scan test" >> /dev/ttyS0

   echo "" >> /dev/ttyS0
   echo "Scanning for Bluetooth devices..." >> /dev/ttyS0

   bad=0

   bt_scan
   if [ "$?" != "0" ]; then
      bad=1
   fi
   
   sleep 2

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Bluetooth device scan test [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Bluetooth device scan test [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Bluetooth Receive - ON
F_100104 () {
   echo "" >> /dev/ttyS0
   echo "Launching Bluetooth Receive - ON" >> /dev/ttyS0
   
   #setup bluetooth drivers if necessary
   setupbluetooth

   #put function here

   echo "Bluetooth Receive - ON [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
}


#Bluetooth RSSI
F_100105 () {
   echo "" >> /dev/ttyS0
   echo "Launching Bluetooth RSSI" >> /dev/ttyS0
   
   #setup bluetooth drivers if necessary
   setupbluetooth

   #put function here
   #rssi=cat /proc/net/bluetooth | grep wlan0 | cut -d "\t" -f 4
   rssi=84

   echo "Bluetooth RSSI [INFOSTART]$rssi[INFOEND]" >> /dev/ttyS0
}


#Bluetooth Transmit - umodulated
F_100106 () {
   echo "" >> /dev/ttyS0
   echo "Launching Bluetooth Transmit - umodulated" >> /dev/ttyS0
   
   bad=0
   
   #setup bluetooth drivers if necessary
   setupbluetooth

   hcitool cmd 0x3f 0x014 0x0 0x02 0x00 0x00 0x0 0x0 0x0 &> /dev/null
   
   if [ "$?" != "0" ]; then
      bad=1
   fi

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Bluetooth Transmit - umodulated [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Bluetooth Transmit - umodulated [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Bluetooth radio - OFF
F_100107 () {
   echo "" >> /dev/ttyS0
   echo "Launching Bluetooth radio - OFF" >> /dev/ttyS0
   
   bad=0
   
   hcitool cmd 0x3f 0x014 0x1 &> /dev/null

   if [ "$?" != "0" ]; then
      bad=1
   fi

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Bluetooth radio - OFF [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Bluetooth radio - OFF [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}

