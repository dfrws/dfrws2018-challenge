#CF Manufacturing Tests Component

#board_id:APRON


#Get manufacturing test suite version info
F_FF0006 () {
   echo "Getting manufacturing test suite version info." >> /dev/ttyS0
   verno=`grep 'ver\.' /mfgtests/sdk/mfgtest.sh | awk -F '(' {'print $2'} | awk -F ')' {'print $1'}`

   echo "mfgtests version number is [INFOSTART]$verno[INFOEND]" >> /dev/ttyS0
}


#Write Serial Number
F_FF0007 () {

   #The serial number will be next in line on the port so read it.
   while true; do
      echo "[INFOSTART]Enter serial number[INFOEND]" >> /dev/ttyS0
      read newSerial

      echo "Writing serial number $newSerial..." >> /dev/ttyS0

      #Apron uboot special requirement: must run setenv commands twice.
      fw_setenv serialno "$newSerial"
      fw_setenv serialno "$newSerial"

      if [ "$?" = "0" ]; then
         echo "" >> /dev/ttyS0
         echo "Write Serial Number [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
         break
      else
         echo "" >> /dev/ttyS0
         echo "Write Serial Number [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
         break
      fi
   done
}

#Read Serial Number
F_FF0008 () {

   echo "" >> /dev/ttyS0
   echo "Launching Read Serial Number" >> /dev/ttyS0
   
   bad=0

   SerNum=`fw_printenv serialno | cut -d '=' -f 2`
   
   if [ "$SerNum" == "" ]; then
      bad=1
   fi

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Serial Number [INFOSTART]$SerNum[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Read Serial Number [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}

#Activate Customer Mode
F_FF0009 () {

   echo "" >> /dev/ttyS0
   echo "Activating Customer Mode" >> /dev/ttyS0
   
   bad=0

   echo 0 > /database/mfg_mode
   
   if [ "$?" != "0" ]; then
      bad=1
   fi
   
   sync
   sync
   sync

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Activate Customer Mode [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
      # Turn off serial terminal now...
      sed  -i 's/^ttyAM/#ttyAM/' /etc/inittab 
   else
      echo "" >> /dev/ttyS0
      echo "Activate Customer Mode [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}

