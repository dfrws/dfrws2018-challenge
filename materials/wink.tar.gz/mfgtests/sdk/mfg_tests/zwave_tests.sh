#CF Manufacturing Tests Component

#board_id:APRON


#Z-Wave Micro Terminal
F_0C0000 ()
{
   echo "" >> /dev/ttyS0
   echo "Launching Z-Wave Micro Terminal" >> /dev/ttyS0
   
   cd /mfgtests/sdk/tools

   ./z-wave_micro_terminal
   
   cd /mfgtests/sdk/mfg_tests

   echo "" >> /dev/ttyS0
   echo "Returning from Z-Wave Micro Terminal" >> /dev/ttyS0
}


#Z-Wave Micro Terminal Transmit - modulated
F_0C0001 ()
{
   echo "" >> /dev/ttyS0
   echo "Launching Z-Wave Micro Terminal Transmit - modulated" >> /dev/ttyS0
   
   cd /mfgtests/sdk/tools
   
   bad=0
   #put code to turn off LED here if desired  &> /dev/null

   ./z-wave_micro_terminal-auto tx
   
   if [ "$?" != "0" ]; then
      bad=1
   fi
   
   cd /mfgtests/sdk/mfg_tests

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Z-Wave Micro Terminal Transmit - modulated [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
      #put code to turn on LED here if desired
   else
      echo "" >> /dev/ttyS0
      echo "Z-Wave Micro Terminal Transmit - modulated [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Z-Wave Micro Terminal Auto Receive
F_0C0002 ()
{
   echo "" >> /dev/ttyS0
   echo "Launching Z-Wave Micro Terminal Auto-receive" >> /dev/ttyS0
   
   cd /mfgtests/sdk/tools
   
   bad=0
   #put code to turn off LED here if desired  &> /dev/null

   ./z-wave_micro_terminal-autoreceive
   
   if [ "$?" != "0" ]; then
      bad=1
   fi
   
   cd /mfgtests/sdk/mfg_tests
   
   sleep 2

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Z-Wave radio receive test [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
      #put code to turn on LED here if desired
   else
      echo "" >> /dev/ttyS0
      echo "Z-Wave radio receive test [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Z-Wave Micro Terminal Receive - ON
F_0C0003 ()
{
   echo "" >> /dev/ttyS0
   echo "Launching Z-Wave Micro Terminal Receive - ON" >> /dev/ttyS0
   
   cd /mfgtests/sdk/tools
   
   bad=0
   #put code to turn off LED here if desired  &> /dev/null

   ./z-wave_micro_terminal-auto rx
   
   if [ "$?" != "0" ]; then
      bad=1
   fi
   
   cd /mfgtests/sdk/mfg_tests

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Z-Wave Micro Terminal Receive - ON [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
      #put code to turn on LED here if desired
   else
      echo "" >> /dev/ttyS0
      echo "Z-Wave Micro Terminal Receive - ON [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Z-Wave RSSI
F_0C0005 ()
{
   echo "" >> /dev/ttyS0
   echo "Launching Z-Wave RSSI" >> /dev/ttyS0
   
   cd /mfgtests/sdk/tools
   
   bad=0
   #put code to turn off LED here if desired  &> /dev/null

   rssival=`./z-wave_micro_terminal-auto rssi | grep ' : ' | cut -d ' ' -f 3`
   
   if [ "$?" != "0" ]; then
      bad=1
   fi
   
   if [ ! $rssival ]; then
      bad=1
   fi

   cd /mfgtests/sdk/mfg_tests

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Z-Wave RSSI [INFOSTART]$rssival[INFOEND]" >> /dev/ttyS0
      #put code to turn on LED here if desired
   else
      echo "" >> /dev/ttyS0
      echo "Z-Wave RSSI [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Z-Wave Micro Terminal Transmit - unmodulated
F_0C0006 ()
{
   echo "" >> /dev/ttyS0
   echo "Launching Z-Wave Micro Terminal Transmit - unmodulated" >> /dev/ttyS0
   
   cd /mfgtests/sdk/tools
   
   bad=0
   #put code to turn off LED here if desired  &> /dev/null

   ./z-wave_micro_terminal-auto txc
   
   if [ "$?" != "0" ]; then
      bad=1
   fi
   
   cd /mfgtests/sdk/mfg_tests

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Z-Wave Micro Terminal Transmit - unmodulated [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
      #put code to turn on LED here if desired
   else
      echo "" >> /dev/ttyS0
      echo "Z-Wave Micro Terminal Transmit - unmodulated [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}


#Z-Wave radio - OFF
F_0C0007 ()
{
   echo "" >> /dev/ttyS0
   echo "Launching Z-Wave radio - OFF" >> /dev/ttyS0
   
   cd /mfgtests/sdk/tools
   
   bad=0
   #put code to turn off LED here if desired  &> /dev/null

   ./z-wave_micro_terminal-auto off
   
   if [ "$?" != "0" ]; then
      bad=1
   fi
   
   cd /mfgtests/sdk/mfg_tests

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Z-Wave radio - OFF [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
      #put code to turn on LED here if desired
   else
      echo "" >> /dev/ttyS0
      echo "Z-Wave radio - OFF [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}

