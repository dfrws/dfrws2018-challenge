#!/bin/sh -x

wlprog=/root/wifi/wl

echo starting carrier wave test with channel $1 
$wlprog mpc 0
$wlprog down
$wlprog country ALL
# change band below between a or b
$wlprog band b
$wlprog up
$wlprog phy_forcecal 1
sleep 2
$wlprog out
# change channel below to select carrier freq
$wlprog fqacurcy $1
echo to stop... 'wl fqacurcy 0'

