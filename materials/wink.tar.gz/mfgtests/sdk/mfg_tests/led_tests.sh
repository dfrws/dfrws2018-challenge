#CF Manufacturing Tests Component

#board_id:APRON

#control functions
blue_on () {
   echo "255" > /sys/class/leds/led-pwm2/brightness
}

blue_off () {
   echo "0" > /sys/class/leds/led-pwm2/brightness
}

red_on () {
   echo "255" > /sys/class/leds/led-pwm0/brightness
}

red_off () {
   echo "0" > /sys/class/leds/led-pwm0/brightness
}

green_on () {
   echo "255" > /sys/class/leds/led-pwm1/brightness
}

green_off () {
   echo "0" > /sys/class/leds/led-pwm1/brightness
}


#Green LED Test
F_010100 () {
   echo "Testing Green LED..." >> /dev/ttyS0

   echo "" >> /dev/ttyS0
   echo "Turning on Green LED" >> /dev/ttyS0

   green_on &> /dev/null

   while true; do
      echo "[INFOSTART]Did the Green LED turn on? (p for pass or f for fail)[INFOEND]" >> /dev/ttyS0
      read pf
      case $pf in
         [Pp]* ) echo "Turning off Green LED..." >> /dev/ttyS0
                 green_off &> /dev/null
                 echo "" >> /dev/ttyS0
                 echo "Green LED [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
                 break;;
         [Ff]* ) green_off &> /dev/null
                 echo "" >> /dev/ttyS0
                 echo "Green LED [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
                 break;;
             * ) echo "Please answer p for pass or f for fail." >> /dev/ttyS0;;
      esac
   done
}


#Green LED On
F_010101 () {
   echo "Turning on Green LED..." >> /dev/ttyS0

   echo "" >> /dev/ttyS0

   green_on &> /dev/null

   echo "Green LED on [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
}


#Green LED Off
F_010102 () {
   echo "Turning off Green LED..." >> /dev/ttyS0

   echo "" >> /dev/ttyS0

   green_off &> /dev/null

   echo "Green LED off [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
}


#Blue LED Test
F_010300 () {
   echo "Testing Blue LED..." >> /dev/ttyS0

   echo "" >> /dev/ttyS0
   echo "Turning on Blue LED" >> /dev/ttyS0

   blue_on &> /dev/null

   while true; do
      echo "[INFOSTART]Did the Blue LED turn on? (p for pass or f for fail)[INFOEND]" >> /dev/ttyS0
      read pf
      case $pf in
         [Pp]* ) echo "Turning off Blue LED..." >> /dev/ttyS0
                 blue_off &> /dev/null
                 echo "" >> /dev/ttyS0
                 echo "Blue LED [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
                 break;;
         [Ff]* ) blue_off &> /dev/null
                 echo "" >> /dev/ttyS0
                 echo "Blue LED [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
                 break;;
             * ) echo "Please answer p for pass or f for fail." >> /dev/ttyS0;;
      esac
   done
}


#Blue LED On
F_010301 () {
   echo "Turning on Blue LED..." >> /dev/ttyS0

   echo "" >> /dev/ttyS0

   blue_on &> /dev/null

   echo "Blue LED on [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
}


#Blue LED Off
F_010302 () {
   echo "Turning off Blue LED..." >> /dev/ttyS0

   echo "" >> /dev/ttyS0

   green_on &> /dev/null

   echo "Blue LED off [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
}


#Red LED Test
F_010400 () {
   echo "Testing Red LED..." >> /dev/ttyS0

   echo "" >> /dev/ttyS0
   echo "Turning on Red LED" >> /dev/ttyS0

   red_on &> /dev/null

   while true; do
      echo "[INFOSTART]Did the Red LED turn on? (p for pass or f for fail)[INFOEND]" >> /dev/ttyS0
      read pf
      case $pf in
         [Pp]* ) echo "Turning off Red LED..." >> /dev/ttyS0
                 red_off &> /dev/null
                 echo "" >> /dev/ttyS0
                 echo "Red LED [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
                 break;;
         [Ff]* ) red_off &> /dev/null
                 echo "" >> /dev/ttyS0
                 echo "Red LED [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
                 break;;
             * ) echo "Please answer p for pass or f for fail." >> /dev/ttyS0;;
      esac
   done
}


#Red LED On
F_010401 () {
   echo "Turning on Red LED..." >> /dev/ttyS0

   echo "" >> /dev/ttyS0

   green_on &> /dev/null

   echo "Red LED on [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
}


#Red LED Off
F_010402 () {
   echo "Turning off Red LED..." >> /dev/ttyS0

   echo "" >> /dev/ttyS0

   green_on &> /dev/null

   echo "Red LED off [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
}
