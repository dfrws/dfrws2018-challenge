#CF Manufacturing Tests Component

#board_id:APRON

#Lutron Update
F_0E0000 () {
   echo "" >> /dev/ttyS0
   echo "Launching Lutron Update" >> /dev/ttyS0
   
   bad=0

   if ! md5sum /database/lutron-db.sqlite | grep "3771b9a14dab8f1f21726081a34a8b39"; then
      bad=1
   fi

   ../tools/lutron-coproc-init.sh
   
   if [ "$?" != "0" ]; then
      bad=1
   fi

   if [ "0" == $bad ]; then
      echo "" >> /dev/ttyS0
      echo "Lutron Update [INFOSTART]PASSED[INFOEND]" >> /dev/ttyS0
   else
      echo "" >> /dev/ttyS0
      echo "Lutron Update [INFOSTART]FAILED[INFOEND]" >> /dev/ttyS0
   fi
}
