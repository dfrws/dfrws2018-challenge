#!/bin/sh

#CF Manufacturing Tests Component

#board_id:APRON

if [ $(pidof mfg_test_menu.sh) ]; then
    echo "Not Doing anything" >> /dev/ttyS0
    exit 0
fi

#launch test application
./mfg_test_menu.sh
