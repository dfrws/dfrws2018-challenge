#!/bin/sh

#CF Manufacturing Tests Component

#board_id:APRON

source ./led_tests.sh
source ./wireless_tests.sh
source ./zwave_tests.sh
source ./zigbee_tests.sh
source ./lutron_tests.sh
source ./kidde_tests.sh
source ./bluetooth_tests.sh
source ./utility_functions.sh

#clear

#turn off LEDs
red_off
green_off
blue_off

#User menu
Menu () {
   echo "Choose a test or function number from the list." >> /dev/ttyS0
   echo "Enter \"q\" to quit." >> /dev/ttyS0
   echo "     Tests:" >> /dev/ttyS0
   echo "010100) Green LED" >> /dev/ttyS0
   echo "010101) Green LED - ON" >> /dev/ttyS0
   echo "010102) Green LED - OFF" >> /dev/ttyS0
   echo "010300) Blue LED" >> /dev/ttyS0
   echo "010301) Blue LED - ON" >> /dev/ttyS0
   echo "010302) Blue LED - OFF" >> /dev/ttyS0
   echo "010400) Red LED" >> /dev/ttyS0
   echo "010401) Red LED - ON" >> /dev/ttyS0
   echo "010402) Red LED - OFF" >> /dev/ttyS0
   echo "050101) Wirless Ping" >> /dev/ttyS0
   echo "050102) Wifi Receive - ON" >> /dev/ttyS0
   echo "050103) Wifi RSSI" >> /dev/ttyS0
   echo "050104) Wifi Transmit - umodulated" >> /dev/ttyS0
   echo "050105) Wifi radio  - OFF" >> /dev/ttyS0
   echo "050106) Wifi - Get Mac Address" >> /dev/ttyS0
   echo "0C0000) Z-Wave Mirco Terminal" >> /dev/ttyS0
   echo "0C0003) Z-Wave Micro Terminal Receive - ON" >> /dev/ttyS0
   echo "0C0005) Z-Wave RSSI" >> /dev/ttyS0
   echo "0C0006) Z-Wave Micro Terminal Transmit - umodulated" >> /dev/ttyS0
   echo "0C0007) Z-Wave radio - OFF" >> /dev/ttyS0
   echo "0D0309) Zigbee Receive - ON" >> /dev/ttyS0
   echo "0D0311) Zigbee RSSI" >> /dev/ttyS0
   echo "0D0312) Zigbee Transmit - umodulated" >> /dev/ttyS0
   echo "0D0313) Zigbee radio - OFF" >> /dev/ttyS0
   echo "0E0000) Lutron Update" >> /dev/ttyS0
   echo "0F0003) Kidde_receive_test" >> /dev/ttyS0
   echo "100102) Bluetooth - Write MAC address" >> /dev/ttyS0
   echo "100103) Bluetooth device scan test" >> /dev/ttyS0
   echo "100104) Bluetooth Receive - ON" >> /dev/ttyS0
   echo "100105) Bluetooth RSSI" >> /dev/ttyS0
   echo "100106) Bluetooth Transmit - umodulated" >> /dev/ttyS0
   echo "100107) Bluetooth radio - OFF" >> /dev/ttyS0
   echo "     Functions:" >> /dev/ttyS0
   echo "FF0006) Get manufacturing test suite version info" >> /dev/ttyS0
   echo "FF0007) Write Serial Number" >> /dev/ttyS0
   echo "[INFOSTART]READY[INFOEND]" >> /dev/ttyS0
}

#Main
while [ 1 ]
do
   #Menu
   echo "[INFOSTART]READY[INFOEND]" >> /dev/ttyS0
   read choice
   
   echo "$choice" >> /dev/ttyS0

   case "$choice" in
      "010100")
         F_010100   #Green LED
         echo "" >> /dev/ttyS0
         ;;
      "010101")
         F_010101   #Green LED - ON
         echo "" >> /dev/ttyS0
         ;;
      "010102")
         F_010102   #Green LED - OFF
         echo "" >> /dev/ttyS0
         ;;
      "010300")
         F_010300   #Blue LED
         echo "" >> /dev/ttyS0
         ;;
      "010301")
         F_010301   #Blue LED - ON
         echo "" >> /dev/ttyS0
         ;;
      "010302")
         F_010302   #Blue LED - OFF
         echo "" >> /dev/ttyS0
         ;;
      "010400")
         F_010400   #Red LED
         echo "" >> /dev/ttyS0
         ;;
      "010401")
         F_010401   #Red LED - ON
         echo "" >> /dev/ttyS0
         ;;
      "010402")
         F_010402   #Red LED - OFF
         echo "" >> /dev/ttyS0
         ;;
      "050101")
         F_050101   #Wireless Ping
         echo "" >> /dev/ttyS0
         ;;
      "050102")
         F_050102    #Wifi Receive - ON
         echo "" >> /dev/ttyS0
         ;;
      "050103")
         F_050103   #Wifi RSSI
         echo "" >> /dev/ttyS0
         ;;
      "050104")
         F_050104   #Wifi Transmit - umodulated
         echo "" >> /dev/ttyS0
         ;;
      "050105")
         F_050105   #Wifi radio  - OFF
         echo "" >> /dev/ttyS0
         ;;
      "050106")
         F_050106   #Wifi - Get Mac Address
         echo "" >> /dev/ttyS0
         ;;
      "0C0000")
         F_0C0000   #Z-Wave Micro Terminal
         echo "" >> /dev/ttyS0
         ;;
      "0C0001")
         F_0C0001   #Z-Wave Micro Terminal Transmit - modulated
         echo "" >> /dev/ttyS0
         ;;
      "0C0003")
         F_0C0003   #Z-Wave Micro Terminal Receive - ON
         echo "" >> /dev/ttyS0
         ;;
      "0C0005")
         F_0C0005   #Z-Wave RSSI
         echo "" >> /dev/ttyS0
         ;;
      "0C0006")
         F_0C0006   #Z-Wave Micro Terminal Transmit - unmodulated
         echo "" >> /dev/ttyS0
         ;;
      "0C0007")
         F_0C0007   #Z-Wave radio - OFF
         echo "" >> /dev/ttyS0
         ;;
      "0D0309")
         F_0D0309   #Zigbee Receive - ON
         echo "" >> /dev/ttyS0
         ;;
      "0D0311")
         F_0D0311   #Zigbee RSSI
         echo "" >> /dev/ttyS0
         ;;
      "0D0312")
         F_0D0312   #Zigbee Transmit - umodulated
         echo "" >> /dev/ttyS0
         ;;
      "0D0313")
         F_0D0313   #Zigbee radio - OFF
         echo "" >> /dev/ttyS0
         ;;
      "0E0000")
         F_0E0000   #Lutron Update
         echo "" >> /dev/ttyS0
         ;;
      "0F0003")                                                                                
         F_0F0003   #Kidde_receive_test
         echo "" >> /dev/ttyS0                                                                 
         ;;
      "100101")
         F_100101   #Bluetooth - Read MAC address
         echo "" >> /dev/ttyS0                                                                 
         ;;
      "100102")
         F_100102   #Bluetooth - Write MAC address
         echo "" >> /dev/ttyS0                                                                 
         ;;
      "100103")
         F_100103    #Bluetooth device scan test
         echo "" >> /dev/ttyS0
         ;;
      "100104")
         F_100104    #Bluetooth Receive - ON
         echo "" >> /dev/ttyS0
         ;;
      "100105")
         F_100105    #Bluetooth RSSI
         echo "" >> /dev/ttyS0
         ;;
      "100106")
         F_100106    #Bluetooth Transmit - umodulated
         echo "" >> /dev/ttyS0
         ;;
      "100107")
         F_100107    #Bluetooth radio - OFF
         echo "" >> /dev/ttyS0
         ;;
      "FF0006")
         F_FF0006   #Get manufacturing test suite version info                                                                
         echo "" >> /dev/ttyS0                                                                 
         ;;
      "FF0007")
         F_FF0007   #Write Serial Number
         echo "" >> /dev/ttyS0                                                                 
         ;;
      "FF0008")
         F_FF0008   #Read Serial Number
         echo "" >> /dev/ttyS0
         ;;
      "FF0009")
         F_FF0009   #Activate Customer Mode
         echo "" >> /dev/ttyS0
         ;;
      "m")
         Menu
         ;;
      "q")
         exit   #quit
         ;;
   esac
done

