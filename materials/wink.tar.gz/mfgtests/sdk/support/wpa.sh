#!/bin/ash -x
wpa_supplicant -iwlan0 -Dwext -c/mfgtests/sdk/support/wpa_supplicant.conf &
sleep 6
udhcpc -i wlan0 -t 15 -b

