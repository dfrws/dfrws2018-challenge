#!/bin/ash -x
PATCHRAM="/root/bt/BCM4334B0_002.001.013.1806.0000_Confocus_Apron_TEST_ONLY.hcd"
PORT="/dev/ttySP0"

insmod /root/bt/compat.ko
insmod /root/bt/bluetooth.ko
insmod /root/bt/hci_uart.ko

/root/bt/brcm_patchram_plus --baudrate 4000000 --use_baudrate_for_download --no2bytes --enable_hci --patchram $PATCHRAM $PORT &

