#!/bin/sh

#CF Manufacturing Tests Component

#board_id:APRON


#Check for getty and wait if not initialized
count=0
while ! pidof getty >/dev/null && ! [ "$count" = "10" ]; do
   sleep 1
   let count=count+1
done

#stop operation of getty to prevent communication race condition on /dev/ttyS0
kill -23 "$(pidof getty)"  # SIGSTOP

#start manufacturing tests
cd /mfgtests/sdk/mfg_tests/
echo "Launching the APRON Manufacturing test application (ver. 0.1.1, 20150923)..." > /dev/ttyS0
./launch-test-app.sh

#resume operation of getty when manufacturing test program ends
if [ 1 -eq $# ]; then
    kill -25 "$(pidof getty)"  # SIGCONT
fi
